"""Live HTTP upload integration test for JARVIS API.

Tests:
1. Upload real audio File A via HTTP POST /api/upload
2. Poll /api/analysis/{id} until pipeline completes
3. Verify evidence-based metrics and 5-component deterministic score
4. Upload File B via HTTP POST /api/upload and verify distinct measurements & scores
5. Repeated upload of File A: verify SHA-256 content match and cache handling
"""

import os
import sys
import time
import wave
import struct
import math
import requests

BASE_URL = "http://localhost:8000"


def generate_wav(path: str, duration: float, rate_hz: float, base_f0: float):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    n_samples = int(duration * 16000)
    with wave.open(path, "w") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(16000)
        frames = bytearray()
        for i in range(n_samples):
            t = i / 16000.0
            env = 0.5 * (1.0 + math.cos(2.0 * math.pi * rate_hz * t))
            sig = math.sin(2.0 * math.pi * base_f0 * t) * env * 0.7
            val = int(max(-32767, min(32767, sig * 32767.0)))
            frames.extend(struct.pack("<h", val))
        wf.writeframes(frames)


def test_live_pipeline():
    print("=" * 70)
    print("LIVE HTTP ENDPOINT AUDIT & VERIFICATION")
    print("=" * 70)

    # 1. Health check
    h_res = requests.get(f"{BASE_URL}/health")
    assert h_res.status_code == 200, f"Backend health failed: {h_res.text}"
    print("[1] Backend /health: 200 OK")

    os.makedirs("test_scratch", exist_ok=True)
    file_1 = "test_scratch/http_sample_fast.wav"
    file_2 = "test_scratch/http_sample_slow.wav"

    generate_wav(file_1, duration=5.0, rate_hz=6.0, base_f0=240.0)
    generate_wav(file_2, duration=6.0, rate_hz=2.0, base_f0=120.0)

    # 2. Upload File 1
    print("\n[2] Uploading File 1 via POST /api/upload...")
    with open(file_1, "rb") as f:
        up1 = requests.post(f"{BASE_URL}/api/upload", files={"file": ("http_sample_fast.wav", f, "audio/wav")})
    assert up1.status_code == 200, f"Upload 1 failed: {up1.text}"
    id_1 = up1.json()["analysis_id"]
    print(f"  Analysis 1 ID: {id_1}")

    # Wait for completion
    res1 = None
    for _ in range(30):
        time.sleep(1)
        r = requests.get(f"{BASE_URL}/api/analysis/{id_1}").json()
        if r.get("status") in {"complete", "completed", "failed", "error"}:
            res1 = r
            break

    assert res1 is not None, "Pipeline timed out"
    assert res1.get("status") == "completed", f"Pipeline failed: {res1.get('error')}"
    score_1 = res1.get("scores", {})
    metrics_1 = res1.get("metrics", {})
    print(f"  File 1 Completed! Overall Score: {score_1.get('overall')}/100 ({score_1.get('grade')})")
    print(f"  Pace Score: {score_1.get('components', {}).get('pace', {}).get('score')}")
    print(f"  Syllable Rate: {metrics_1.get('speaking_rate', {}).get('overall_syl_per_sec')} syl/s")

    # 3. Upload File 2
    print("\n[3] Uploading File 2 via POST /api/upload...")
    with open(file_2, "rb") as f:
        up2 = requests.post(f"{BASE_URL}/api/upload", files={"file": ("http_sample_slow.wav", f, "audio/wav")})
    assert up2.status_code == 200, f"Upload 2 failed: {up2.text}"
    id_2 = up2.json()["analysis_id"]
    print(f"  Analysis 2 ID: {id_2}")
    assert id_1 != id_2, "Different files must receive different analysis IDs"

    res2 = None
    for _ in range(30):
        time.sleep(1)
        r = requests.get(f"{BASE_URL}/api/analysis/{id_2}").json()
        if r.get("status") in {"complete", "completed", "failed", "error"}:
            res2 = r
            break

    assert res2 is not None, "Pipeline 2 timed out"
    assert res2.get("status") == "completed", f"Pipeline 2 failed: {res2.get('error')}"
    score_2 = res2.get("scores", {})
    metrics_2 = res2.get("metrics", {})
    print(f"  File 2 Completed! Overall Score: {score_2.get('overall')}/100 ({score_2.get('grade')})")
    print(f"  Pace Score: {score_2.get('components', {}).get('pace', {}).get('score')}")
    print(f"  Syllable Rate: {metrics_2.get('speaking_rate', {}).get('overall_syl_per_sec')} syl/s")

    # Verify results differ based on audio content
    assert metrics_1.get("speaking_rate", {}).get("overall_syl_per_sec") != metrics_2.get("speaking_rate", {}).get("overall_syl_per_sec"), "Different files must have different rates"
    assert score_1.get("overall") != score_2.get("overall"), "Different files must have distinct calculated scores"
    print("  -> Verified: Results are NOT reused or hardcoded across different files.")

    # 4. Repeated upload of File 1 (Content Hash Match & Genuine Cache Handling)
    print("\n[4] Repeated upload of File 1 via POST /api/upload...")
    with open(file_1, "rb") as f:
        up1_repeat = requests.post(f"{BASE_URL}/api/upload", files={"file": ("http_sample_fast.wav", f, "audio/wav")})
    assert up1_repeat.status_code == 200
    repeat_data = up1_repeat.json()
    print(f"  Response: analysis_id={repeat_data.get('analysis_id')}, cached={repeat_data.get('cached')}")
    assert repeat_data.get("analysis_id") == id_1, "Identical content hash must resolve to the verified analysis"
    assert repeat_data.get("cached") is True, "Expected cached=True for identical content"
    print("  -> Verified: Exact content match reuses verified analysis safely without redundant re-computation.")

    # Cleanup test files
    for p in [file_1, file_2]:
        if os.path.exists(p):
            os.remove(p)

    print("\n" + "=" * 70)
    print("ALL LIVE HTTP PIPELINE AUDIT CHECKS PASSED SUCCESSFULLY!")
    print("=" * 70)


if __name__ == "__main__":
    test_live_pipeline()
