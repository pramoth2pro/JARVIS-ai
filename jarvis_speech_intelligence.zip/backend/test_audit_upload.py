"""Comprehensive audit test suite for JARVIS upload-based analysis mode.

Verifies:
1. Actual uploaded content reaches and passes through the analysis pipeline.
2. Two different files with known differences produce distinct, evidence-based results.
3. No hardcoded scores or accidental result reuse across different files.
4. Repeated upload of the same file produces consistent, reproducible results.
5. Video uploads extract visual presentation metrics and synchronize findings.
6. Missing audio tracks (silent video) never produce fabricated speech scores.
7. Scores are calculated strictly from deterministic mathematical rules.
"""

import os
import sys
import json
import wave
import struct
import math
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

# Add backend directory to path
backend_dir = Path(__file__).resolve().parent
sys.path.insert(0, str(backend_dir))

from app.audio_processor import AudioProcessor
from app.transcriber import Transcriber
from app.flaw_detector import FlawDetector
from app.video_processor import VideoProcessor
from app.scoring import compute_component_scores
from app.llm_explainer import LLMExplainer


def create_synthetic_wav(
    filepath: str,
    duration_sec: float = 6.0,
    sample_rate: int = 16000,
    base_freq: float = 220.0,
    freq_mod: float = 0.0,
    silence_start: float = -1.0,
    silence_duration: float = 0.0,
    syllable_rate: float = 4.0,
):
    """Generate deterministic synthetic speech-like acoustic audio WAV file."""
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    n_samples = int(duration_sec * sample_rate)
    with wave.open(filepath, "w") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)  # 16-bit
        wav_file.setframerate(sample_rate)

        frames = bytearray()
        for i in range(n_samples):
            t = float(i) / sample_rate

            # Check for silence window
            if silence_start >= 0 and silence_start <= t < (silence_start + silence_duration):
                sample_val = 0
            else:
                # Modulated pitch frequency
                curr_freq = base_freq + freq_mod * math.sin(2.0 * math.pi * 1.5 * t)
                # Amplitude envelope simulating syllable bursts
                envelope = 0.5 * (1.0 + math.cos(2.0 * math.pi * syllable_rate * t))
                carrier = math.sin(2.0 * math.pi * curr_freq * t)
                sample_float = carrier * envelope * 0.7
                sample_val = int(max(-32767, min(32767, sample_float * 32767.0)))

            frames.extend(struct.pack("<h", sample_val))

        wav_file.writeframes(frames)


def create_synthetic_video(
    filepath: str,
    audio_wav_path: Optional[str] = None,
    duration_sec: float = 4.0,
    fps: int = 10,
    width: int = 320,
    height: int = 240,
):
    """Create a deterministic synthetic MP4 video container using static FFmpeg."""
    from app.video_processor import VideoProcessor
    vp = VideoProcessor()
    ffmpeg_bin = vp._get_ffmpeg_bin()
    os.makedirs(os.path.dirname(filepath), exist_ok=True)

    # Generate test video frames using FFmpeg testsrc
    if audio_wav_path and os.path.exists(audio_wav_path):
        cmd = [
            ffmpeg_bin, "-y",
            "-f", "lavfi", "-i", f"testsrc=duration={duration_sec}:size={width}x{height}:rate={fps}",
            "-i", str(audio_wav_path),
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "128k",
            "-shortest",
            str(filepath),
        ]
    else:
        # Silent video (NO audio stream)
        cmd = [
            ffmpeg_bin, "-y",
            "-f", "lavfi", "-i", f"testsrc=duration={duration_sec}:size={width}x{height}:rate={fps}",
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-an",  # Explicitly disable audio stream
            str(filepath),
        ]

    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if res.returncode != 0:
        raise RuntimeError(f"FFmpeg synthetic video creation failed: {res.stderr.decode('utf-8', errors='ignore')}")


def run_full_audit():
    print("=" * 75)
    print("JARVIS UPLOAD-BASED ANALYSIS AUDIT & VERIFICATION SUITE")
    print("=" * 75)

    test_dir = backend_dir / "test_scratch"
    os.makedirs(test_dir, exist_ok=True)

    audio_proc = AudioProcessor(target_sr=16000)
    flaw_det = FlawDetector()
    video_proc = VideoProcessor(target_fps=1.0)
    llm_exp = LLMExplainer()

    passed_checks = 0
    total_checks = 0

    # -------------------------------------------------------------------------
    # Setup Test Files
    # -------------------------------------------------------------------------
    # File A: Fast Speaking Cadence (6.2 syl/s), high pitch inflection (freq_mod=60Hz)
    file_a = str(test_dir / "sample_a_rapid_dynamic.wav")
    create_synthetic_wav(
        file_a,
        duration_sec=6.0,
        base_freq=220.0,
        freq_mod=60.0,
        syllable_rate=6.2,
    )

    # File B: Slow Monotone Cadence (1.8 syl/s), flat pitch (freq_mod=0Hz), 2.5s dead-air pause
    file_b = str(test_dir / "sample_b_slow_monotone_pause.wav")
    create_synthetic_wav(
        file_b,
        duration_sec=7.0,
        base_freq=130.0,
        freq_mod=2.0,  # Almost completely flat pitch
        silence_start=2.0,
        silence_duration=2.5,
        syllable_rate=1.8,
    )

    # File C: MP4 Video with audio track
    file_c = str(test_dir / "sample_c_video_with_audio.mp4")
    create_synthetic_video(file_c, audio_wav_path=file_a, duration_sec=4.0)

    # File D: MP4 Video with NO audio track (silent video)
    file_d = str(test_dir / "sample_d_silent_video_no_audio.mp4")
    create_synthetic_video(file_d, audio_wav_path=None, duration_sec=4.0)

    # -------------------------------------------------------------------------
    # Check 1: Ingestion reaches actual pipeline and extracts real measurements
    # -------------------------------------------------------------------------
    total_checks += 1
    print("\n[CHECK 1] Ingestion and Real Feature Extraction on File A...")
    features_a = audio_proc.extract_features(file_a)
    print(f"  Duration: {features_a['duration']}s")
    print(f"  Mean F0: {features_a['pitch']['mean_f0']} Hz, Std F0: {features_a['pitch']['std_f0']} Hz")
    print(f"  Overall Syllable Rate: {features_a['speaking_rate']['overall_syl_per_sec']} syl/s")
    print(f"  RMS Mean: {features_a['rms']['mean_rms']}")

    assert features_a["duration"] > 5.0, "Feature extraction failed duration check"
    assert features_a["pitch"]["mean_f0"] > 100.0, "Real pYIN pitch not extracted"
    assert features_a["speaking_rate"]["overall_syl_per_sec"] > 4.5, "Fast syllable rate not detected"
    print("  -> PASS: File A reaches pipeline and yields genuine computed acoustic metrics.")
    passed_checks += 1

    # -------------------------------------------------------------------------
    # Check 2: File B produces distinct acoustic measurements (No Hardcoding/Reusing)
    # -------------------------------------------------------------------------
    total_checks += 1
    print("\n[CHECK 2] Verification of Contrastive Audio File B...")
    features_b = audio_proc.extract_features(file_b)
    print(f"  Duration: {features_b['duration']}s")
    print(f"  Mean F0: {features_b['pitch']['mean_f0']} Hz, Std F0: {features_b['pitch']['std_f0']} Hz")
    print(f"  Overall Syllable Rate: {features_b['speaking_rate']['overall_syl_per_sec']} syl/s")
    print(f"  Pauses Detected: {len(features_b['pauses'])}")

    # Verify physical differences
    rate_diff = abs(features_a["speaking_rate"]["overall_syl_per_sec"] - features_b["speaking_rate"]["overall_syl_per_sec"])
    pitch_std_diff = abs(features_a["pitch"]["std_f0"] - features_b["pitch"]["std_f0"])
    pause_count_diff = abs(len(features_a["pauses"]) - len(features_b["pauses"]))

    print(f"  Rate difference: {rate_diff:.2f} syl/s")
    print(f"  Pitch variation difference: {pitch_std_diff:.2f} Hz")
    print(f"  Pause count difference: {pause_count_diff}")

    assert rate_diff >= 1.0, f"Physical rate difference not reflected in acoustic extraction: {rate_diff:.2f}"
    assert pitch_std_diff > 10.0, "Physical pitch variation difference not reflected"
    assert len(features_b["pauses"]) >= 1, "Expected long pause in File B not detected"
    print("  -> PASS: File B measurements genuinely differ based on acoustic facts (no static/mock numbers).")
    passed_checks += 1

    # -------------------------------------------------------------------------
    # Check 3: Deterministic Flaw Detection & Scoring on File A vs File B
    # -------------------------------------------------------------------------
    total_checks += 1
    print("\n[CHECK 3] Deterministic Flaw Detection & Scoring Rules...")
    # Mock aligned transcript corresponding to the audio durations
    transcript_a = {
        "text": "This is a rapidly delivered presentation with high energy.",
        "language": "en",
        "segments": [{"start": 0.0, "end": 6.0, "text": "This is a rapidly delivered presentation with high energy."}],
        "words": [
            {"word": "This", "start": 0.1, "end": 0.4, "probability": 0.95},
            {"word": "presentation", "start": 1.5, "end": 2.2, "probability": 0.95},
        ],
    }

    transcript_b = {
        "text": "Deliberate words ... long pause ... concluding remarks.",
        "language": "en",
        "segments": [{"start": 0.0, "end": 7.0, "text": "Deliberate words long pause concluding remarks."}],
        "words": [
            {"word": "Deliberate", "start": 0.2, "end": 1.5, "probability": 0.90},
            {"word": "remarks", "start": 5.0, "end": 6.5, "probability": 0.90},
        ],
    }

    flaws_a = flaw_det.detect_flaws(transcript_a, features_a, file_a)
    flaws_b = flaw_det.detect_flaws(transcript_b, features_b, file_b)

    cats_a = {f["category"] for f in flaws_a}
    cats_b = {f["category"] for f in flaws_b}

    print(f"  Flaws in File A: {cats_a}")
    print(f"  Flaws in File B: {cats_b}")

    scores_a = compute_component_scores(features_a, flaws_a, transcript_a, is_video=False)
    scores_b = compute_component_scores(features_b, flaws_b, transcript_b, is_video=False)

    print(f"  File A Scores: Overall={scores_a['overall']} ({scores_a['grade']}) | Pace={scores_a['components']['pace']['score']} | Vocal={scores_a['components']['vocal_delivery']['score']}")
    print(f"  File B Scores: Overall={scores_b['overall']} ({scores_b['grade']}) | Pace={scores_b['components']['pace']['score']} | Fluency={scores_b['components']['fluency']['score']}")

    # Verify that different acoustic profiles yield different deterministic scores
    assert scores_a["overall"] != scores_b["overall"], "Scores should differ according to acoustic differences"
    assert scores_b["components"]["fluency"]["score"] < 90.0, "Long pause in File B should penalize fluency"
    print("  -> PASS: Deterministic rules calculate distinct component scores based on measured flaws.")
    passed_checks += 1

    # -------------------------------------------------------------------------
    # Check 4: Repeated Analysis of Same File is Reproducible & Consistent
    # -------------------------------------------------------------------------
    total_checks += 1
    print("\n[CHECK 4] Repeated Analysis of File A (Reproducibility)...")
    features_a2 = audio_proc.extract_features(file_a)
    flaws_a2 = flaw_det.detect_flaws(transcript_a, features_a2, file_a)
    scores_a2 = compute_component_scores(features_a2, flaws_a2, transcript_a, is_video=False)

    assert scores_a["overall"] == scores_a2["overall"], f"Non-deterministic scores on identical input: {scores_a['overall']} vs {scores_a2['overall']}"
    assert len(flaws_a) == len(flaws_a2), "Flaw counts differed on identical input"
    print(f"  Original: {scores_a['overall']} / Repeated: {scores_a2['overall']}")
    print("  -> PASS: Repeated analysis of identical input produces 100% reproducible metrics and scores.")
    passed_checks += 1

    # -------------------------------------------------------------------------
    # Check 5: Video Upload Processing (Visual Presentation Metrics & Timestamps)
    # -------------------------------------------------------------------------
    total_checks += 1
    print("\n[CHECK 5] Video Upload Processing & Visual Metrics (File C)...")
    is_vid_c = video_proc.is_video_file(file_c)
    has_aud_c = video_proc.has_audio_stream(file_c)
    assert is_vid_c, "Failed to identify MP4 as video"
    assert has_aud_c, "Failed to identify audio track in video MP4"

    vis_result = video_proc.analyze_presentation(file_c)
    assert vis_result["is_video"], "Visual analysis failed is_video check"
    vis_metrics = vis_result["metrics"]
    print(f"  Frames Analyzed: {vis_metrics['frame_count']}")
    print(f"  Average Brightness: {vis_metrics['average_brightness']}/255")
    print(f"  Lighting Stability: {vis_metrics['lighting_stability']}%")
    print(f"  Motion Stability: {vis_metrics['motion_stability']}%")
    print(f"  Framing Stability: {vis_metrics['framing_stability']}%")

    # Score with 5 components
    scores_video = compute_component_scores(
        features_a,
        flaws_a + vis_result["findings"],
        transcript_a,
        is_video=True,
        visual_metrics=vis_metrics,
        has_audio=True,
    )
    print(f"  Video 5-Component Score: {scores_video['overall']}/100")
    print(f"  Visual Presentation Component: {scores_video['components']['visual_presentation']['score']}/100 ({scores_video['components']['visual_presentation']['grade']})")

    assert scores_video["components"]["visual_presentation"]["score"] is not None
    assert scores_video["is_video"] is True
    print("  -> PASS: Video frames extracted and evaluated separately for visual presentation.")
    passed_checks += 1

    # -------------------------------------------------------------------------
    # Check 6: Video with Missing Audio Track (Requirement 5 & 7)
    # -------------------------------------------------------------------------
    total_checks += 1
    print("\n[CHECK 6] Video with NO Audio Stream (Silent Video File D)...")
    is_vid_d = video_proc.is_video_file(file_d)
    has_aud_d = video_proc.has_audio_stream(file_d)
    print(f"  File D: is_video={is_vid_d}, has_audio={has_aud_d}")
    assert is_vid_d is True
    assert has_aud_d is False, "Silent video should not report having audio"

    vis_result_d = video_proc.analyze_presentation(file_d)
    vis_metrics_d = vis_result_d["metrics"]

    # Score silent video: speech components MUST be None, not fabricated!
    scores_silent = compute_component_scores(
        metrics={},
        findings=vis_result_d["findings"],
        transcript={},
        is_video=True,
        visual_metrics=vis_metrics_d,
        has_audio=False,
    )

    print(f"  Silent Video Overall: {scores_silent['overall']}/100")
    print(f"  Grammar Score: {scores_silent['components']['grammar']['score']} ({scores_silent['components']['grammar']['status']})")
    print(f"  Fluency Score: {scores_silent['components']['fluency']['score']} ({scores_silent['components']['fluency']['status']})")
    print(f"  Visual Score: {scores_silent['components']['visual_presentation']['score']}")

    assert scores_silent["components"]["grammar"]["score"] is None, "Speech score was fabricated for silent video!"
    assert scores_silent["components"]["fluency"]["score"] is None, "Fluency score was fabricated for silent video!"
    assert scores_silent["components"]["vocal_delivery"]["score"] is None, "Vocal score was fabricated for silent video!"
    assert scores_silent["has_audio"] is False
    print("  -> PASS: Missing audio track handled gracefully without fabricating speech scores.")
    passed_checks += 1

    # -------------------------------------------------------------------------
    # Check 7: LLM Explainer does not invent scores or alter evidence
    # -------------------------------------------------------------------------
    total_checks += 1
    print("\n[CHECK 7] LLM Explainer Grounding Verification...")
    test_finding = [{
        "id": "test_flaw_1",
        "category": "speaking_too_fast",
        "start_time": 1.2,
        "end_time": 4.5,
        "severity": "medium",
        "confidence": 0.82,
        "evidence": {
            "metric_name": "syllable_rate",
            "measured_value": 6.2,
            "threshold": 5.0,
            "unit": "syllables/sec",
        },
        "description": "Speaking rate is rushed at 6.2 syllables/sec.",
        "suggestion": "Slow down your cadence.",
    }]

    enriched = llm_exp.explain_findings(test_finding, "Test transcript", {})
    item = enriched[0]
    print(f"  Explanation: {item['explanation']}")
    print(f"  Recommendation: {item['recommendation']}")

    assert "6.2" in item["explanation"], "Measured evidence value not grounded in explanation"
    assert "syllables/sec" in item["explanation"]
    assert "score" not in item or item["score"] == test_finding[0].get("score"), "LLM should not invent numerical scores"
    print("  -> PASS: Explanations are strictly grounded in acoustic evidence without inventing numbers.")
    passed_checks += 1

    # Cleanup test scratch files
    shutil.rmtree(test_dir, ignore_errors=True)

    print("\n" + "=" * 75)
    print(f"AUDIT COMPLETE: {passed_checks}/{total_checks} CHECKS PASSED (100% SUCCESS)")
    print("=" * 75)
    return True


if __name__ == "__main__":
    success = run_full_audit()
    sys.exit(0 if success else 1)
