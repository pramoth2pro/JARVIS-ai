"""Video presentation processing module.
Extracts video frames and computes visual-presentation metrics:
- Lighting / Exposure stability & contrast
- Subject motion & movement steadiness / camera stability
- Framing presence & centering
- Timestamped visual flaw detection synchronized with audio findings
"""

import logging
import os
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)

VIDEO_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".flv", ".wmv", ".m4v"}


class VideoProcessor:
    """Processes video frames for presentation metrics and visual flaw detection."""

    def __init__(self, target_fps: float = 1.0, frame_width: int = 320, frame_height: int = 240):
        self.target_fps = target_fps
        self.frame_width = frame_width
        self.frame_height = frame_height

    def _get_ffmpeg_bin(self) -> str:
        """Get path to static FFmpeg binary."""
        try:
            import imageio_ffmpeg
            return imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            return "ffmpeg"

    def is_video_file(self, file_path: str) -> bool:
        """Check whether the given path corresponds to a supported video container."""
        ext = Path(file_path).suffix.lower()
        if ext in VIDEO_EXTENSIONS:
            return True

        # Probe container if extension is generic
        try:
            ffmpeg_bin = self._get_ffmpeg_bin()
            cmd = [ffmpeg_bin, "-i", str(file_path)]
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            _, err = proc.communicate(timeout=5)
            err_text = err.decode("utf-8", errors="ignore")
            return "Video:" in err_text
        except Exception:
            return False

    def has_audio_stream(self, file_path: str) -> bool:
        """Check if media file contains at least one valid audio stream."""
        try:
            ffmpeg_bin = self._get_ffmpeg_bin()
            cmd = [ffmpeg_bin, "-i", str(file_path)]
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            _, err = proc.communicate(timeout=5)
            err_text = err.decode("utf-8", errors="ignore")
            return "Audio:" in err_text
        except Exception as e:
            logger.warning(f"Failed to probe audio stream with ffmpeg: {e}")
            return True

    def extract_frames(self, video_path: str) -> Tuple[List[np.ndarray], List[float]]:
        """
        Extract video frames at target_fps scaled to (frame_width x frame_height) in RGB24.
        Returns:
            frames: list of uint8 numpy arrays of shape (frame_height, frame_width, 3)
            timestamps: list of float seconds for each frame
        """
        video_file = Path(video_path).resolve()
        if not video_file.exists():
            raise FileNotFoundError(f"Video file not found: {video_path}")

        ffmpeg_bin = self._get_ffmpeg_bin()
        cmd = [
            ffmpeg_bin,
            "-y",
            "-i", str(video_file),
            "-vf", f"fps={self.target_fps},scale={self.frame_width}:{self.frame_height}",
            "-f", "rawvideo",
            "-pix_fmt", "rgb24",
            "pipe:1",
        ]

        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            raw_data, err_data = proc.communicate()
            if proc.returncode != 0 and len(raw_data) == 0:
                logger.warning(f"FFmpeg frame extraction returned code {proc.returncode}: {err_data.decode('utf-8', errors='ignore')}")
                return [], []

            frame_size = self.frame_width * self.frame_height * 3
            n_frames = len(raw_data) // frame_size

            frames: List[np.ndarray] = []
            timestamps: List[float] = []

            for i in range(n_frames):
                start = i * frame_size
                end = start + frame_size
                frame_arr = np.frombuffer(raw_data[start:end], dtype=np.uint8).reshape(
                    (self.frame_height, self.frame_width, 3)
                )
                frames.append(frame_arr)
                timestamps.append(round(i / self.target_fps, 2))

            return frames, timestamps

        except Exception as e:
            logger.error(f"Error extracting video frames from {video_path}: {e}")
            return [], []

    def analyze_presentation(self, video_path: str) -> Dict[str, Any]:
        """
        Perform complete visual presentation analysis on video frames.
        Returns visual metrics dictionary and timestamped visual flaw findings.
        """
        if not self.is_video_file(video_path):
            return {
                "is_video": False,
                "metrics": {},
                "findings": [],
            }

        frames, timestamps = self.extract_frames(video_path)

        if not frames:
            return {
                "is_video": True,
                "metrics": {
                    "frame_count": 0,
                    "duration_seconds": 0.0,
                    "lighting_stability": 0.0,
                    "average_brightness": 0.0,
                    "motion_stability": 0.0,
                    "framing_stability": 0.0,
                },
                "findings": [{
                    "id": "visual_no_frames",
                    "category": "video_read_error",
                    "start_time": 0.0,
                    "end_time": 1.0,
                    "severity": "medium",
                    "confidence": 0.90,
                    "evidence": {
                        "metric_name": "extracted_frames",
                        "measured_value": 0,
                        "threshold": 1,
                        "unit": "frames",
                    },
                    "description": "Could not decode video frames from uploaded container.",
                    "suggestion": "Verify that your video is encoded in standard H.264 or MP4 format.",
                }],
            }

        duration = timestamps[-1] if timestamps else 0.0
        n = len(frames)

        # 1. Luminance & Lighting Analysis
        brightness_series: List[float] = []
        contrast_series: List[float] = []
        center_energy_series: List[float] = []

        h, w = self.frame_height, self.frame_width
        y1, y2 = int(0.2 * h), int(0.8 * h)
        x1, x2 = int(0.2 * w), int(0.8 * w)

        for frame in frames:
            # Grayscale conversion: Y = 0.299R + 0.587G + 0.114B
            gray = 0.299 * frame[:, :, 0] + 0.587 * frame[:, :, 1] + 0.114 * frame[:, :, 2]
            mean_lum = float(np.mean(gray))
            std_lum = float(np.std(gray))
            brightness_series.append(mean_lum)
            contrast_series.append(std_lum)

            # Center presence: proportion of image energy/variance in the central 60% box
            center_crop = gray[y1:y2, x1:x2]
            center_std = float(np.std(center_crop))
            center_energy_series.append(center_std)

        avg_brightness = float(np.mean(brightness_series)) if brightness_series else 0.0
        std_brightness = float(np.std(brightness_series)) if brightness_series else 0.0
        avg_contrast = float(np.mean(contrast_series)) if contrast_series else 0.0

        # Lighting stability score (0 - 100): 100 is perfectly stable lighting
        brightness_cv = (std_brightness / avg_brightness) if avg_brightness > 0 else 1.0
        lighting_stability = max(10.0, min(100.0, round((1.0 - min(1.0, brightness_cv * 2.0)) * 100.0, 1)))

        # 2. Inter-Frame Motion Analysis (Mean Absolute Difference)
        motion_series: List[float] = [0.0]
        for i in range(1, n):
            prev_gray = 0.299 * frames[i - 1][:, :, 0] + 0.587 * frames[i - 1][:, :, 1] + 0.114 * frames[i - 1][:, :, 2]
            curr_gray = 0.299 * frames[i][:, :, 0] + 0.587 * frames[i][:, :, 1] + 0.114 * frames[i][:, :, 2]
            diff = float(np.mean(np.abs(curr_gray - prev_gray)))
            motion_series.append(diff)

        avg_motion = float(np.mean(motion_series)) if motion_series else 0.0
        std_motion = float(np.std(motion_series)) if motion_series else 0.0

        # Motion stability (0 - 100): penalize extreme jerkiness or chaotic swings
        motion_cv = (std_motion / avg_motion) if avg_motion > 0 else 0.0
        motion_stability = max(15.0, min(100.0, round((1.0 - min(1.0, motion_cv * 0.7)) * 100.0, 1)))

        # 3. Framing stability
        # Percentage of frames where central subject region has good contrast/presence
        good_framing_count = sum(1 for c in center_energy_series if c >= 15.0)
        framing_stability = round((good_framing_count / max(1, n)) * 100.0, 1)

        # 4. Detect Visual Presentation Flaws
        findings: List[Dict[str, Any]] = []

        # A. Poor Lighting: Dark / Underexposed
        dark_clusters = self._find_contiguous_intervals(
            [b < 45.0 for b in brightness_series],
            timestamps,
            min_duration=2.0,
        )
        for c in dark_clusters:
            dur = c["end"] - c["start"]
            sub_lum = [brightness_series[i] for i in range(c["start_idx"], c["end_idx"] + 1)]
            val = round(float(np.mean(sub_lum)), 1)
            sev = "high" if val < 25.0 else "medium" if val < 38.0 else "low"
            findings.append({
                "category": "poor_lighting_dark",
                "start_time": round(c["start"], 2),
                "end_time": round(c["end"], 2),
                "severity": sev,
                "confidence": min(0.95, round(0.75 + (45.0 - val) * 0.005, 3)),
                "evidence": {
                    "metric_name": "mean_luminance",
                    "measured_value": val,
                    "threshold": 45.0,
                    "unit": "IRE (0-255)",
                },
                "description": f"Video frame illumination is underexposed at {val}/255 for {round(dur, 1)}s.",
                "suggestion": "Position a key light or soft lamp in front of your face to enhance facial visibility.",
            })

        # B. Poor Lighting: Glare / Overexposed
        glare_clusters = self._find_contiguous_intervals(
            [b > 225.0 for b in brightness_series],
            timestamps,
            min_duration=2.0,
        )
        for c in glare_clusters:
            dur = c["end"] - c["start"]
            sub_lum = [brightness_series[i] for i in range(c["start_idx"], c["end_idx"] + 1)]
            val = round(float(np.mean(sub_lum)), 1)
            findings.append({
                "category": "poor_lighting_glare",
                "start_time": round(c["start"], 2),
                "end_time": round(c["end"], 2),
                "severity": "medium",
                "confidence": 0.88,
                "evidence": {
                    "metric_name": "mean_luminance",
                    "measured_value": val,
                    "threshold": 225.0,
                    "unit": "IRE (0-255)",
                },
                "description": f"Harsh glare or overexposure detected ({val}/255) washing out facial features.",
                "suggestion": "Diffuse direct background light or lower camera exposure to avoid harsh blowouts.",
            })

        # C. Camera Shake / Erratic Motion
        motion_threshold = max(28.0, avg_motion * 2.5)
        shake_clusters = self._find_contiguous_intervals(
            [m > motion_threshold for m in motion_series],
            timestamps,
            min_duration=1.5,
        )
        for c in shake_clusters:
            dur = c["end"] - c["start"]
            sub_m = [motion_series[i] for i in range(c["start_idx"], c["end_idx"] + 1)]
            peak_m = round(float(np.max(sub_m)), 1)
            sev = "high" if peak_m > 45.0 else "medium"
            findings.append({
                "category": "excessive_camera_shake",
                "start_time": round(c["start"], 2),
                "end_time": round(c["end"], 2),
                "severity": sev,
                "confidence": 0.85,
                "evidence": {
                    "metric_name": "inter_frame_motion",
                    "measured_value": peak_m,
                    "threshold": round(motion_threshold, 1),
                    "unit": "MAE delta",
                },
                "description": f"Excessive camera jitter or erratic body movement detected (motion delta {peak_m}).",
                "suggestion": "Mount the camera on a stable tripod or stand and maintain a centered anchor position.",
            })

        # Downsample series for compact storage
        step = max(1, n // 200)
        compact_timestamps = [timestamps[i] for i in range(0, n, step)]
        compact_brightness = [round(brightness_series[i], 1) for i in range(0, n, step)]
        compact_motion = [round(motion_series[i], 2) for i in range(0, n, step)]

        metrics = {
            "frame_count": n,
            "duration_seconds": round(duration, 2),
            "average_brightness": round(avg_brightness, 1),
            "brightness_std": round(std_brightness, 1),
            "lighting_stability": lighting_stability,
            "average_contrast": round(avg_contrast, 1),
            "average_motion": round(avg_motion, 2),
            "motion_stability": motion_stability,
            "framing_stability": framing_stability,
            "time_series": {
                "times": compact_timestamps,
                "brightness": compact_brightness,
                "motion": compact_motion,
            },
        }

        return {
            "is_video": True,
            "metrics": metrics,
            "findings": findings,
        }

    def _find_contiguous_intervals(
        self,
        flags: List[bool],
        timestamps: List[float],
        min_duration: float = 1.0,
    ) -> List[Dict[str, Any]]:
        """Helper to find contiguous True flag runs satisfying min_duration."""
        intervals: List[Dict[str, Any]] = []
        n = len(flags)
        in_run = False
        start_idx = 0

        for i, val in enumerate(flags):
            if val and not in_run:
                in_run = True
                start_idx = i
            elif not val and in_run:
                in_run = False
                end_idx = i - 1
                dur = timestamps[end_idx] - timestamps[start_idx]
                if dur >= min_duration:
                    intervals.append({
                        "start": timestamps[start_idx],
                        "end": timestamps[end_idx],
                        "start_idx": start_idx,
                        "end_idx": end_idx,
                    })

        if in_run:
            end_idx = n - 1
            dur = timestamps[end_idx] - timestamps[start_idx]
            if dur >= min_duration:
                intervals.append({
                    "start": timestamps[start_idx],
                    "end": timestamps[end_idx],
                    "start_idx": start_idx,
                    "end_idx": end_idx,
                })

        return intervals
