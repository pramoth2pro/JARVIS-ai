"""Application configuration module using Pydantic Settings."""

import os
from functools import lru_cache
from pathlib import Path
from typing import List, Literal

# Ensure FFmpeg binary from imageio-ffmpeg is on system PATH
try:
    import imageio_ffmpeg
    ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
    ffmpeg_dir = os.path.dirname(ffmpeg_exe)
    if ffmpeg_dir not in os.environ.get("PATH", ""):
        os.environ["PATH"] = ffmpeg_dir + os.pathsep + os.environ.get("PATH", "")
except Exception:
    pass

try:
    from pydantic_settings import BaseSettings, SettingsConfigDict
    USE_PYDANTIC_SETTINGS = True
except ImportError:  # pragma: no cover
    try:
        from pydantic import BaseSettings
        USE_PYDANTIC_SETTINGS = False
    except ImportError:
        # Fallback minimal implementation if pydantic is not yet installed
        class BaseSettings:  # type: ignore
            def __init__(self, **kwargs):
                for k, v in kwargs.items():
                    setattr(self, k, v)
        USE_PYDANTIC_SETTINGS = False


class Settings(BaseSettings):
    """Runtime application settings loaded from environment or .env file."""

    OPENAI_API_KEY: str = ""
    LLM_PROVIDER: Literal["openai", "fallback"] = "fallback"
    LLM_MODEL: str = "gpt-4o-mini"
    MAX_UPLOAD_MB: int = 100
    UPLOAD_DIR: str = "./uploads"
    DB_PATH: str = "./jarvis.db"
    CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:8000",
    ]

    if USE_PYDANTIC_SETTINGS:
        model_config = SettingsConfigDict(
            env_file=os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env"),
            env_file_encoding="utf-8",
            extra="ignore",
        )
    else:
        class Config:
            env_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env")
            env_file_encoding = "utf-8"
            extra = "ignore"

    @property
    def upload_path(self) -> Path:
        """Return resolved Path object for upload directory."""
        path = Path(self.UPLOAD_DIR).resolve()
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def db_file_path(self) -> Path:
        """Return resolved Path object for sqlite database."""
        path = Path(self.DB_PATH).resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def max_upload_bytes(self) -> int:
        """Maximum upload size in bytes."""
        return self.MAX_UPLOAD_MB * 1024 * 1024


@lru_cache()
def get_settings() -> Settings:
    """Return cached Settings instance."""
    return Settings()
