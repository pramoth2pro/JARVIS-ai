"""Deterministic, evidence-grounded scoring engine for JARVIS speech intelligence.

Calculates independent component scores:
1. Grammar & Syntactic Cohesion
2. Fluency & Articulation
3. Pace & Rhythm
4. Vocal Delivery & Dynamics
5. Visual Presentation (for video uploads)
6. Documented Overall JARVIS Score & Letter Grade

All scores are strictly calculated from physical acoustic & visual measurements
and model alignments according to documented mathematical formulas.
The LLM is NEVER permitted to invent numerical scores or metrics.
"""

import math
from typing import Any, Dict, List, Optional


def compute_component_scores(
    metrics: Dict[str, Any],
    findings: List[Dict[str, Any]],
    transcript: Dict[str, Any],
    is_video: bool = False,
    visual_metrics: Optional[Dict[str, Any]] = None,
    has_audio: bool = True,
) -> Dict[str, Any]:
    """
    Compute deterministic speech intelligence scores.

    Returns:
        {
            "overall": float (0-100),
            "grade": str ("A+", "A", "B+", "B", "C", "Needs Work"),
            "is_video": bool,
            "has_audio": bool,
            "components": {
                "grammar": {...},
                "fluency": {...},
                "pace": {...},
                "vocal_delivery": {...},
                "visual_presentation": {...}
            },
            "scoring_formula": str
        }
    """
    duration = float(metrics.get("duration", 0.0))
    if duration <= 0.0 and visual_metrics:
        duration = float(visual_metrics.get("duration_seconds", 0.0))

    words = transcript.get("words", []) if transcript else []
    total_words = len(words)

    # -------------------------------------------------------------------------
    # 1. Grammar & Syntactic Cohesion Score (S_grammar)
    # -------------------------------------------------------------------------
    if not has_audio or (total_words == 0 and duration > 3.0):
        if not has_audio:
            grammar_score = None
            grammar_grade = "N/A"
            grammar_status = "unavailable_no_audio"
            grammar_evidence = {"reason": "Audio stream missing from media file"}
        else:
            grammar_score = 50.0
            grammar_grade = "Needs Work"
            grammar_status = "poor"
            grammar_evidence = {"reason": "No intelligible spoken words recognized in recording"}
    else:
        # Base: 100.0
        grammar_deductions = 0.0

        # Mid-sentence awkward pauses break syntactic constituent flow
        awkward_pauses = [f for f in findings if f.get("category") == "awkward_pause"]
        for ap in awkward_pauses:
            sev = ap.get("severity", "medium")
            if sev == "high":
                grammar_deductions += 10.0
            elif sev == "medium":
                grammar_deductions += 6.0
            else:
                grammar_deductions += 3.0

        # Inconsistent volume mid-sentence breaks
        inconsistent_vol = [f for f in findings if f.get("category") == "inconsistent_volume"]
        for iv in inconsistent_vol:
            sev = iv.get("severity", "medium")
            if sev == "high":
                grammar_deductions += 7.0
            elif sev == "medium":
                grammar_deductions += 4.0
            else:
                grammar_deductions += 2.0

        raw_grammar = 100.0 - grammar_deductions
        grammar_score = round(max(10.0, min(100.0, raw_grammar)), 1)
        grammar_grade = _score_to_grade(grammar_score)
        grammar_status = "good" if grammar_score >= 80.0 else "warning" if grammar_score >= 65.0 else "poor"
        grammar_evidence = {
            "awkward_pauses_count": len(awkward_pauses),
            "inconsistent_volume_breaks": len(inconsistent_vol),
            "total_words_analyzed": total_words,
            "deductions_applied": round(grammar_deductions, 1),
        }

    # -------------------------------------------------------------------------
    # 2. Fluency & Articulation Score (S_fluency)
    # -------------------------------------------------------------------------
    if not has_audio:
        fluency_score = None
        fluency_grade = "N/A"
        fluency_status = "unavailable_no_audio"
        fluency_evidence = {"reason": "Audio stream missing"}
    else:
        fluency_deductions = 0.0

        # Measure filler words per minute
        filler_findings = [f for f in findings if "filler" in f.get("category", "").lower()]
        filler_count = len(filler_findings)
        active_minutes = max(0.1, duration / 60.0)
        filler_rate_per_min = round(filler_count / active_minutes, 2)

        if filler_rate_per_min > 3.0:
            fluency_deductions += min(45.0, 16.0 + (filler_rate_per_min - 3.0) * 12.0)
        elif filler_rate_per_min > 1.0:
            fluency_deductions += (filler_rate_per_min - 1.0) * 8.0

        # Long pauses (> 2.0s) duration ratio
        long_pauses = [f for f in findings if f.get("category") == "long_pause"]
        total_long_pause_sec = sum(
            float(f.get("evidence", {}).get("measured_value", 0.0)) for f in long_pauses
        )
        pause_ratio = (total_long_pause_sec / max(1.0, duration))
        pause_deduction = min(35.0, pause_ratio * 100.0 * 1.2)
        fluency_deductions += pause_deduction

        raw_fluency = 100.0 - fluency_deductions
        fluency_score = round(max(10.0, min(100.0, raw_fluency)), 1)
        fluency_grade = _score_to_grade(fluency_score)
        fluency_status = "good" if fluency_score >= 80.0 else "warning" if fluency_score >= 65.0 else "poor"
        fluency_evidence = {
            "filler_count": filler_count,
            "filler_rate_per_min": filler_rate_per_min,
            "long_pause_count": len(long_pauses),
            "total_long_pause_sec": round(total_long_pause_sec, 2),
            "pause_ratio_percent": round(pause_ratio * 100.0, 1),
            "deductions_applied": round(fluency_deductions, 1),
        }

    # -------------------------------------------------------------------------
    # 3. Pace & Rhythm Score (S_pace)
    # -------------------------------------------------------------------------
    if not has_audio:
        pace_score = None
        pace_grade = "N/A"
        pace_status = "unavailable_no_audio"
        pace_evidence = {"reason": "Audio stream missing"}
    else:
        speaking_rate_info = metrics.get("speaking_rate", {})
        overall_rate = float(
            speaking_rate_info.get("overall_syl_per_sec")
            or speaking_rate_info.get("overall")
            or 0.0
        )

        pace_deductions = 0.0

        if overall_rate <= 0.3:
            # Silent or near silent recording
            pace_score = 10.0
            pace_grade = "Needs Work"
            pace_status = "poor"
            pace_evidence = {
                "overall_rate_syl_per_sec": overall_rate,
                "reason": "Near-zero syllable rate detected across audio duration",
            }
        else:
            # Optimal human speech delivery: 3.5 to 4.8 syllables/sec
            if overall_rate > 4.8:
                pace_deductions += min(45.0, (overall_rate - 4.8) * 22.0)
            elif overall_rate < 3.5:
                pace_deductions += min(45.0, (3.5 - overall_rate) * 18.0)

            # Local tempo violations
            rate_flaws = [
                f for f in findings
                if f.get("category") in {"speaking_too_fast", "speaking_too_slow"}
            ]
            pace_deductions += min(25.0, len(rate_flaws) * 4.0)

            raw_pace = 100.0 - pace_deductions
            pace_score = round(max(10.0, min(100.0, raw_pace)), 1)
            pace_grade = _score_to_grade(pace_score)
            pace_status = "good" if pace_score >= 80.0 else "warning" if pace_score >= 65.0 else "poor"
            pace_evidence = {
                "overall_rate_syl_per_sec": round(overall_rate, 2),
                "target_range": "3.5 - 4.8 syl/s",
                "rate_flaws_count": len(rate_flaws),
                "deductions_applied": round(pace_deductions, 1),
            }

    # -------------------------------------------------------------------------
    # 4. Vocal Delivery & Dynamics Score (S_vocal)
    # -------------------------------------------------------------------------
    if not has_audio:
        vocal_score = None
        vocal_grade = "N/A"
        vocal_status = "unavailable_no_audio"
        vocal_evidence = {"reason": "Audio stream missing"}
    else:
        vocal_deductions = 0.0
        pitch_info = metrics.get("pitch", {})
        std_f0 = float(pitch_info.get("std_f0") or pitch_info.get("std") or 0.0)
        mean_f0 = float(pitch_info.get("mean_f0") or pitch_info.get("mean") or 0.0)

        # Monotone penalty: optimal pitch variation std is 20 Hz to 55 Hz
        if std_f0 > 0.0 and std_f0 < 20.0:
            vocal_deductions += min(30.0, (20.0 - std_f0) * 2.0)
        elif std_f0 > 55.0:
            vocal_deductions += min(20.0, (std_f0 - 55.0) * 0.8)

        # RMS Energy Consistency
        rms_info = metrics.get("rms", {})
        rms_mean = float(rms_info.get("mean_rms") or 0.0)
        rms_std = float(rms_info.get("std_rms") or 0.0)
        if rms_mean > 0.0:
            cv_rms = rms_std / rms_mean
            if cv_rms > 0.50:
                vocal_deductions += min(25.0, (cv_rms - 0.50) * 40.0)
        else:
            cv_rms = 1.0

        # Pitch spikes / register cracks
        pitch_spikes = [f for f in findings if f.get("category") == "pitch_spike"]
        for ps in pitch_spikes:
            sev = ps.get("severity", "medium")
            vocal_deductions += 8.0 if sev == "high" else 4.0 if sev == "medium" else 2.0

        # Low energy / mumbling
        mumbles = [f for f in findings if f.get("category") == "low_energy"]
        vocal_deductions += min(20.0, len(mumbles) * 5.0)

        # Vocal fry
        vocal_fries = [f for f in findings if f.get("category") == "vocal_fry"]
        vocal_deductions += min(20.0, len(vocal_fries) * 4.0)

        raw_vocal = 100.0 - vocal_deductions
        vocal_score = round(max(10.0, min(100.0, raw_vocal)), 1)
        vocal_grade = _score_to_grade(vocal_score)
        vocal_status = "good" if vocal_score >= 80.0 else "warning" if vocal_score >= 65.0 else "poor"
        vocal_evidence = {
            "mean_f0_hz": round(mean_f0, 1),
            "std_f0_hz": round(std_f0, 1),
            "rms_coefficient_of_variation": round(cv_rms, 2),
            "pitch_spikes_count": len(pitch_spikes),
            "mumble_segments_count": len(mumbles),
            "vocal_fry_count": len(vocal_fries),
            "deductions_applied": round(vocal_deductions, 1),
        }

    # -------------------------------------------------------------------------
    # 5. Visual Presentation Score (S_visual) - Video uploads only
    # -------------------------------------------------------------------------
    visual_score: Optional[float] = None
    visual_grade = "N/A"
    visual_status = "audio_only"
    visual_evidence: Dict[str, Any] = {}

    if is_video and visual_metrics:
        frame_count = int(visual_metrics.get("frame_count", 0))
        if frame_count > 0:
            vis_deductions = 0.0
            avg_brightness = float(visual_metrics.get("average_brightness", 100.0))
            lighting_stability = float(visual_metrics.get("lighting_stability", 85.0))
            motion_stability = float(visual_metrics.get("motion_stability", 85.0))
            framing_stability = float(visual_metrics.get("framing_stability", 80.0))

            # Lighting range penalty: target [70, 175]
            if avg_brightness < 70.0:
                vis_deductions += min(25.0, (70.0 - avg_brightness) * 0.5)
            elif avg_brightness > 180.0:
                vis_deductions += min(25.0, (avg_brightness - 180.0) * 0.5)

            # Instability deductions
            if lighting_stability < 75.0:
                vis_deductions += (75.0 - lighting_stability) * 0.6
            if motion_stability < 75.0:
                vis_deductions += (75.0 - motion_stability) * 0.6
            if framing_stability < 60.0:
                vis_deductions += (60.0 - framing_stability) * 0.4

            # Visual findings penalty
            vis_flaws = [
                f for f in findings
                if f.get("category") in {
                    "poor_lighting_dark",
                    "poor_lighting_glare",
                    "excessive_camera_shake",
                    "static_visual_freeze",
                }
            ]
            vis_deductions += min(25.0, len(vis_flaws) * 5.0)

            raw_visual = 100.0 - vis_deductions
            visual_score = round(max(10.0, min(100.0, raw_visual)), 1)
            visual_grade = _score_to_grade(visual_score)
            visual_status = "good" if visual_score >= 80.0 else "warning" if visual_score >= 65.0 else "poor"
            visual_evidence = {
                "frames_analyzed": frame_count,
                "average_brightness": avg_brightness,
                "lighting_stability_pct": lighting_stability,
                "motion_stability_pct": motion_stability,
                "framing_stability_pct": framing_stability,
                "visual_flaws_count": len(vis_flaws),
                "deductions_applied": round(vis_deductions, 1),
            }

    # -------------------------------------------------------------------------
    # 6. Overall Weighted Score Calculation
    # -------------------------------------------------------------------------
    if not has_audio:
        # Video with missing audio: score based strictly on visual presentation
        if visual_score is not None:
            overall_score = visual_score
            formula = "Overall = Visual Presentation (Audio unavailable)"
        else:
            overall_score = 0.0
            formula = "Overall = 0.0 (No valid streams decoded)"
    elif is_video and visual_score is not None:
        # Video with audio track: 5 components
        # Grammar: 15%, Fluency: 25%, Pace: 20%, Vocal: 25%, Visual: 15%
        overall_score = (
            0.15 * (grammar_score or 50.0)
            + 0.25 * (fluency_score or 50.0)
            + 0.20 * (pace_score or 50.0)
            + 0.25 * (vocal_score or 50.0)
            + 0.15 * visual_score
        )
        formula = "Overall = 0.15*Grammar + 0.25*Fluency + 0.20*Pace + 0.25*Vocal + 0.15*Visual"
    else:
        # Audio-only: 4 speech components (weights re-normalized to 1.0)
        # Grammar: 20%, Fluency: 30%, Pace: 25%, Vocal: 25%
        overall_score = (
            0.20 * (grammar_score or 50.0)
            + 0.30 * (fluency_score or 50.0)
            + 0.25 * (pace_score or 50.0)
            + 0.25 * (vocal_score or 50.0)
        )
        formula = "Overall = 0.20*Grammar + 0.30*Fluency + 0.25*Pace + 0.25*Vocal"

    overall_score = round(max(10.0, min(100.0, overall_score)), 1)
    overall_grade = _score_to_grade(overall_score)

    return {
        "overall": overall_score,
        "grade": overall_grade,
        "is_video": is_video,
        "has_audio": has_audio,
        "components": {
            "grammar": {
                "score": grammar_score,
                "weight": 0.15 if is_video and visual_score is not None else 0.20,
                "grade": grammar_grade,
                "status": grammar_status,
                "evidence": grammar_evidence,
            },
            "fluency": {
                "score": fluency_score,
                "weight": 0.25 if is_video and visual_score is not None else 0.30,
                "grade": fluency_grade,
                "status": fluency_status,
                "evidence": fluency_evidence,
            },
            "pace": {
                "score": pace_score,
                "weight": 0.20 if is_video and visual_score is not None else 0.25,
                "grade": pace_grade,
                "status": pace_status,
                "evidence": pace_evidence,
            },
            "vocal_delivery": {
                "score": vocal_score,
                "weight": 0.25,
                "grade": vocal_grade,
                "status": vocal_status,
                "evidence": vocal_evidence,
            },
            "visual_presentation": {
                "score": visual_score,
                "weight": 0.15 if is_video and visual_score is not None else 0.0,
                "grade": visual_grade,
                "status": visual_status,
                "evidence": visual_evidence,
            },
        },
        "scoring_formula": formula,
    }


def _score_to_grade(score: Optional[float]) -> str:
    """Deterministic conversion of 0-100 score to executive letter grade."""
    if score is None:
        return "N/A"
    if score >= 90.0:
        return "A+"
    if score >= 80.0:
        return "A"
    if score >= 70.0:
        return "B+"
    if score >= 60.0:
        return "B"
    if score >= 50.0:
        return "C"
    return "Needs Work"
