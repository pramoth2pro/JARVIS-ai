"""Acoustic and linguistic flaw detection engine for speech coaching."""

import logging
import re
import uuid
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)

# Standard filler words and multi-word phrases to detect
FILLER_PATTERNS = [
    r"\bum\b",
    r"\buh\b",
    r"\ber\b",
    r"\bah\b",
    r"\blike\b",
    r"\byou know\b",
    r"\bbasically\b",
    r"\bactually\b",
    r"\bkind of\b",
    r"\bsort of\b",
    r"\bi mean\b",
    r"\bright\b",
    r"\bso\b",
]


class FlawDetector:
    """Detects 10 speech flaws based on acoustic metrics and transcript alignment."""

    def __init__(self):
        pass

    def detect_flaws(
        self,
        transcript: Dict[str, Any],
        features: Dict[str, Any],
        audio_path: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Analyze audio features and transcript to detect 10 acoustic/linguistic flaws:
        1. Speaking too fast (> 5 syl/s)
        2. Speaking too slow (< 2 syl/s)
        3. Long pauses (> 2 seconds)
        4. Awkward pauses (mid-sentence)
        5. Monotone delivery (pitch std dev < 10 Hz over 3+ seconds)
        6. Pitch spikes (> 100 Hz jump between adjacent frames)
        7. Low energy / mumbling (< 20% of mean RMS for > 1s)
        8. Filler words ('um', 'uh', 'like', etc.)
        9. Vocal fry (low F0 + irregular pitch pattern)
        10. Inconsistent volume (large RMS variance within sentences)
        """
        flaws: List[Dict[str, Any]] = []

        try:
            # 1 & 2: Speaking rate anomalies
            flaws.extend(self._detect_speaking_rate_flaws(features))

            # 3 & 4: Pause anomalies
            flaws.extend(self._detect_pause_flaws(features, transcript))

            # 5 & 6: Pitch delivery anomalies (monotone & pitch spikes)
            flaws.extend(self._detect_pitch_flaws(features))

            # 7: Low energy / mumbling
            flaws.extend(self._detect_low_energy(features))

            # 8: Filler words
            flaws.extend(self._detect_filler_words(transcript))

            # 9: Vocal fry
            flaws.extend(self._detect_vocal_fry(features))

            # 10: Inconsistent volume
            flaws.extend(self._detect_inconsistent_volume(features, transcript))

            # Sort flaws chronologically by start_time
            flaws.sort(key=lambda x: x.get("start_time", 0.0))

            # Assign sequential deterministic IDs if needed
            for i, f in enumerate(flaws):
                f["id"] = f"flaw_{i + 1}_{f['category']}"

        except Exception as e:
            logger.error(f"Error during flaw detection: {e}", exc_info=True)

        return flaws

    # =========================================================================
    # 1 & 2: Rate Flaws
    # =========================================================================
    def _detect_speaking_rate_flaws(self, features: Dict[str, Any]) -> List[Dict[str, Any]]:
        findings: List[Dict[str, Any]] = []
        rate_info = features.get("speaking_rate", {})
        windows = rate_info.get("rate_windows", [])

        if not windows:
            return findings

        # A. Speaking too fast (> 5 syl/s)
        fast_clusters: List[List[Dict[str, Any]]] = []
        current_cluster: List[Dict[str, Any]] = []

        for win in windows:
            if win["rate"] > 5.0:
                current_cluster.append(win)
            else:
                if current_cluster:
                    fast_clusters.append(current_cluster)
                    current_cluster = []
        if current_cluster:
            fast_clusters.append(current_cluster)

        for cluster in fast_clusters:
            start_t = cluster[0]["start"]
            end_t = cluster[-1]["end"]
            rates = [w["rate"] for w in cluster]
            peak_rate = max(rates)
            avg_rate = sum(rates) / len(rates)

            # Severity computation based on acoustic value
            if avg_rate >= 6.8:
                severity = "high"
                confidence = min(0.98, 0.85 + (avg_rate - 6.8) * 0.05)
            elif avg_rate >= 5.8:
                severity = "medium"
                confidence = min(0.90, 0.78 + (avg_rate - 5.8) * 0.08)
            else:
                severity = "low"
                confidence = min(0.85, 0.70 + (avg_rate - 5.0) * 0.10)

            findings.append({
                "category": "speaking_too_fast",
                "start_time": round(float(start_t), 3),
                "end_time": round(float(end_t), 3),
                "severity": severity,
                "confidence": round(float(confidence), 3),
                "evidence": {
                    "metric_name": "syllable_rate",
                    "measured_value": round(float(avg_rate), 2),
                    "threshold": 5.0,
                    "unit": "syllables/sec",
                },
                "description": f"Speaking pace is rushed at {round(avg_rate, 1)} syllables/sec (recommended 3.5 - 4.5 syl/s).",
                "suggestion": "Slow down your cadence, articulate key consonants, and pause slightly between phrases.",
            })

        # B. Speaking too slow (< 2 syl/s during speech)
        slow_clusters: List[List[Dict[str, Any]]] = []
        current_cluster = []

        for win in windows:
            # Must have some syllable activity (> 0.2) to avoid purely counting silence
            if 0.2 <= win["rate"] < 2.0:
                current_cluster.append(win)
            else:
                if current_cluster:
                    slow_clusters.append(current_cluster)
                    current_cluster = []
        if current_cluster:
            slow_clusters.append(current_cluster)

        for cluster in slow_clusters:
            start_t = cluster[0]["start"]
            end_t = cluster[-1]["end"]
            rates = [w["rate"] for w in cluster]
            avg_rate = sum(rates) / len(rates)

            if avg_rate < 1.0:
                severity = "high"
                confidence = min(0.95, 0.85 + (1.0 - avg_rate) * 0.1)
            elif avg_rate < 1.5:
                severity = "medium"
                confidence = min(0.88, 0.75 + (1.5 - avg_rate) * 0.15)
            else:
                severity = "low"
                confidence = min(0.82, 0.70 + (2.0 - avg_rate) * 0.15)

            findings.append({
                "category": "speaking_too_slow",
                "start_time": round(float(start_t), 3),
                "end_time": round(float(end_t), 3),
                "severity": severity,
                "confidence": round(float(confidence), 3),
                "evidence": {
                    "metric_name": "syllable_rate",
                    "measured_value": round(float(avg_rate), 2),
                    "threshold": 2.0,
                    "unit": "syllables/sec",
                },
                "description": f"Pace is sluggish at {round(avg_rate, 1)} syllables/sec, which may cause audience disengagement.",
                "suggestion": "Energize your delivery and connect ideas smoothly to maintain conversational momentum.",
            })

        return findings

    # =========================================================================
    # 3 & 4: Pauses
    # =========================================================================
    def _detect_pause_flaws(
        self,
        features: Dict[str, Any],
        transcript: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        findings: List[Dict[str, Any]] = []
        pauses = features.get("pauses", [])
        words = transcript.get("words", [])

        for p in pauses:
            dur = float(p.get("duration", 0.0))
            p_start = float(p.get("start", 0.0))
            p_end = float(p.get("end", 0.0))

            # 3. Long Pauses (> 2.0 seconds)
            if dur > 2.0:
                if dur >= 5.0:
                    severity = "high"
                    confidence = 0.98
                elif dur >= 3.0:
                    severity = "medium"
                    confidence = 0.92
                else:
                    severity = "low"
                    confidence = 0.85

                findings.append({
                    "category": "long_pause",
                    "start_time": round(p_start, 3),
                    "end_time": round(p_end, 3),
                    "severity": severity,
                    "confidence": round(confidence, 3),
                    "evidence": {
                        "metric_name": "pause_duration",
                        "measured_value": round(dur, 2),
                        "threshold": 2.0,
                        "unit": "seconds",
                    },
                    "description": f"Extended silence lasting {round(dur, 1)} seconds interrupts the flow of speech.",
                    "suggestion": "Keep deliberate rhetorical pauses under 1.5 to 2.0 seconds to prevent awkward dead air.",
                })

            # 4. Awkward Pauses (mid-sentence pause not at punctuation boundaries)
            # Find the word immediately preceding and succeeding the pause
            if 0.5 <= dur <= 2.0 and words:
                preceding_words = [w for w in words if w["end"] <= p_start + 0.15]
                succeeding_words = [w for w in words if w["start"] >= p_end - 0.15]

                if preceding_words and succeeding_words:
                    prev_w = preceding_words[-1]["word"].strip()
                    next_w = succeeding_words[0]["word"].strip()

                    # Check if preceding word ends with sentence punctuation
                    ends_with_punct = prev_w and prev_w[-1] in {".", "!", "?", ",", ";", ":"}

                    if not ends_with_punct:
                        if dur >= 1.4:
                            severity = "high"
                            confidence = 0.88
                        elif dur >= 0.9:
                            severity = "medium"
                            confidence = 0.82
                        else:
                            severity = "low"
                            confidence = 0.75

                        findings.append({
                            "category": "awkward_pause",
                            "start_time": round(p_start, 3),
                            "end_time": round(p_end, 3),
                            "severity": severity,
                            "confidence": round(confidence, 3),
                            "evidence": {
                                "metric_name": "mid_sentence_pause_duration",
                                "measured_value": round(dur, 2),
                                "threshold": 0.5,
                                "unit": "seconds",
                            },
                            "description": f"Awkward hesitation of {round(dur, 1)}s between '{prev_w}' and '{next_w}' breaks grammatical continuity.",
                            "suggestion": "Breathe at clause or sentence boundaries rather than halting midway through thought units.",
                        })

        return findings

    # =========================================================================
    # 5 & 6: Pitch (Monotone & Spikes)
    # =========================================================================
    def _detect_pitch_flaws(self, features: Dict[str, Any]) -> List[Dict[str, Any]]:
        findings: List[Dict[str, Any]] = []
        pitch_info = features.get("pitch", {})
        raw_f0 = pitch_info.get("_raw_f0")
        raw_times = pitch_info.get("_raw_times")

        if not raw_f0 or not raw_times or len(raw_f0) != len(raw_times):
            return findings

        # 5. Monotone delivery: segments where pitch std dev < 10 Hz over 3+ continuous seconds
        # Frame step is typically ~0.032s (512 hop at 16kHz)
        frames_per_sec = 16000 / 512
        window_size_frames = int(3.0 * frames_per_sec)
        hop_step = int(frames_per_sec)  # 1-second slide

        i = 0
        monotone_segments: List[Tuple[float, float, float]] = []

        while i + window_size_frames <= len(raw_f0):
            sub_f0 = [v for v in raw_f0[i : i + window_size_frames] if v is not None and v > 0]
            # Must have at least 60% voiced frames in window to judge pitch variability
            if len(sub_f0) >= 0.6 * window_size_frames:
                std_val = float(np.std(sub_f0))
                if std_val < 10.0:
                    start_sec = raw_times[i]
                    end_sec = raw_times[i + window_size_frames - 1]
                    monotone_segments.append((start_sec, end_sec, std_val))
            i += hop_step

        # Merge overlapping monotone segments
        if monotone_segments:
            merged = []
            curr_start, curr_end, curr_stds = (
                monotone_segments[0][0],
                monotone_segments[0][1],
                [monotone_segments[0][2]],
            )

            for seg in monotone_segments[1:]:
                if seg[0] <= curr_end + 1.0:
                    curr_end = max(curr_end, seg[1])
                    curr_stds.append(seg[2])
                else:
                    avg_std = sum(curr_stds) / len(curr_stds)
                    merged.append((curr_start, curr_end, avg_std))
                    curr_start, curr_end, curr_stds = seg[0], seg[1], [seg[2]]
            avg_std = sum(curr_stds) / len(curr_stds)
            merged.append((curr_start, curr_end, avg_std))

            for m_start, m_end, m_std in merged:
                if m_std < 5.0:
                    severity = "high"
                    confidence = 0.95
                elif m_std < 8.0:
                    severity = "medium"
                    confidence = 0.88
                else:
                    severity = "low"
                    confidence = 0.78

                findings.append({
                    "category": "monotone",
                    "start_time": round(float(m_start), 3),
                    "end_time": round(float(m_end), 3),
                    "severity": severity,
                    "confidence": round(float(confidence), 3),
                    "evidence": {
                        "metric_name": "pitch_std_dev",
                        "measured_value": round(float(m_std), 2),
                        "threshold": 10.0,
                        "unit": "Hz",
                    },
                    "description": f"Voice pitch variation is very flat (standard deviation of {round(m_std, 1)} Hz over {round(m_end - m_start, 1)}s).",
                    "suggestion": "Introduce pitch inflection on emphasized keywords to convey enthusiasm and clarity.",
                })

        # 6. Pitch spikes: sudden F0 jumps > 100 Hz between adjacent frames
        spike_frames: List[Tuple[float, float]] = []
        for idx in range(1, len(raw_f0)):
            p_prev = raw_f0[idx - 1]
            p_curr = raw_f0[idx]
            if p_prev is not None and p_curr is not None and p_prev > 0 and p_curr > 0:
                jump = abs(p_curr - p_prev)
                if jump > 100.0:
                    spike_frames.append((raw_times[idx], jump))

        # Cluster spikes within 0.5s
        if spike_frames:
            clusters: List[List[Tuple[float, float]]] = []
            curr_c = [spike_frames[0]]
            for sp in spike_frames[1:]:
                if sp[0] - curr_c[-1][0] < 0.5:
                    curr_c.append(sp)
                else:
                    clusters.append(curr_c)
                    curr_c = [sp]
            clusters.append(curr_c)

            for c in clusters:
                t_start = max(0.0, c[0][0] - 0.1)
                t_end = c[-1][0] + 0.1
                max_jump = max(x[1] for x in c)

                if max_jump >= 200.0:
                    severity = "high"
                    confidence = 0.92
                elif max_jump >= 140.0:
                    severity = "medium"
                    confidence = 0.85
                else:
                    severity = "low"
                    confidence = 0.76

                findings.append({
                    "category": "pitch_spike",
                    "start_time": round(float(t_start), 3),
                    "end_time": round(float(t_end), 3),
                    "severity": severity,
                    "confidence": round(float(confidence), 3),
                    "evidence": {
                        "metric_name": "pitch_jump",
                        "measured_value": round(float(max_jump), 1),
                        "threshold": 100.0,
                        "unit": "Hz",
                    },
                    "description": f"Uncontrolled pitch crack or spike jumping {round(max_jump, 1)} Hz abruptly.",
                    "suggestion": "Maintain supported diaphragm breath support to avoid vocal register cracking or sudden frequency instability.",
                })

        return findings

    # =========================================================================
    # 7: Low Energy / Mumbling
    # =========================================================================
    def _detect_low_energy(self, features: Dict[str, Any]) -> List[Dict[str, Any]]:
        findings: List[Dict[str, Any]] = []
        rms_info = features.get("rms", {})
        raw_rms = rms_info.get("_raw_rms")
        raw_times = rms_info.get("_raw_times")
        mean_rms = rms_info.get("mean_rms", 0.0)

        if not raw_rms or not raw_times or mean_rms <= 1e-5:
            return findings

        # Low energy threshold: < 20% of mean RMS, but > 1% to ignore true background silence/pauses
        threshold = 0.20 * mean_rms
        silence_floor = 0.01 * mean_rms

        low_frames: List[int] = []
        for i, val in enumerate(raw_rms):
            if silence_floor < val < threshold:
                low_frames.append(i)

        # Find contiguous stretches > 1.0 second (16000 / 512 ~ 31.25 frames)
        min_frames = int(1.0 * (16000 / 512))
        clusters: List[List[int]] = []
        curr_c: List[int] = []

        for idx in low_frames:
            if not curr_c or idx == curr_c[-1] + 1:
                curr_c.append(idx)
            else:
                if len(curr_c) >= min_frames:
                    clusters.append(curr_c)
                curr_c = [idx]
        if len(curr_c) >= min_frames:
            clusters.append(curr_c)

        for c in clusters:
            t_start = raw_times[c[0]]
            t_end = raw_times[c[-1]]
            dur = t_end - t_start
            avg_sub_rms = sum(raw_rms[i] for i in c) / len(c)
            ratio = avg_sub_rms / mean_rms

            if dur >= 3.5:
                severity = "high"
                confidence = 0.94
            elif dur >= 2.0:
                severity = "medium"
                confidence = 0.87
            else:
                severity = "low"
                confidence = 0.78

            findings.append({
                "category": "low_energy",
                "start_time": round(float(t_start), 3),
                "end_time": round(float(t_end), 3),
                "severity": severity,
                "confidence": round(float(confidence), 3),
                "evidence": {
                    "metric_name": "rms_ratio_to_mean",
                    "measured_value": round(float(ratio), 3),
                    "threshold": 0.20,
                    "unit": "ratio",
                },
                "description": f"Vocal intensity drops below 20% of your average volume ({round(ratio*100, 1)}% of mean) for {round(dur, 1)}s, causing mumbling.",
                "suggestion": "Project your voice from the chest and project toward the back of the room.",
            })

        return findings

    # =========================================================================
    # 8: Filler Words
    # =========================================================================
    def _detect_filler_words(self, transcript: Dict[str, Any]) -> List[Dict[str, Any]]:
        findings: List[Dict[str, Any]] = []
        words = transcript.get("words", [])

        if not words:
            # Fallback to segment-level text regex search if word timestamps missing
            segments = transcript.get("segments", [])
            for seg in segments:
                text = seg.get("text", "")
                for pattern in FILLER_PATTERNS:
                    for match in re.finditer(pattern, text, re.IGNORECASE):
                        w_match = match.group(0)
                        findings.append({
                            "category": "filler_word",
                            "start_time": round(float(seg["start"]), 3),
                            "end_time": round(float(seg["end"]), 3),
                            "severity": "medium",
                            "confidence": 0.85,
                            "evidence": {
                                "metric_name": "filler_word_detected",
                                "measured_value": w_match,
                                "threshold": "forbidden_filler",
                                "unit": "word",
                            },
                            "description": f"Filler word '{w_match}' used in speech.",
                            "suggestion": "Replace verbal crutches with a silent pause.",
                        })
            return findings

        # Check individual words and two-word combinations
        i = 0
        detected_fillers: List[Dict[str, Any]] = []

        while i < len(words):
            current_w = re.sub(r"[^\w\s]", "", words[i]["word"]).strip().lower()
            two_word = ""
            if i + 1 < len(words):
                next_w = re.sub(r"[^\w\s]", "", words[i + 1]["word"]).strip().lower()
                two_word = f"{current_w} {next_w}"

            # Check two-word phrases first
            matched = False
            for pattern in [r"^you know$", r"^kind of$", r"^sort of$", r"^i mean$"]:
                if two_word and re.match(pattern, two_word):
                    detected_fillers.append({
                        "word": two_word,
                        "start_time": words[i]["start"],
                        "end_time": words[i + 1]["end"],
                        "confidence": min(words[i].get("probability", 0.9), words[i + 1].get("probability", 0.9)),
                    })
                    i += 2
                    matched = True
                    break

            if matched:
                continue

            # Check single word fillers
            for pattern in [r"^um$", r"^uh$", r"^er$", r"^ah$", r"^like$", r"^basically$", r"^actually$", r"^right$", r"^so$"]:
                if re.match(pattern, current_w):
                    # Filter out "so" or "right" when used syntactically in compound sentences if low confidence
                    prob = float(words[i].get("probability", 0.88))
                    detected_fillers.append({
                        "word": current_w,
                        "start_time": words[i]["start"],
                        "end_time": words[i]["end"],
                        "confidence": prob,
                    })
                    break
            i += 1

        # Calculate local density for severity
        for idx, item in enumerate(detected_fillers):
            t_curr = item["start_time"]
            # Count fillers within 10 seconds window
            nearby_count = sum(1 for other in detected_fillers if abs(other["start_time"] - t_curr) <= 10.0)

            if nearby_count >= 3:
                severity = "high"
            elif nearby_count >= 2:
                severity = "medium"
            else:
                severity = "low"

            findings.append({
                "category": "filler_word",
                "start_time": round(float(item["start_time"]), 3),
                "end_time": round(float(item["end_time"]), 3),
                "severity": severity,
                "confidence": round(float(item["confidence"]), 3),
                "evidence": {
                    "metric_name": "filler_word_detected",
                    "measured_value": item["word"],
                    "threshold": "forbidden_filler",
                    "unit": "word",
                },
                "description": f"Used verbal filler '{item['word']}' which detracts from authoritative delivery.",
                "suggestion": "Embrace brief silence when gathering your next thought rather than voicing filler sounds.",
            })

        return findings

    # =========================================================================
    # 9: Vocal Fry
    # =========================================================================
    def _detect_vocal_fry(self, features: Dict[str, Any]) -> List[Dict[str, Any]]:
        findings: List[Dict[str, Any]] = []
        pitch_info = features.get("pitch", {})
        raw_f0 = pitch_info.get("_raw_f0")
        raw_times = pitch_info.get("_raw_times")

        if not raw_f0 or not raw_times:
            return findings

        # Vocal fry characteristics: F0 dropped below 80 Hz with irregular frame jitter
        fry_frames: List[int] = []
        for i in range(1, len(raw_f0)):
            f0_val = raw_f0[i]
            prev_val = raw_f0[i - 1]
            if f0_val is not None and prev_val is not None:
                if 45.0 <= f0_val <= 82.0:
                    # check local pitch jitter (aperiodicity)
                    diff = abs(f0_val - prev_val)
                    if diff > 5.0 or f0_val < 70.0:
                        fry_frames.append(i)

        # Cluster into segments of at least 0.5s duration
        min_frames = int(0.5 * (16000 / 512))
        clusters: List[List[int]] = []
        curr_c: List[int] = []

        for idx in fry_frames:
            if not curr_c or idx <= curr_c[-1] + 2:
                curr_c.append(idx)
            else:
                if len(curr_c) >= min_frames:
                    clusters.append(curr_c)
                curr_c = [idx]
        if len(curr_c) >= min_frames:
            clusters.append(curr_c)

        for c in clusters:
            t_start = raw_times[c[0]]
            t_end = raw_times[c[-1]]
            dur = t_end - t_start
            avg_f0 = sum(raw_f0[i] for i in c) / len(c)

            if dur >= 2.0:
                severity = "high"
                confidence = 0.92
            elif dur >= 1.0:
                severity = "medium"
                confidence = 0.85
            else:
                severity = "low"
                confidence = 0.78

            findings.append({
                "category": "vocal_fry",
                "start_time": round(float(t_start), 3),
                "end_time": round(float(t_end), 3),
                "severity": severity,
                "confidence": round(float(confidence), 3),
                "evidence": {
                    "metric_name": "vocal_fry_f0",
                    "measured_value": round(float(avg_f0), 1),
                    "threshold": 80.0,
                    "unit": "Hz",
                },
                "description": f"Vocal fry creak detected at low baseline frequency ({round(avg_f0, 1)} Hz) over {round(dur, 1)}s.",
                "suggestion": "Lift your pitch slightly and maintain steady breath pressure all the way through sentence endings.",
            })

        return findings

    # =========================================================================
    # 10: Inconsistent Volume
    # =========================================================================
    def _detect_inconsistent_volume(
        self,
        features: Dict[str, Any],
        transcript: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        findings: List[Dict[str, Any]] = []
        rms_info = features.get("rms", {})
        raw_rms = rms_info.get("_raw_rms")
        raw_times = rms_info.get("_raw_times")
        segments = transcript.get("segments", [])

        if not raw_rms or not raw_times or not segments:
            return findings

        times_arr = np.array(raw_times)
        rms_arr = np.array(raw_rms)

        for seg in segments:
            s_start = float(seg.get("start", 0.0))
            s_end = float(seg.get("end", 0.0))
            seg_text = seg.get("text", "")

            # Only analyze segments longer than 2 seconds
            if s_end - s_start < 2.0:
                continue

            mask = (times_arr >= s_start) & (times_arr <= s_end)
            seg_rms = rms_arr[mask]

            if len(seg_rms) < 10:
                continue

            # Exclude silence frames inside segment for accurate speech volume variance
            active_rms = seg_rms[seg_rms > 0.01]
            if len(active_rms) < 5:
                continue

            mean_val = float(np.mean(active_rms))
            std_val = float(np.std(active_rms))

            if mean_val < 1e-4:
                continue

            cv = std_val / mean_val  # Coefficient of variation

            # High CV (> 0.65) indicates unstable, swinging volume within a single sentence
            if cv > 0.65:
                if cv >= 1.10:
                    severity = "high"
                    confidence = 0.93
                elif cv >= 0.85:
                    severity = "medium"
                    confidence = 0.86
                else:
                    severity = "low"
                    confidence = 0.77

                findings.append({
                    "category": "inconsistent_volume",
                    "start_time": round(s_start, 3),
                    "end_time": round(s_end, 3),
                    "severity": severity,
                    "confidence": round(float(confidence), 3),
                    "evidence": {
                        "metric_name": "rms_coefficient_of_variation",
                        "measured_value": round(float(cv), 2),
                        "threshold": 0.65,
                        "unit": "ratio",
                    },
                    "description": f"Volume fluctuated significantly (coefficient of variation {round(cv, 2)}) across: '{seg_text[:60]}...'",
                    "suggestion": "Maintain a steady vocal output without sudden fades at the end of sentences or erratic volume bursts.",
                })

        return findings
