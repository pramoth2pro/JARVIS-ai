"""Contrastive speech dataset management and reference comparison engine."""

import json
import uuid
from typing import Any, Dict, List, Optional
from app.database import get_db

# Pre-curated contrastive dataset examples with temporal ground-truth annotations and provenance
BENCHMARK_SAMPLES = [
    {
        "id": "ds_ref_001",
        "sample_type": "reference_good",
        "speaker_id": "speaker_eval_01",
        "transcript": "Good morning everyone. Today we are launching our autonomous agent architecture. We have carefully engineered each stage for precision and reliability.",
        "duration_seconds": 9.4,
        "metrics": {
            "speaking_rate": {"overall_syl_per_sec": 4.1},
            "pitch": {"mean_f0": 132.5, "std_f0": 26.8},
            "rms": {"mean_rms": 0.048, "std_rms": 0.012},
            "pauses": [{"start": 2.1, "end": 2.7, "duration": 0.6}, {"start": 5.9, "end": 6.5, "duration": 0.6}],
        },
        "flaws": [],
        "provenance": "Controlled studio reference recording (Speaker Eval 01)",
    },
    {
        "id": "ds_flawed_001_fast",
        "sample_type": "flawed_rate",
        "speaker_id": "speaker_eval_02",
        "transcript": "Good morning everyone today we are launching our autonomous agent architecture we have carefully engineered each stage for precision and reliability.",
        "duration_seconds": 5.8,
        "metrics": {
            "speaking_rate": {"overall_syl_per_sec": 6.8},
            "pitch": {"mean_f0": 140.2, "std_f0": 21.0},
            "rms": {"mean_rms": 0.052, "std_rms": 0.018},
            "pauses": [],
        },
        "flaws": [
            {
                "id": "gt_flaw_fast_1",
                "category": "speaking_too_fast",
                "start_time": 0.0,
                "end_time": 5.8,
                "severity": "high",
                "evidence": {"metric_name": "syllable_rate", "measured_value": 6.8, "threshold": 5.0, "unit": "syl/s"},
            }
        ],
        "provenance": "Controlled acoustic stress test: excessively rushed delivery (Speaker Eval 02)",
    },
    {
        "id": "ds_flawed_002_monotone",
        "sample_type": "flawed_prosody",
        "speaker_id": "speaker_eval_03",
        "transcript": "The quarterly financial report indicates a steady trajectory across all segments of operation.",
        "duration_seconds": 6.2,
        "metrics": {
            "speaking_rate": {"overall_syl_per_sec": 3.9},
            "pitch": {"mean_f0": 118.0, "std_f0": 6.2},
            "rms": {"mean_rms": 0.041, "std_rms": 0.009},
            "pauses": [],
        },
        "flaws": [
            {
                "id": "gt_flaw_mono_1",
                "category": "monotone",
                "start_time": 0.5,
                "end_time": 5.5,
                "severity": "high",
                "evidence": {"metric_name": "pitch_std_dev", "measured_value": 6.2, "threshold": 10.0, "unit": "Hz"},
            }
        ],
        "provenance": "Controlled prosody experiment: intentionally flattened F0 contour (Speaker Eval 03)",
    },
    {
        "id": "ds_flawed_003_pauses_fillers",
        "sample_type": "flawed_fluency",
        "speaker_id": "speaker_eval_04",
        "transcript": "Um we looked into the data and like after three seconds... uh we found the problem.",
        "duration_seconds": 7.5,
        "metrics": {
            "speaking_rate": {"overall_syl_per_sec": 3.1},
            "pitch": {"mean_f0": 125.0, "std_f0": 19.5},
            "rms": {"mean_rms": 0.039, "std_rms": 0.019},
            "pauses": [{"start": 3.2, "end": 5.6, "duration": 2.4}],
        },
        "flaws": [
            {
                "id": "gt_flaw_filler_1",
                "category": "filler_word",
                "start_time": 0.1,
                "end_time": 0.5,
                "severity": "low",
                "evidence": {"metric_name": "filler_word_detected", "measured_value": "um"},
            },
            {
                "id": "gt_flaw_pause_1",
                "category": "long_pause",
                "start_time": 3.2,
                "end_time": 5.6,
                "severity": "medium",
                "evidence": {"metric_name": "pause_duration", "measured_value": 2.4, "threshold": 2.0, "unit": "seconds"},
            },
            {
                "id": "gt_flaw_filler_2",
                "category": "filler_word",
                "start_time": 5.7,
                "end_time": 6.1,
                "severity": "low",
                "evidence": {"metric_name": "filler_word_detected", "measured_value": "uh"},
            },
        ],
        "provenance": "Controlled hesitation capture with mid-sentence hesitation and fillers (Speaker Eval 04)",
    },
]


def seed_contrastive_dataset():
    """Populate database dataset_entries with reference benchmark samples."""
    db = get_db()
    table = db["dataset_entries"]

    for sample in BENCHMARK_SAMPLES:
        # Check if already seeded
        existing = list(table.rows_where("id = ?", [sample["id"]]))
        if not existing:
            table.insert({
                "id": sample["id"],
                "analysis_id": "benchmark_ref",
                "transcript": sample["transcript"],
                "speaker_id": sample["speaker_id"],
                "category": sample["sample_type"],
                "severity": "benchmark",
                "timestamps_json": json.dumps({"duration": sample["duration_seconds"]}),
                "features_json": json.dumps(sample["metrics"]),
                "provenance": sample["provenance"],
            })


def get_contrastive_samples(limit: int = 50) -> List[Dict[str, Any]]:
    """Return contrastive dataset samples for model training or benchmark comparison."""
    db = get_db()
    table = db["dataset_entries"]
    return list(table.rows_where(limit=limit))


def compare_with_reference(
    speaker_metrics: Dict[str, Any],
    speaker_transcript: str = "",
) -> Dict[str, Any]:
    """
    Compare speaker acoustic delivery against standard reference baseline.
    Returns comparison deltas, prosodic divergence, and benchmark metrics.
    """
    ref_rate = 4.2  # Ideal syllables/sec
    ref_pitch_std = 25.0  # Dynamic pitch variation Hz
    ref_pause_ratio = 0.15  # 15% pause time ideal

    spk_rate = speaker_metrics.get("speaking_rate", {}).get("overall_syl_per_sec", 0.0)
    spk_pitch_std = speaker_metrics.get("pitch", {}).get("std_f0", 0.0)
    spk_duration = speaker_metrics.get("duration", 1.0)
    pauses = speaker_metrics.get("pauses", [])
    total_pause = sum(p.get("duration", 0.0) for p in pauses)
    spk_pause_ratio = total_pause / max(1.0, spk_duration)

    rate_delta = spk_rate - ref_rate
    pitch_dyn_delta = spk_pitch_std - ref_pitch_std
    pause_delta = spk_pause_ratio - ref_pause_ratio

    return {
        "benchmark": {
            "ideal_rate_syl_per_sec": ref_rate,
            "ideal_pitch_std_hz": ref_pitch_std,
            "ideal_pause_ratio": ref_pause_ratio,
        },
        "speaker": {
            "measured_rate": round(spk_rate, 2),
            "measured_pitch_std": round(spk_pitch_std, 2),
            "measured_pause_ratio": round(spk_pause_ratio, 3),
        },
        "deltas": {
            "rate_delta": round(rate_delta, 2),
            "pitch_std_delta": round(pitch_dyn_delta, 2),
            "pause_ratio_delta": round(pause_delta, 3),
        },
        "assessment": {
            "rate_status": "Optimal" if abs(rate_delta) < 0.8 else ("Fast" if rate_delta > 0 else "Slow"),
            "inflection_status": "Dynamic" if spk_pitch_std >= 18.0 else "Flat / Monotone Tendency",
            "pause_control": "Controlled" if spk_pause_ratio <= 0.25 else "Excessive Silences",
        },
    }
