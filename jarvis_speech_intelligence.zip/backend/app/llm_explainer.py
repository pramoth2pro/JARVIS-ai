"""Speech coaching explanation engine supporting OpenAI LLM and acoustic rule-based fallback."""

import json
import logging
from typing import Any, Dict, List, Optional

import httpx

from app.config import get_settings

logger = logging.getLogger(__name__)


class LLMExplainer:
    """Enriches detected acoustic flaws with contextual explanations and actionable coaching recommendations."""

    def __init__(self):
        self.settings = get_settings()

    def explain_findings(
        self,
        findings: List[Dict[str, Any]],
        transcript: str,
        metrics: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """
        Enrich each finding with grounded 'explanation' and 'recommendation' fields.
        Tries OpenAI if configured and available, else uses rule-based fallback.
        """
        if not findings:
            return []

        use_openai = (
            self.settings.LLM_PROVIDER == "openai"
            and bool(self.settings.OPENAI_API_KEY)
            and self.settings.OPENAI_API_KEY.strip() != "your-key-here"
        )

        if use_openai:
            try:
                enriched = self._explain_with_openai(findings, transcript, metrics)
                if enriched and len(enriched) == len(findings):
                    return enriched
            except Exception as e:
                logger.warning(f"OpenAI explanation call failed; falling back to rule-based engine: {e}")

        # Always fallback cleanly if OpenAI is not configured, disabled, or fails
        return self._explain_with_fallback(findings, transcript, metrics)

    def _explain_with_fallback(
        self,
        findings: List[Dict[str, Any]],
        transcript: str,
        metrics: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """
        Rule-based generator that constructs rigorous, metric-grounded explanations
        and coaching recommendations based on the exact acoustic evidence.
        """
        enriched: List[Dict[str, Any]] = []

        for f in findings:
            item = dict(f)
            cat = item.get("category", "")
            evidence = item.get("evidence", {})
            val = evidence.get("measured_value", "N/A")
            thresh = evidence.get("threshold", "N/A")
            unit = evidence.get("unit", "")
            severity = item.get("severity", "medium")

            explanation = ""
            recommendation = ""

            if cat == "speaking_too_fast":
                explanation = (
                    f"Your speaking rate of {val} {unit} in this segment exceeds the recommended {thresh} {unit} threshold. "
                    f"At this rapid tempo ({severity} severity), listeners may struggle to retain key points."
                )
                recommendation = (
                    "Consciously insert a 0.5-second pause between thought groups and focus on articulating "
                    "the final consonants of important words."
                )

            elif cat == "speaking_too_slow":
                explanation = (
                    f"Your pace slowed to {val} {unit}, falling below the natural conversational baseline of {thresh} {unit}. "
                    f"This sluggish cadence ({severity} severity) can cause the listener's attention to wander."
                )
                recommendation = (
                    "Energize your vocal delivery and connect consecutive words within clauses to build natural rhythm."
                )

            elif cat == "long_pause":
                explanation = (
                    f"An extended silence lasting {val} {unit} was detected, exceeding the {thresh} {unit} conversational limit. "
                    f"Extended dead air disrupts engagement and suggests hesitation."
                )
                recommendation = (
                    "Limit intentional rhetorical pauses to 1.0–1.8 seconds. If you need to gather thoughts, "
                    "use a controlled silent inhalation rather than letting silence drag."
                )

            elif cat == "awkward_pause":
                explanation = (
                    f"A hesitation of {val} {unit} occurred mid-phrase without punctuation boundary. "
                    "Halting in the middle of a grammatical constituent breaks sentence cohesion."
                )
                recommendation = (
                    "Speak in complete syntactic chunks. Only pause at natural comma or period boundaries."
                )

            elif cat == "monotone":
                explanation = (
                    f"Voice pitch variance dropped to {val} {unit} (minimum recommended: {thresh} {unit}) over multiple seconds. "
                    f"A flat pitch contour ({severity} severity) sounds detached and robotic."
                )
                recommendation = (
                    "Introduce melodic variety by raising pitch on stressed syllables and emphasizing focal nouns and verbs."
                )

            elif cat == "pitch_spike":
                explanation = (
                    f"An abrupt pitch shift of {val} {unit} occurred between adjacent frames, surpassing the {thresh} {unit} threshold. "
                    "This acoustic signature indicates vocal register cracking or involuntary tension."
                )
                recommendation = (
                    "Ensure steady diaphragmatic breath support and relax tension in the throat and larynx before beginning phonation."
                )

            elif cat == "low_energy":
                pct = round(float(val) * 100, 1) if isinstance(val, (int, float)) else val
                explanation = (
                    f"Acoustic volume plummeted to {pct}% of your average energy (threshold: 20%). "
                    "Low vocal amplitude leads to perceived mumbling and lost speech clarity."
                )
                recommendation = (
                    "Project your voice from the chest cavity rather than the throat, and sustain energy through sentence endings."
                )

            elif cat == "filler_word":
                explanation = (
                    f"The verbal filler '{val}' was used as a vocal crutch. "
                    f"Frequent filler sounds detract from executive presence and perceived confidence."
                )
                recommendation = (
                    f"Whenever you feel the urge to say '{val}', close your lips and take a silent breath instead."
                )

            elif cat == "vocal_fry":
                explanation = (
                    f"Vocal fry creak was detected at fundamental frequency {val} {unit} (threshold: {thresh} {unit}). "
                    "Glottal fry can sound fatigued or informal in professional speaking environments."
                )
                recommendation = (
                    "Slightly elevate your baseline vocal pitch and maintain steady airflow through the ends of sentences."
                )

            elif cat == "inconsistent_volume":
                explanation = (
                    f"Vocal energy showed an erratic coefficient of variation of {val} (threshold: {thresh}). "
                    "Uncontrolled swings between loud bursts and fading whispers create an unsteady listening experience."
                )
                recommendation = (
                    "Maintain consistent distance from your microphone and calibrate a stable breath rate across full sentences."
                )

            elif cat == "poor_lighting_dark":
                explanation = (
                    f"Average facial illumination was {val} {unit} (minimum recommended: {thresh} {unit}). "
                    "Inadequate lighting casts heavy shadows, making eye contact and facial expressions difficult to perceive."
                )
                recommendation = (
                    "Position a ring light or soft desk lamp directly facing you at eye level, ensuring light falls evenly on both cheeks."
                )

            elif cat == "poor_lighting_glare":
                explanation = (
                    f"Frame luminance spiked to {val} {unit} (overexposure threshold: {thresh} {unit}). "
                    "Intense glare washes out facial features and strains viewer attention."
                )
                recommendation = (
                    "Close background window blinds, turn off overhead spotlights, and lower your webcam exposure settings."
                )

            elif cat == "excessive_camera_shake":
                explanation = (
                    f"Camera movement delta reached {val} {unit} (stability threshold: {thresh} {unit}). "
                    "Frequent handheld camera jitter causes visual fatigue and undermines professional executive presence."
                )
                recommendation = (
                    "Mount your camera or smartphone onto a rigid desk mount or tripod and maintain a centered anchor stance."
                )

            elif cat == "missing_audio_track":
                explanation = (
                    "The uploaded media container contains a video stream but no detectable audio track (0 audio channels). "
                    "Vocal prosody, syllable rate, and Whisper speech-to-text alignment require an active acoustic stream."
                )
                recommendation = (
                    "Re-record or export the video ensuring that your microphone input is enabled and unmuted in your recording software."
                )

            else:
                explanation = item.get("description", "Acoustic or visual delivery irregularity detected.")
                recommendation = item.get("suggestion", "Practice steady, balanced communication delivery.")

            item["explanation"] = explanation
            item["recommendation"] = recommendation
            enriched.append(item)

        return enriched

    def _explain_with_openai(
        self,
        findings: List[Dict[str, Any]],
        transcript: str,
        metrics: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """Call OpenAI API using httpx to obtain LLM-grounded explanations."""
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.settings.OPENAI_API_KEY}",
            "Content-Type": "application/json",
        }

        # Compact findings for LLM prompt
        items_payload = []
        for f in findings:
            items_payload.append({
                "id": f.get("id"),
                "category": f.get("category"),
                "start_time": f.get("start_time"),
                "end_time": f.get("end_time"),
                "severity": f.get("severity"),
                "evidence": f.get("evidence"),
            })

        system_prompt = (
            "You are JARVIS, an elite speech and communication coach. "
            "For each detected acoustic speech flaw, provide a scientifically grounded explanation "
            "referencing the measured values, and a practical, actionable recommendation. "
            "Respond strictly with a JSON object in this format: "
            '{"results": [{"id": "...", "explanation": "...", "recommendation": "..."}]}'
        )

        user_content = json.dumps({
            "transcript_sample": transcript[:1500],
            "findings": items_payload,
        })

        payload = {
            "model": self.settings.LLM_MODEL,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content},
            ],
            "response_format": {"type": "json_object"},
            "temperature": 0.3,
            "max_tokens": 2048,
        }

        with httpx.Client(timeout=30.0) as client:
            resp = client.post(url, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()
            content = data["choices"][0]["message"]["content"]
            parsed = json.loads(content)
            results_map = {item["id"]: item for item in parsed.get("results", []) if "id" in item}

            merged = []
            for f in findings:
                f_copy = dict(f)
                res = results_map.get(f_copy.get("id"))
                if res and "explanation" in res and "recommendation" in res:
                    f_copy["explanation"] = res["explanation"]
                    f_copy["recommendation"] = res["recommendation"]
                else:
                    # Fallback single item if LLM omitted ID
                    fb = self._explain_with_fallback([f_copy], transcript, metrics)[0]
                    f_copy["explanation"] = fb["explanation"]
                    f_copy["recommendation"] = fb["recommendation"]
                merged.append(f_copy)
            return merged
