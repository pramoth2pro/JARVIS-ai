"""PDF report generation for JARVIS speech intelligence analyses using fpdf2."""

import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List
from fpdf import FPDF


def clean_text(s: Any) -> str:
    """Normalize unicode punctuation to ASCII equivalents for standard PDF fonts."""
    if not s:
        return ""
    text = str(s)
    replacements = {
        "\u2013": "-",
        "\u2014": "--",
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2026": "...",
        "\u00a0": " ",
        "\u2022": "*",
        "±": "+/-",
    }
    for k, v in replacements.items():
        text = text.replace(k, v)
    return text.encode("latin-1", "replace").decode("latin-1")


class JarvisPDFReport(FPDF):
    """Custom FPDF document styled in JARVIS dark-graphite / cyan aesthetic."""

    def header(self):
        # Top banner background
        self.set_fill_color(16, 26, 46)  # Dark graphite #101a2e
        self.rect(0, 0, 210, 25, "F")

        # Cyan accent line
        self.set_fill_color(0, 212, 255)  # Cyan #00d4ff
        self.rect(0, 24, 210, 1.5, "F")

        # Title
        self.set_xy(10, 6)
        self.set_font("Helvetica", "B", 14)
        self.set_text_color(0, 212, 255)
        self.cell(0, 7, "J.A.R.V.I.S. SPEECH INTELLIGENCE", ln=False)

        # Subtitle
        self.set_xy(10, 14)
        self.set_font("Helvetica", "", 8)
        self.set_text_color(180, 195, 215)
        self.cell(0, 5, "ACOUSTIC PROSODY & TEMPORAL FLAW DIAGNOSTIC REPORT", ln=False)

        # Right aligned timestamp
        self.set_xy(130, 10)
        self.set_font("Helvetica", "I", 7)
        self.set_text_color(140, 160, 185)
        self.cell(70, 5, datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"), align="R")

        self.ln(18)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 7)
        self.set_text_color(130, 140, 160)
        self.cell(
            0,
            10,
            f"JARVIS AI Speech Diagnostics  |  Ground-Truth Acoustic Telemetry  |  Page {self.page_no()}",
            align="C",
        )


def generate_pdf_report(analysis: Dict[str, Any], output_path: str) -> str:
    """Generate a comprehensive PDF diagnostic report for an analysis."""
    pdf = JarvisPDFReport(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=18)
    pdf.add_page()

    filename = analysis.get("filename", "audio_sample.wav")
    analysis_id = analysis.get("id", "N/A")
    duration = float(analysis.get("duration_seconds") or 0.0)
    findings: List[Dict[str, Any]] = analysis.get("findings", [])
    metrics: Dict[str, Any] = analysis.get("metrics", {})

    # Extract deterministic scores
    scores = analysis.get("scores")
    if scores and isinstance(scores, dict) and "overall" in scores:
        score = scores["overall"]
        grade = scores["grade"]
        components = scores.get("components", {})
    else:
        critical_count = sum(1 for f in findings if f.get("severity") == "high")
        moderate_count = sum(1 for f in findings if f.get("severity") == "medium")
        minor_count = sum(1 for f in findings if f.get("severity") == "low")
        deductions = (critical_count * 12) + (moderate_count * 6) + (minor_count * 2)
        score = max(20, min(100, 100 - deductions))
        grade = "A" if score >= 90 else "B" if score >= 80 else "C" if score >= 70 else "Needs Work"
        components = {}

    critical_count = sum(1 for f in findings if f.get("severity") == "high")
    moderate_count = sum(1 for f in findings if f.get("severity") == "medium")

    # Section 1: Session Overview
    pdf.set_fill_color(240, 245, 250)
    pdf.rect(10, 32, 190, 28, "F")
    pdf.set_draw_color(200, 215, 230)
    pdf.rect(10, 32, 190, 28, "D")

    pdf.set_xy(14, 35)
    pdf.set_font("Helvetica", "B", 9)
    pdf.set_text_color(20, 35, 60)
    pdf.cell(90, 5, f"Media File: {filename}")
    pdf.set_xy(110, 35)
    pdf.cell(85, 5, f"Analysis ID: {analysis_id[:16]}...")

    pdf.set_xy(14, 42)
    pdf.set_font("Helvetica", "", 8)
    pdf.set_text_color(60, 75, 95)
    pdf.cell(90, 5, f"Duration: {duration:.1f} seconds  ({int(duration // 60)}m {int(duration % 60)}s)")
    pdf.set_xy(110, 42)
    pdf.cell(85, 5, f"Diagnostic Flags: {len(findings)} detected ({critical_count} critical, {moderate_count} moderate)")

    # Score Pill
    pdf.set_xy(14, 49)
    pdf.set_font("Helvetica", "B", 10)
    pdf.set_text_color(0, 150, 180)
    pdf.cell(90, 7, f"JARVIS Speech Score: {score}/100  [Grade: {grade}]")

    # Section 2: Acoustic Telemetry Summary Table
    pdf.set_xy(10, 65)
    pdf.set_font("Helvetica", "B", 10)
    pdf.set_text_color(16, 26, 46)
    pdf.cell(0, 6, "ACOUSTIC PROSODIC METRICS", ln=True)

    pdf.set_fill_color(20, 35, 60)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Helvetica", "B", 8)
    col_w = [47.5, 47.5, 47.5, 47.5]
    pdf.cell(col_w[0], 6, "Metric Parameter", border=1, fill=True, align="C")
    pdf.cell(col_w[1], 6, "Measured Value", border=1, fill=True, align="C")
    pdf.cell(col_w[2], 6, "Target / Benchmark", border=1, fill=True, align="C")
    pdf.cell(col_w[3], 6, "Acoustic Status", border=1, fill=True, align="C", ln=True)

    # Extract metrics safely
    spk_rate = metrics.get("speaking_rate", {}).get("overall_syl_per_sec", 0.0)
    mean_f0 = metrics.get("pitch", {}).get("mean_f0", 0.0)
    std_f0 = metrics.get("pitch", {}).get("std_f0", 0.0)
    rms_mean = metrics.get("rms", {}).get("mean_rms", 0.0)
    pauses_list = metrics.get("pauses", [])
    total_pause_dur = sum(p.get("duration", 0.0) for p in pauses_list)

    metric_rows = [
        ("Speaking Cadence (Pace)", f"{spk_rate:.1f} syl/s", "3.5 - 4.8 syl/s", "Optimal" if 3.2 <= spk_rate <= 5.2 else "Review Pace"),
        ("Fundamental Pitch (F0)", f"{mean_f0:.1f} Hz", "Speaker Baseline", "Calibrated" if mean_f0 > 0 else "N/A"),
        ("Pitch Inflection (Std Dev)", f"+/- {std_f0:.1f} Hz", "> 18.0 Hz (Dynamic)", "Dynamic" if std_f0 >= 18 else "Monotone Risk"),
        ("Pauses & Hesitations", f"{len(pauses_list)} ({total_pause_dur:.1f}s)", "< 2.0s per pause", "Controlled" if len(pauses_list) <= 12 else "Frequent"),
    ]

    pdf.set_font("Helvetica", "", 7.5)
    for row in metric_rows:
        pdf.set_text_color(30, 40, 55)
        pdf.cell(col_w[0], 5.5, f"  {row[0]}", border=1)
        pdf.cell(col_w[1], 5.5, f"  {row[1]}", border=1, align="C")
        pdf.cell(col_w[2], 5.5, f"  {row[2]}", border=1, align="C")
        # Color status
        if "Optimal" in row[3] or "Calibrated" in row[3] or "Dynamic" in row[3] or "Controlled" in row[3]:
            pdf.set_text_color(0, 140, 70)
        else:
            pdf.set_text_color(190, 50, 40)
        pdf.cell(col_w[3], 5.5, f"  {row[3]}", border=1, align="C", ln=True)

    # Section 3: Diagnostic Findings & Actionable Coaching
    pdf.ln(4)
    pdf.set_font("Helvetica", "B", 10)
    pdf.set_text_color(16, 26, 46)
    pdf.cell(0, 6, f"DIAGNOSTIC FINDINGS & DRILLS ({len(findings)} Items)", ln=True)

    if not findings:
        pdf.set_font("Helvetica", "I", 8)
        pdf.set_text_color(100, 115, 135)
        pdf.cell(0, 8, "No acoustic prosody flaws detected. Delivery is balanced and articulate.", ln=True)
    else:
        for idx, f in enumerate(findings, 1):
            sev = f.get("severity", "medium").upper()
            start_t = float(f.get("start_time", 0.0))
            end_t = float(f.get("end_time", 0.0))
            category = clean_text(f.get("category", "Speech Flaw"))
            desc = clean_text(f.get("description", ""))
            recom = clean_text(f.get("recommendation") or f.get("suggestion", ""))
            evidence = f.get("evidence", {})
            measured_val = clean_text(evidence.get("measured_value", "N/A"))
            unit = clean_text(evidence.get("unit", ""))
            thresh = clean_text(evidence.get("threshold", "N/A"))

            # Check page break
            if pdf.get_y() > 250:
                pdf.add_page()

            # Item header box
            pdf.set_fill_color(245, 248, 252)
            pdf.rect(10, pdf.get_y(), 190, 5, "F")
            pdf.set_font("Helvetica", "B", 7.5)
            pdf.set_text_color(0, 100, 150)
            time_str = f"[{int(start_t // 60):02d}:{int(start_t % 60):02d}.{int((start_t % 1)*10):01d} - {int(end_t // 60):02d}:{int(end_t % 60):02d}.{int((end_t % 1)*10):01d}]"
            pdf.cell(60, 5, f"#{idx}  {time_str}  {category}")

            # Severity badge
            if sev == "HIGH":
                pdf.set_text_color(190, 30, 40)
            elif sev == "MEDIUM":
                pdf.set_text_color(200, 130, 0)
            else:
                pdf.set_text_color(0, 140, 180)
            pdf.cell(40, 5, f"Severity: {sev}")

            pdf.set_text_color(100, 110, 125)
            pdf.cell(90, 5, f"Measured: {measured_val} {unit}  (Thresh: {thresh})", align="R", ln=True)

            # Description
            pdf.set_font("Helvetica", "", 7.5)
            pdf.set_text_color(40, 50, 65)
            pdf.multi_cell(190, 4, f"Evidence: {desc}")

            # Coaching recommendation
            if recom:
                pdf.set_font("Helvetica", "I", 7.5)
                pdf.set_text_color(0, 100, 140)
                pdf.multi_cell(190, 4, f"Drill: {recom}")

            pdf.ln(2)

    # Section 4: Provenance & Ethical Disclaimer
    if pdf.get_y() > 240:
        pdf.add_page()
    pdf.ln(4)
    pdf.set_fill_color(248, 250, 252)
    pdf.rect(10, pdf.get_y(), 190, 14, "F")
    pdf.set_xy(12, pdf.get_y() + 2)
    pdf.set_font("Helvetica", "", 6.5)
    pdf.set_text_color(110, 120, 135)
    pdf.multi_cell(
        186,
        3,
        "Ethics & Acoustic Provenance: All flaws are computed strictly from measurable physical acoustics (librosa F0, RMS, onset intervals) and Whisper temporal alignments. JARVIS does not evaluate personal accents or dialect variations as intrinsic flaws. LLM coaching recommendations provide deliberate practice drills grounded solely in acoustic evidence.",
    )

    pdf.output(output_path)
    return output_path
