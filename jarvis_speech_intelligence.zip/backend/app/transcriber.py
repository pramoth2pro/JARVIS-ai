"""Speech-to-text transcription module using OpenAI Whisper with word-level timestamps."""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class Transcriber:
    """Whisper transcription service with lazy model loading and word timestamp alignment."""

    def __init__(self, model_size: str = "base"):
        self.model_size = model_size
        self._model = None

    def _get_model(self):
        """Lazily load the Whisper model."""
        if self._model is None:
            try:
                import torch
                import whisper

                # Detect CUDA if available, otherwise CPU
                device = "cuda" if torch.cuda.is_available() else "cpu"
                logger.info(f"Loading Whisper model '{self.model_size}' on {device}...")
                self._model = whisper.load_model(self.model_size, device=device)
                logger.info(f"Whisper model '{self.model_size}' loaded successfully.")
            except ImportError as e:
                raise RuntimeError(
                    f"Required libraries for transcription are missing: {e}. "
                    f"Please install torch and openai-whisper."
                ) from e
            except Exception as e:
                raise RuntimeError(
                    f"Failed to load Whisper model '{self.model_size}': {str(e)}"
                ) from e
        return self._model

    def transcribe(self, audio_path: str) -> Dict[str, Any]:
        """
        Transcribe an audio file and extract segment and word-level timestamps.

        Returns:
            {
                "text": str,
                "language": str,
                "segments": [
                    {"start": float, "end": float, "text": str}
                ],
                "words": [
                    {"word": str, "start": float, "end": float, "probability": float}
                ]
            }
        """
        audio_file = Path(audio_path).resolve()
        if not audio_file.exists():
            raise FileNotFoundError(f"Audio file not found: {audio_path}")

        model = self._get_model()

        try:
            logger.info(f"Transcribing '{audio_path}' with word_timestamps=True...")
            # Try reading audio into numpy float32 array first
            audio_input: Any = str(audio_file)
            try:
                import soundfile as sf
                data, sr = sf.read(str(audio_file), dtype="float32", always_2d=False)
                if data.ndim > 1:
                    data = data.mean(axis=1)
                if sr == 16000 and len(data) > 0:
                    audio_input = data
            except Exception as read_err:
                logger.debug(f"Direct soundfile read failed, falling back to file path: {read_err}")

            try:
                result = model.transcribe(
                    audio_input,
                    word_timestamps=True,
                    verbose=False,
                )
            except Exception as wt_err:
                logger.warning(f"Whisper word_timestamps failed ({wt_err}), retrying standard transcription...")
                result = model.transcribe(
                    audio_input,
                    word_timestamps=False,
                    verbose=False,
                )

            full_text = result.get("text", "").strip()
            language = result.get("language", "en")
            raw_segments = result.get("segments", [])

            formatted_segments: List[Dict[str, Any]] = []
            flat_words: List[Dict[str, Any]] = []

            for seg in raw_segments:
                seg_start = round(float(seg.get("start", 0.0)), 3)
                seg_end = round(float(seg.get("end", 0.0)), 3)
                seg_text = seg.get("text", "").strip()

                formatted_segments.append({
                    "start": seg_start,
                    "end": seg_end,
                    "text": seg_text,
                })

                # Extract word-level timestamps
                seg_words = seg.get("words", [])
                for w in seg_words:
                    word_str = w.get("word", "").strip()
                    if not word_str:
                        continue
                    w_start = round(float(w.get("start", seg_start)), 3)
                    w_end = round(float(w.get("end", seg_end)), 3)
                    w_prob = round(float(w.get("probability", 1.0)), 3)

                    flat_words.append({
                        "word": word_str,
                        "start": w_start,
                        "end": w_end,
                        "probability": w_prob,
                    })

            return {
                "text": full_text,
                "language": language,
                "segments": formatted_segments,
                "words": flat_words,
            }

        except Exception as e:
            logger.error(f"Error during Whisper transcription: {e}")
            raise RuntimeError(f"Transcription failed: {str(e)}") from e
