"""Audio processing and acoustic feature extraction module using librosa and soundfile."""

import logging
import math
import os
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


def sanitize_floats(obj: Any) -> Any:
    """Recursively convert NaN/Inf values to None/0.0 for JSON compliance."""
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
        return round(obj, 4)
    elif isinstance(obj, np.floating):
        val = float(obj)
        if math.isnan(val) or math.isinf(val):
            return None
        return round(val, 4)
    elif isinstance(obj, (np.integer, int)):
        return int(obj)
    elif isinstance(obj, np.ndarray):
        return [sanitize_floats(x) for x in obj.tolist()]
    elif isinstance(obj, list):
        return [sanitize_floats(x) for x in obj]
    elif isinstance(obj, dict):
        return {k: sanitize_floats(v) for k, v in obj.items()}
    return obj


class AudioProcessor:
    """Handles audio conversion, normalization, and comprehensive acoustic feature extraction."""

    def __init__(self, target_sr: int = 16000):
        self.target_sr = target_sr

    def preprocess(self, input_path: str, output_path: str) -> Dict[str, Any]:
        """
        Convert any audio/video file to 16kHz mono 16-bit WAV.
        Uses pydub first, falling back to soundfile / scipy / subprocess ffmpeg if needed.
        """
        input_file = Path(input_path).resolve()
        output_file = Path(output_path).resolve()
        output_file.parent.mkdir(parents=True, exist_ok=True)

        if not input_file.exists():
            raise FileNotFoundError(f"Input audio file not found: {input_path}")

        conversion_success = False
        last_error = ""

        # Strategy 1: Attempt conversion using pydub
        try:
            from pydub import AudioSegment
            audio = AudioSegment.from_file(str(input_file))
            audio = audio.set_frame_rate(self.target_sr).set_channels(1).set_sample_width(2)
            audio.export(str(output_file), format="wav")
            conversion_success = True
        except Exception as e:
            last_error = f"pydub conversion failed: {str(e)}"
            logger.warning(last_error)

        # Strategy 2: If pydub failed (e.g. ffmpeg not found in path for certain formats), try soundfile / librosa
        if not conversion_success:
            try:
                import soundfile as sf
                import librosa

                data, sr = sf.read(str(input_file), always_2d=True)
                # Convert to mono if multi-channel
                if data.shape[1] > 1:
                    mono_data = np.mean(data, axis=1)
                else:
                    mono_data = data[:, 0]

                # Resample if sample rate doesn't match
                if sr != self.target_sr:
                    mono_data = librosa.resample(mono_data.astype(np.float32), orig_sr=sr, target_sr=self.target_sr)

                sf.write(str(output_file), mono_data.astype(np.float32), self.target_sr, subtype="PCM_16")
                conversion_success = True
            except Exception as e:
                last_error += f" | soundfile fallback failed: {str(e)}"
                logger.warning(f"soundfile fallback failed: {e}")

        # Strategy 3: Subprocess ffmpeg invocation if available on the system
        if not conversion_success:
            try:
                ffmpeg_bin = "ffmpeg"
                try:
                    import imageio_ffmpeg
                    ffmpeg_bin = imageio_ffmpeg.get_ffmpeg_exe()
                except Exception:
                    pass

                cmd = [
                    ffmpeg_bin, "-y", "-i", str(input_file),
                    "-vn", "-acodec", "pcm_s16le", "-ar", str(self.target_sr),
                    "-ac", "1", str(output_file)
                ]
                res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
                if output_file.exists() and output_file.stat().st_size > 0:
                    conversion_success = True
            except Exception as e:
                last_error += f" | ffmpeg CLI fallback failed: {str(e)}"
                logger.warning(f"ffmpeg CLI fallback failed: {e}")

        if not conversion_success or not output_file.exists():
            raise RuntimeError(f"Failed to preprocess audio file '{input_path}'. Errors: {last_error}")

        # Read output metadata
        duration = 0.0
        channels = 1
        sample_rate = self.target_sr
        try:
            import soundfile as sf
            info = sf.info(str(output_file))
            duration = float(info.duration)
            channels = int(info.channels)
            sample_rate = int(info.samplerate)
        except Exception:
            # Fallback calculate from file size for 16-bit 16kHz mono WAV
            file_bytes = output_file.stat().st_size - 44
            if file_bytes > 0:
                duration = float(file_bytes / (self.target_sr * 2))

        return {
            "duration": round(duration, 3),
            "sample_rate": sample_rate,
            "channels": channels,
            "input_path": str(input_file),
            "output_path": str(output_file),
            "size_bytes": output_file.stat().st_size,
        }

    def detect_pauses(self, audio_path: str, min_duration: float = 0.3) -> List[Dict[str, float]]:
        """
        Detect silent segments where energy is below threshold for at least min_duration seconds.
        Returns list of {start, end, duration}.
        """
        try:
            import librosa
            y, sr = librosa.load(audio_path, sr=self.target_sr, mono=True)
            total_duration = float(len(y) / sr)

            if len(y) == 0:
                return []

            # Use librosa.effects.split to detect voiced/active intervals
            # top_db=25 is a standard speech silence threshold
            non_silent = librosa.effects.split(y, top_db=25, frame_length=2048, hop_length=512)

            silent_intervals: List[Dict[str, float]] = []
            prev_end = 0.0

            for interval in non_silent:
                start_sec = float(interval[0] / sr)
                end_sec = float(interval[1] / sr)

                if start_sec - prev_end >= min_duration:
                    pause_dur = round(start_sec - prev_end, 3)
                    silent_intervals.append({
                        "start": round(prev_end, 3),
                        "end": round(start_sec, 3),
                        "duration": pause_dur,
                    })
                prev_end = end_sec

            # Trailing silence
            if total_duration - prev_end >= min_duration:
                silent_intervals.append({
                    "start": round(prev_end, 3),
                    "end": round(total_duration, 3),
                    "duration": round(total_duration - prev_end, 3),
                })

            return silent_intervals
        except Exception as e:
            logger.error(f"Error in detect_pauses: {e}")
            return []

    def get_waveform_data(self, audio_path: str, num_points: int = 2000) -> List[float]:
        """
        Return downsampled waveform points normalized between -1.0 and 1.0 for UI visualization.
        """
        try:
            import soundfile as sf
            y, sr = sf.read(audio_path, always_2d=False)
            if y.ndim > 1:
                y = np.mean(y, axis=1)

            total_samples = len(y)
            if total_samples == 0:
                return [0.0] * num_points

            if total_samples <= num_points:
                # Pad with zeros
                result = y.tolist() + [0.0] * (num_points - total_samples)
                return [round(float(v), 4) for v in result]

            # Block-based downsampling taking peak absolute amplitude per bucket
            step = total_samples / float(num_points)
            peaks: List[float] = []

            for i in range(num_points):
                start_idx = int(i * step)
                end_idx = int((i + 1) * step)
                chunk = y[start_idx:end_idx]
                if len(chunk) > 0:
                    peak = float(np.max(np.abs(chunk)))
                else:
                    peak = 0.0
                peaks.append(peak)

            # Normalize to 1.0 peak
            max_val = max(peaks) if peaks else 0.0
            if max_val > 1e-6:
                peaks = [p / max_val for p in peaks]

            return [round(p, 4) for p in peaks]
        except Exception as e:
            logger.error(f"Error in get_waveform_data: {e}")
            return [0.0] * num_points

    def extract_features(self, audio_path: str) -> Dict[str, Any]:
        """
        Using librosa and scipy, extract full acoustic profile:
        - pitch/F0 contour using librosa.pyin (fmin=50, fmax=500)
        - RMS energy over time
        - speaking rate (syllables per second estimate from energy envelope)
        - pause detection
        - MFCCs (13 coefficients)
        - spectral centroid, bandwidth, rolloff
        - zero crossing rate
        """
        result: Dict[str, Any] = {
            "duration": 0.0,
            "pitch": {"times": [], "f0": [], "mean_f0": 0.0, "std_f0": 0.0, "min_f0": 0.0, "max_f0": 0.0},
            "rms": {"times": [], "values": [], "mean_rms": 0.0, "std_rms": 0.0, "min_rms": 0.0, "max_rms": 0.0},
            "speaking_rate": {"overall_syl_per_sec": 0.0, "estimated_syllables": 0, "rate_windows": []},
            "pauses": [],
            "mfcc": {"coefficients": [], "mean": [], "std": []},
            "spectral": {
                "centroid_mean": 0.0,
                "bandwidth_mean": 0.0,
                "rolloff_mean": 0.0,
            },
            "zcr": {"mean": 0.0, "std": 0.0},
            "errors": [],
        }

        try:
            import librosa
            from scipy.signal import find_peaks

            y, sr = librosa.load(audio_path, sr=self.target_sr, mono=True)
            duration = float(len(y) / sr)
            result["duration"] = round(duration, 3)

            if len(y) == 0:
                result["errors"].append("Audio file contains no samples")
                return sanitize_floats(result)

            hop_length = 512
            frame_length = 2048

            # 1. Pitch / F0 contour with pyin
            try:
                f0, voiced_flag, voiced_probs = librosa.pyin(
                    y,
                    fmin=50,
                    fmax=500,
                    sr=sr,
                    frame_length=frame_length,
                    hop_length=hop_length,
                )
                pitch_times = librosa.times_like(f0, sr=sr, hop_length=hop_length)

                voiced_f0 = f0[~np.isnan(f0)] if f0 is not None else np.array([])
                mean_f0 = float(np.mean(voiced_f0)) if len(voiced_f0) > 0 else 0.0
                std_f0 = float(np.std(voiced_f0)) if len(voiced_f0) > 0 else 0.0
                min_f0 = float(np.min(voiced_f0)) if len(voiced_f0) > 0 else 0.0
                max_f0 = float(np.max(voiced_f0)) if len(voiced_f0) > 0 else 0.0

                # Downsample pitch contour for compact storage and frontend streaming
                ds_step = max(1, len(f0) // 500)
                f0_list = [None if np.isnan(v) else round(float(v), 2) for v in f0[::ds_step]]
                times_list = [round(float(t), 3) for t in pitch_times[::ds_step]]

                result["pitch"] = {
                    "times": times_list,
                    "f0": f0_list,
                    "mean_f0": round(mean_f0, 2),
                    "std_f0": round(std_f0, 2),
                    "min_f0": round(min_f0, 2),
                    "max_f0": round(max_f0, 2),
                    # Full resolution references for internal flaw detection
                    "_raw_f0": [None if np.isnan(v) else float(v) for v in f0],
                    "_raw_times": [float(t) for t in pitch_times],
                }
            except Exception as e:
                result["errors"].append(f"Pitch extraction failed: {str(e)}")

            # 2. RMS Energy over time
            try:
                rms = librosa.feature.rms(y=y, frame_length=frame_length, hop_length=hop_length)[0]
                rms_times = librosa.times_like(rms, sr=sr, hop_length=hop_length)

                mean_rms = float(np.mean(rms)) if len(rms) > 0 else 0.0
                std_rms = float(np.std(rms)) if len(rms) > 0 else 0.0
                min_rms = float(np.min(rms)) if len(rms) > 0 else 0.0
                max_rms = float(np.max(rms)) if len(rms) > 0 else 0.0

                ds_step_rms = max(1, len(rms) // 500)
                result["rms"] = {
                    "times": [round(float(t), 3) for t in rms_times[::ds_step_rms]],
                    "values": [round(float(v), 4) for v in rms[::ds_step_rms]],
                    "mean_rms": round(mean_rms, 4),
                    "std_rms": round(std_rms, 4),
                    "min_rms": round(min_rms, 4),
                    "max_rms": round(max_rms, 4),
                    "_raw_rms": [float(v) for v in rms],
                    "_raw_times": [float(t) for t in rms_times],
                }
            except Exception as e:
                result["errors"].append(f"RMS energy extraction failed: {str(e)}")

            # 3. Pauses detection
            pauses = self.detect_pauses(audio_path, min_duration=0.3)
            result["pauses"] = pauses

            # 4. Speaking Rate (syllable detection via energy envelope peaks)
            try:
                # Compute onset envelope focused on sonorant vocalic peaks (syllables)
                onset_env = librosa.onset.onset_strength(y=y, sr=sr, hop_length=hop_length)
                # Syllables in human speech occur every 120ms to 500ms
                min_distance_frames = max(1, int(0.12 * sr / hop_length))
                height_threshold = float(np.mean(onset_env) * 0.4) if len(onset_env) > 0 else 0.0

                peaks, _ = find_peaks(onset_env, distance=min_distance_frames, height=height_threshold)
                total_syllables = len(peaks)

                total_pause_duration = sum(p["duration"] for p in pauses)
                active_speech_time = max(0.5, duration - total_pause_duration)
                overall_syl_per_sec = float(total_syllables / active_speech_time) if active_speech_time > 0 else 0.0

                # Compute local rate over 3-second sliding windows
                window_size_sec = 3.0
                hop_sec = 1.0
                rate_windows = []
                peak_times = librosa.frames_to_time(peaks, sr=sr, hop_length=hop_length)

                w_start = 0.0
                while w_start + window_size_sec <= duration + 0.5:
                    w_end = min(duration, w_start + window_size_sec)
                    syl_in_window = sum(1 for pt in peak_times if w_start <= pt < w_end)
                    local_rate = syl_in_window / (w_end - w_start)
                    rate_windows.append({
                        "start": round(w_start, 2),
                        "end": round(w_end, 2),
                        "rate": round(float(local_rate), 2),
                    })
                    w_start += hop_sec

                result["speaking_rate"] = {
                    "overall_syl_per_sec": round(overall_syl_per_sec, 2),
                    "estimated_syllables": total_syllables,
                    "active_speech_time": round(active_speech_time, 2),
                    "rate_windows": rate_windows,
                }
            except Exception as e:
                result["errors"].append(f"Speaking rate extraction failed: {str(e)}")

            # 5. MFCCs (13 coefficients)
            try:
                mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13, hop_length=hop_length)
                mfcc_mean = [round(float(v), 3) for v in np.mean(mfcc, axis=1)]
                mfcc_std = [round(float(v), 3) for v in np.std(mfcc, axis=1)]

                result["mfcc"] = {
                    "mean": mfcc_mean,
                    "std": mfcc_std,
                    "n_mfcc": 13,
                }
            except Exception as e:
                result["errors"].append(f"MFCC extraction failed: {str(e)}")

            # 6. Spectral Centroid, Bandwidth, Rolloff
            try:
                spec_cent = librosa.feature.spectral_centroid(y=y, sr=sr, hop_length=hop_length)[0]
                spec_bw = librosa.feature.spectral_bandwidth(y=y, sr=sr, hop_length=hop_length)[0]
                spec_roll = librosa.feature.spectral_rolloff(y=y, sr=sr, hop_length=hop_length)[0]

                result["spectral"] = {
                    "centroid_mean": round(float(np.mean(spec_cent)), 2),
                    "bandwidth_mean": round(float(np.mean(spec_bw)), 2),
                    "rolloff_mean": round(float(np.mean(spec_roll)), 2),
                }
            except Exception as e:
                result["errors"].append(f"Spectral features failed: {str(e)}")

            # 7. Zero Crossing Rate
            try:
                zcr = librosa.feature.zero_crossing_rate(y, hop_length=hop_length)[0]
                result["zcr"] = {
                    "mean": round(float(np.mean(zcr)), 4),
                    "std": round(float(np.std(zcr)), 4),
                }
            except Exception as e:
                result["errors"].append(f"Zero crossing rate failed: {str(e)}")

        except Exception as e:
            result["errors"].append(f"Audio processing top-level error: {str(e)}")
            logger.error(f"Error in extract_features: {e}")

        return sanitize_floats(result)
