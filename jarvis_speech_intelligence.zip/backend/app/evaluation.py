"""Evaluation pipeline for speech flaw detection benchmarks.

Calculates:
- Temporal interval Intersection over Union (IoU)
- Detection Precision, Recall, and F1 Score (with configurable IoU matching threshold)
- Severity classification accuracy
- False Positive Rate (FPR)
"""

import math
from typing import Any, Dict, List, Optional, Tuple


def compute_interval_iou(
    start1: float, end1: float, start2: float, end2: float
) -> float:
    """Calculate Intersection over Union (IoU) of two 1D time intervals [s1, e1] and [s2, e2]."""
    intersection_start = max(start1, start2)
    intersection_end = min(end1, end2)
    intersection = max(0.0, intersection_end - intersection_start)

    union_start = min(start1, start2)
    union_end = max(end1, end2)
    union = max(1e-6, union_end - union_start)

    return intersection / union


def evaluate_flaw_detections(
    predictions: List[Dict[str, Any]],
    ground_truth: List[Dict[str, Any]],
    iou_threshold: float = 0.3,
    category_match_required: bool = True,
) -> Dict[str, Any]:
    """
    Evaluate predicted flaw intervals against ground-truth human annotations.

    Returns:
        {
            "precision": float,
            "recall": float,
            "f1": float,
            "mean_iou": float,
            "severity_accuracy": float,
            "tp_count": int,
            "fp_count": int,
            "fn_count": int,
            "matched_pairs": list,
        }
    """
    matched_gt = set()
    matched_pred = set()
    matches: List[Dict[str, Any]] = []

    # Greedy matching by maximum IoU
    candidate_pairs = []
    for p_idx, p in enumerate(predictions):
        p_start = float(p.get("start_time", 0.0))
        p_end = float(p.get("end_time", 0.0))
        p_cat = p.get("category", "").lower()

        for g_idx, g in enumerate(ground_truth):
            g_start = float(g.get("start_time", 0.0))
            g_end = float(g.get("end_time", 0.0))
            g_cat = g.get("category", "").lower()

            if category_match_required and p_cat != g_cat:
                continue

            iou = compute_interval_iou(p_start, p_end, g_start, g_end)
            if iou >= iou_threshold:
                candidate_pairs.append((iou, p_idx, g_idx))

    # Sort descending by IoU
    candidate_pairs.sort(key=lambda x: x[0], reverse=True)

    for iou, p_idx, g_idx in candidate_pairs:
        if p_idx not in matched_pred and g_idx not in matched_gt:
            matched_pred.add(p_idx)
            matched_gt.add(g_idx)
            p = predictions[p_idx]
            g = ground_truth[g_idx]

            severity_match = p.get("severity", "").lower() == g.get("severity", "").lower()

            matches.append({
                "pred_id": p.get("id"),
                "gt_id": g.get("id", f"gt_{g_idx}"),
                "category": p.get("category"),
                "iou": round(iou, 3),
                "severity_match": severity_match,
                "pred_severity": p.get("severity"),
                "gt_severity": g.get("severity"),
            })

    tp = len(matches)
    fp = len(predictions) - tp
    fn = len(ground_truth) - tp

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = (2 * precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0

    mean_iou = sum(m["iou"] for m in matches) / tp if tp > 0 else 0.0
    severity_acc = sum(1 for m in matches if m["severity_match"]) / tp if tp > 0 else 0.0

    return {
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "mean_iou": round(mean_iou, 4),
        "severity_accuracy": round(severity_acc, 4),
        "tp_count": tp,
        "fp_count": fp,
        "fn_count": fn,
        "total_predictions": len(predictions),
        "total_ground_truth": len(ground_truth),
        "iou_threshold": iou_threshold,
        "matched_pairs": matches,
    }
