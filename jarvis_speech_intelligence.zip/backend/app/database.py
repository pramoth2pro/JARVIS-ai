"""Database initialization and access helpers using sqlite-utils."""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
import sqlite_utils
from sqlite_utils import Database

from app.config import get_settings


def get_db(db_path: Optional[str] = None) -> Database:
    """Get sqlite-utils Database instance for configured DB path."""
    settings = get_settings()
    path = db_path or str(settings.db_file_path)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    return Database(path)


def init_db(db_path: Optional[str] = None) -> Database:
    """Initialize database tables and indexes if they do not exist."""
    db = get_db(db_path)

    # Analyses table
    if "analyses" not in db.table_names():
        db["analyses"].create(
            {
                "id": str,
                "filename": str,
                "status": str,
                "created_at": str,
                "updated_at": str,
                "transcript": str,
                "findings_json": str,
                "metrics_json": str,
                "scores_json": str,
                "audio_path": str,
                "duration_seconds": float,
                "content_hash": str,
                "media_type": str,
            },
            pk="id",
        )
        # Create indices for fast lookup
        db["analyses"].create_index(["status"])
        db["analyses"].create_index(["created_at"])
        db["analyses"].create_index(["content_hash"])
    else:
        # Migrate existing table if columns missing
        existing_cols = {col.name for col in db["analyses"].columns}
        if "content_hash" not in existing_cols:
            db["analyses"].add_column("content_hash", str)
            db["analyses"].create_index(["content_hash"])
        if "scores_json" not in existing_cols:
            db["analyses"].add_column("scores_json", str)
        if "media_type" not in existing_cols:
            db["analyses"].add_column("media_type", str)

    # Dataset entries table
    if "dataset_entries" not in db.table_names():
        db["dataset_entries"].create(
            {
                "id": str,
                "analysis_id": str,
                "transcript": str,
                "speaker_id": str,
                "category": str,
                "severity": str,
                "timestamps_json": str,
                "features_json": str,
                "provenance": str,
            },
            pk="id",
            foreign_keys=[("analysis_id", "analyses", "id")],
        )
        db["dataset_entries"].create_index(["analysis_id"])
        db["dataset_entries"].create_index(["category"])
        db["dataset_entries"].create_index(["severity"])

    return db


def get_utc_now() -> str:
    """Return current UTC timestamp in ISO format."""
    return datetime.now(timezone.utc).isoformat()


def create_analysis_record(
    analysis_id: str,
    filename: str,
    audio_path: str,
    status: str = "uploaded",
    content_hash: Optional[str] = None,
    media_type: str = "audio",
) -> Dict[str, Any]:
    """Insert a new analysis record into database."""
    db = get_db()
    now = get_utc_now()
    record = {
        "id": analysis_id,
        "filename": filename,
        "status": status,
        "created_at": now,
        "updated_at": now,
        "transcript": "",
        "findings_json": json.dumps([]),
        "metrics_json": json.dumps({}),
        "scores_json": json.dumps({}),
        "audio_path": audio_path,
        "duration_seconds": 0.0,
        "content_hash": content_hash or "",
        "media_type": media_type,
    }
    db["analyses"].insert(record)
    return record


def update_analysis_record(
    analysis_id: str,
    **kwargs: Any,
) -> Optional[Dict[str, Any]]:
    """Update fields on an analysis record."""
    db = get_db()
    table = db["analyses"]
    if not table.get(analysis_id):
        return None

    update_payload = dict(kwargs)
    update_payload["updated_at"] = get_utc_now()

    # Automatically json-serialize dict/list parameters if json field
    for json_key in ("findings_json", "metrics_json", "scores_json"):
        if json_key in update_payload and isinstance(update_payload[json_key], (dict, list)):
            update_payload[json_key] = json.dumps(update_payload[json_key])

    table.update(analysis_id, update_payload)
    return get_analysis_record(analysis_id)


def get_analysis_record(analysis_id: str) -> Optional[Dict[str, Any]]:
    """Fetch an analysis record by ID and parse JSON fields."""
    db = get_db()
    try:
        row = db["analyses"].get(analysis_id)
    except sqlite_utils.db.NotFoundError:
        return None

    result = dict(row)
    # Parse JSON fields safely
    for json_key, default_val in [("findings_json", []), ("metrics_json", {}), ("scores_json", {})]:
        val = result.get(json_key)
        if isinstance(val, str) and val:
            try:
                result[json_key.replace("_json", "")] = json.loads(val)
            except Exception:
                result[json_key.replace("_json", "")] = default_val
        else:
            result[json_key.replace("_json", "")] = default_val

    return result


def find_cached_analysis(content_hash: str) -> Optional[Dict[str, Any]]:
    """
    Look up a completed analysis record with the exact matching content hash.
    Ensures cache reuse is permitted ONLY when the content identity genuinely matches.
    """
    if not content_hash:
        return None
    db = get_db()
    table = db["analyses"]
    matches = list(
        table.rows_where(
            "content_hash = ? AND status IN ('complete', 'completed')",
            [content_hash],
            order_by="created_at desc",
            limit=1,
        )
    )
    if matches:
        return get_analysis_record(matches[0]["id"])
    return None


def list_analyses_records(limit: int = 50, offset: int = 0) -> Dict[str, Any]:
    """List analysis records with pagination."""
    db = get_db()
    table = db["analyses"]
    total = table.count
    rows = list(
        table.rows_where(
            order_by="created_at desc",
            limit=limit,
            offset=offset,
        )
    )

    items = []
    for row in rows:
        item = dict(row)
        for json_key, default_val in [("findings_json", []), ("metrics_json", {})]:
            val = item.get(json_key)
            if isinstance(val, str) and val:
                try:
                    item[json_key.replace("_json", "")] = json.loads(val)
                except Exception:
                    item[json_key.replace("_json", "")] = default_val
            else:
                item[json_key.replace("_json", "")] = default_val
        items.append(item)

    return {
        "items": items,
        "total": total,
        "limit": limit,
        "offset": offset,
    }


def delete_analysis_record(analysis_id: str) -> bool:
    """Delete an analysis record and associated dataset entries."""
    db = get_db()
    table = db["analyses"]
    try:
        table.get(analysis_id)
    except sqlite_utils.db.NotFoundError:
        return False

    # Delete dataset entries first
    try:
        db["dataset_entries"].delete_where("analysis_id = ?", [analysis_id])
    except Exception:
        pass

    table.delete(analysis_id)
    return True
