"""FastAPI backend application for JARVIS Speech Coach."""

import asyncio
import json
import logging
import os
import shutil
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, List, Optional

import aiofiles
from fastapi import (
    BackgroundTasks,
    FastAPI,
    File,
    HTTPException,
    Query,
    Request,
    UploadFile,
    status,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field
from sse_starlette.sse import EventSourceResponse

from app.audio_processor import AudioProcessor
from app.config import get_settings
import hashlib

from app.flaw_detector import FlawDetector
from app.llm_explainer import LLMExplainer
from app.transcriber import Transcriber
from app.video_processor import VideoProcessor
from app.scoring import compute_component_scores
from app.pdf_exporter import generate_pdf_report
from app.dataset_manager import (
    compare_with_reference,
    get_contrastive_samples,
    seed_contrastive_dataset,
)
from app.evaluation import evaluate_flaw_detections
from app.database import (
    create_analysis_record,
    delete_analysis_record,
    find_cached_analysis,
    get_analysis_record,
    get_db,
    init_db,
    list_analyses_records,
    update_analysis_record,
)

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("jarvis.backend")

# In-memory SSE event bus
_sse_queues: Dict[str, List[asyncio.Queue]] = {}
_sse_history: Dict[str, List[Dict[str, Any]]] = {}

# Instantiate core engines
audio_processor = AudioProcessor(target_sr=16000)
transcriber = Transcriber(model_size="base")
flaw_detector = FlawDetector()
video_processor = VideoProcessor(target_fps=1.0)
llm_explainer = LLMExplainer()


def broadcast_sse(analysis_id: str, stage: str, progress: int, message: str, data: Optional[Dict[str, Any]] = None):
    """Store and broadcast an SSE event to all connected listeners for an analysis."""
    event = {
        "analysis_id": analysis_id,
        "stage": stage,
        "progress": progress,
        "message": message,
        "data": data or {},
    }

    if analysis_id not in _sse_history:
        _sse_history[analysis_id] = []
    _sse_history[analysis_id].append(event)

    # Broadcast to active queues
    queues = _sse_queues.get(analysis_id, [])
    for q in queues:
        try:
            q.put_nowait(event)
        except Exception:
            pass


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for database initialization and directory readiness."""
    settings = get_settings()
    logger.info("Initializing database and storage directories...")
    init_db(str(settings.db_file_path))
    settings.upload_path
    seed_contrastive_dataset()
    logger.info(f"Database ready at: {settings.db_file_path}")
    logger.info(f"Upload directory ready at: {settings.upload_path}")
    yield
    logger.info("Shutting down JARVIS backend application.")


app = FastAPI(
    title="JARVIS Speech Analysis Backend",
    description="High-precision speech analysis, acoustic flaw detection, and AI speech coaching backend.",
    version="1.0.0",
    lifespan=lifespan,
)

settings = get_settings()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS + ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -----------------------------------------------------------------------------
# Background Pipeline Execution
# -----------------------------------------------------------------------------
def _execute_pipeline_sync(analysis_id: str, raw_path: str, wav_path: str, filename: str):
    """Synchronous pipeline run executed in a worker thread."""
    try:
        # Determine container capabilities
        is_video = video_processor.is_video_file(raw_path)
        has_audio = video_processor.has_audio_stream(raw_path)
        visual_metrics: Optional[Dict[str, Any]] = None
        visual_findings: List[Dict[str, Any]] = []

        # Video Presentation Processing (Requirement 2)
        if is_video:
            broadcast_sse(analysis_id, "preprocessing", 10, "Extracting video frames and analyzing visual presentation metrics...")
            update_analysis_record(analysis_id, status="preprocessing", media_type="video")
            vis_result = video_processor.analyze_presentation(raw_path)
            visual_metrics = vis_result.get("metrics", {})
            visual_findings = vis_result.get("findings", [])

        # Speech & Audio Processing
        transcript_data: Dict[str, Any] = {"text": "", "language": "en", "segments": [], "words": []}
        features: Dict[str, Any] = {}
        detected_flaws: List[Dict[str, Any]] = []
        duration_sec = 0.0

        if has_audio:
            # Stage 1: Preprocessing Audio
            broadcast_sse(analysis_id, "preprocessing", 25, "Extracting and normalizing audio track to 16kHz mono WAV...")
            update_analysis_record(analysis_id, status="preprocessing", audio_path=wav_path)
            meta = audio_processor.preprocess(raw_path, wav_path)
            duration_sec = meta.get("duration", 0.0)
            update_analysis_record(analysis_id, duration_seconds=duration_sec)

            # Stage 2: Transcription with Whisper ASR
            broadcast_sse(analysis_id, "transcription", 45, "Transcribing speech and extracting word-level timestamps...")
            update_analysis_record(analysis_id, status="transcribing")
            transcript_data = transcriber.transcribe(wav_path)

            # Stage 3: Alignment verification
            word_count = len(transcript_data.get("words", []))
            broadcast_sse(
                analysis_id,
                "alignment",
                60,
                f"Aligned {word_count} words across {len(transcript_data.get('segments', []))} phrases.",
                {"word_count": word_count},
            )

            # Stage 4: Acoustic Feature Extraction
            broadcast_sse(analysis_id, "feature_extraction", 75, "Computing acoustic parameters (pYIN F0, RMS energy, spectral features)...")
            update_analysis_record(analysis_id, status="extracting_features")
            features = audio_processor.extract_features(wav_path)

            # Stage 5: Speech Flaw Detection
            broadcast_sse(analysis_id, "flaw_detection", 85, "Analyzing acoustic metrics for 10 delivery flaws...")
            update_analysis_record(analysis_id, status="detecting_flaws")
            detected_flaws = flaw_detector.detect_flaws(transcript_data, features, wav_path)

        else:
            # Video contains NO audio track (Requirement 5)
            if visual_metrics:
                duration_sec = float(visual_metrics.get("duration_seconds", 0.0))
            update_analysis_record(analysis_id, duration_seconds=duration_sec)
            features = {
                "duration": duration_sec,
                "speaking_rate": {"overall_syl_per_sec": 0.0, "estimated_syllables": 0, "rate_windows": []},
                "pitch": {"times": [], "f0": [], "mean_f0": 0.0, "std_f0": 0.0, "min_f0": 0.0, "max_f0": 0.0},
                "rms": {"times": [], "values": [], "mean_rms": 0.0, "std_rms": 0.0},
                "pauses": [],
                "errors": ["No audio track found in media container."],
            }
            detected_flaws = [{
                "id": "flaw_no_audio",
                "category": "missing_audio_track",
                "start_time": 0.0,
                "end_time": round(max(1.0, duration_sec), 2),
                "severity": "high",
                "confidence": 1.0,
                "evidence": {
                    "metric_name": "audio_streams",
                    "measured_value": 0,
                    "threshold": 1,
                    "unit": "streams",
                },
                "description": "Uploaded video file has no audio stream. Speech prosody and vocal analysis require an audio track.",
                "suggestion": "Record with your microphone enabled to evaluate vocal pace, pitch variation, and cadence.",
            }]

        # Merge and synchronize audio and visual findings by timestamp
        all_findings = detected_flaws + visual_findings
        all_findings.sort(key=lambda x: x.get("start_time", 0.0))

        # Re-number deterministic IDs
        for idx, f in enumerate(all_findings):
            f["id"] = f"finding_{idx + 1}_{f.get('category', 'flaw')}"

        # Attach visual metrics to features dictionary for client inspection
        if is_video and visual_metrics:
            features["visual"] = visual_metrics

        # Stage 6: Calculate Deterministic Component Scores (Requirement 4)
        scores = compute_component_scores(
            features,
            all_findings,
            transcript_data,
            is_video=is_video,
            visual_metrics=visual_metrics,
            has_audio=has_audio,
        )

        # Stage 7: Grounded Coaching Explanations (LLM / Rule-based)
        broadcast_sse(analysis_id, "explanation", 95, "Synthesizing evidence-grounded coaching recommendations...")
        update_analysis_record(analysis_id, status="explaining")
        enriched_findings = llm_explainer.explain_findings(
            all_findings,
            transcript_data.get("text", ""),
            features,
        )

        # Clean storage features (strip large raw arrays before JSON DB storage)
        compact_features = dict(features)
        if "pitch" in compact_features:
            compact_features["pitch"] = {
                k: v for k, v in compact_features["pitch"].items() if not k.startswith("_raw")
            }
        if "rms" in compact_features:
            compact_features["rms"] = {
                k: v for k, v in compact_features["rms"].items() if not k.startswith("_raw")
            }

        # Stage 8: Persist to database
        db = get_db()
        update_analysis_record(
            analysis_id,
            status="completed",
            transcript=json.dumps(transcript_data),
            findings_json=json.dumps(enriched_findings),
            metrics_json=json.dumps(compact_features),
            scores_json=json.dumps(scores),
            duration_seconds=duration_sec,
            media_type="video" if is_video else "audio",
        )

        # Populate dataset_entries for future benchmark / fine-tuning
        try:
            for item in enriched_findings:
                db["dataset_entries"].insert({
                    "id": str(uuid.uuid4()),
                    "analysis_id": analysis_id,
                    "transcript": transcript_data.get("text", ""),
                    "speaker_id": "default",
                    "category": item.get("category", ""),
                    "severity": item.get("severity", ""),
                    "timestamps_json": json.dumps({
                        "start_time": item.get("start_time"),
                        "end_time": item.get("end_time"),
                    }),
                    "features_json": json.dumps(item.get("evidence", {})),
                    "provenance": "jarvis_pipeline_v2",
                })
        except Exception as e:
            logger.warning(f"Could not populate dataset_entries: {e}")

        broadcast_sse(
            analysis_id,
            "complete",
            100,
            f"Analysis complete. Score: {scores['overall']}/100 ({scores['grade']}). Detected {len(enriched_findings)} observations.",
            {
                "total_flaws": len(enriched_findings),
                "duration": duration_sec,
                "scores": scores,
            },
        )
        logger.info(f"Pipeline successfully completed for analysis: {analysis_id}")

    except Exception as e:
        logger.error(f"Pipeline failed for analysis {analysis_id}: {e}", exc_info=True)
        update_analysis_record(analysis_id, status="failed")
        broadcast_sse(
            analysis_id,
            "error",
            100,
            f"Analysis encountered an error: {str(e)}",
            {"error": str(e)},
        )


async def run_analysis_pipeline(analysis_id: str, raw_path: str, wav_path: str, filename: str):
    """Offload audio processing pipeline to a worker thread so event loop remains unblocked."""
    await asyncio.to_thread(_execute_pipeline_sync, analysis_id, raw_path, wav_path, filename)


# -----------------------------------------------------------------------------
# Request / Response Models
# -----------------------------------------------------------------------------
class TranscriptUpdateRequest(BaseModel):
    transcript: str = Field(..., description="Corrected transcript text")


# -----------------------------------------------------------------------------
# Endpoints
# -----------------------------------------------------------------------------
@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok", "app": "JARVIS Speech Backend"}


@app.post("/api/upload")
async def upload_audio(
    file: UploadFile = File(...),
    background_tasks: BackgroundTasks = BackgroundTasks(),
):
    """
    Accept audio/video file upload (multipart).
    Validates SHA-256 content hash for genuine caching, saves file,
    creates analysis record, and starts the processing pipeline.
    """
    settings = get_settings()
    filename = file.filename or "audio_sample.wav"
    analysis_id = str(uuid.uuid4())

    # Create destination paths
    raw_ext = Path(filename).suffix or ".wav"
    raw_filename = f"{analysis_id}_raw{raw_ext}"
    raw_path = str(settings.upload_path / raw_filename)
    wav_filename = f"{analysis_id}.wav"
    wav_path = str(settings.upload_path / wav_filename)

    # Stream file to disk while validating size and computing content SHA-256
    total_bytes = 0
    max_bytes = settings.max_upload_bytes
    sha256_hasher = hashlib.sha256()

    try:
        async with aiofiles.open(raw_path, "wb") as out_file:
            while chunk := await file.read(1024 * 1024):  # 1MB chunks
                total_bytes += len(chunk)
                if total_bytes > max_bytes:
                    raise HTTPException(
                        status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        detail=f"Uploaded file exceeds maximum limit of {settings.MAX_UPLOAD_MB}MB.",
                    )
                sha256_hasher.update(chunk)
                await out_file.write(chunk)
    except HTTPException:
        if os.path.exists(raw_path):
            os.remove(raw_path)
        raise
    except Exception as e:
        if os.path.exists(raw_path):
            os.remove(raw_path)
        raise HTTPException(status_code=500, detail=f"Failed to save upload: {str(e)}")

    content_hash = sha256_hasher.hexdigest()
    is_video = video_processor.is_video_file(raw_path)
    media_type = "video" if is_video else "audio"

    # Requirement 3: Check genuine content cache match
    cached_record = find_cached_analysis(content_hash)
    if cached_record and cached_record.get("status") in {"completed", "complete"}:
        logger.info(f"Identical content hash match ({content_hash[:12]}...). Returning verified cached analysis {cached_record['id']}")
        # Clean up temporary raw upload file since cache matches
        if os.path.exists(raw_path):
            os.remove(raw_path)
        return {
            "analysis_id": cached_record["id"],
            "filename": filename,
            "status": "completed",
            "message": "Content hash matched existing verified analysis. Loaded from cache.",
            "cached": True,
        }

    # Initialize analysis record in database
    create_analysis_record(
        analysis_id=analysis_id,
        filename=filename,
        audio_path=wav_path,
        status="queued",
        content_hash=content_hash,
        media_type=media_type,
    )

    # Initialize SSE history
    broadcast_sse(analysis_id, "queued", 5, "Media file received and queued for analysis.")

    # Start pipeline in background
    background_tasks.add_task(run_analysis_pipeline, analysis_id, raw_path, wav_path, filename)

    return {
        "analysis_id": analysis_id,
        "filename": filename,
        "status": "queued",
        "message": "File uploaded successfully. Processing initiated.",
    }


@app.get("/api/analysis/{analysis_id}")
async def get_analysis(analysis_id: str):
    """Return full analysis result including transcript, findings, metrics, and deterministic scores."""
    record = get_analysis_record(analysis_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")

    # Parse transcript if stored as JSON string
    raw_transcript = record.get("transcript", "")
    transcript_obj = None
    if isinstance(raw_transcript, str) and raw_transcript.startswith("{"):
        try:
            transcript_obj = json.loads(raw_transcript)
        except Exception:
            transcript_obj = {"text": raw_transcript}
    else:
        transcript_obj = {"text": raw_transcript or ""}

    record["transcript"] = transcript_obj

    # If scores not computed in older record, compute dynamically now
    if not record.get("scores"):
        record["scores"] = compute_component_scores(
            record.get("metrics") or {},
            record.get("findings") or [],
            transcript_obj,
            is_video=record.get("media_type") == "video",
            visual_metrics=(record.get("metrics") or {}).get("visual"),
            has_audio=bool(record.get("audio_path")),
        )

    return record


@app.get("/api/analysis/{analysis_id}/status")
async def get_analysis_status(analysis_id: str, request: Request):
    """
    SSE endpoint streaming real-time pipeline status updates:
    {stage, progress, message, data}.
    Stages: 'preprocessing', 'transcription', 'alignment', 'feature_extraction',
            'flaw_detection', 'explanation', 'complete', 'error'.
    """
    record = get_analysis_record(analysis_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")

    queue: asyncio.Queue = asyncio.Queue()
    if analysis_id not in _sse_queues:
        _sse_queues[analysis_id] = []
    _sse_queues[analysis_id].append(queue)

    async def event_generator() -> AsyncGenerator[Dict[str, Any], None]:
        try:
            # Yield any historical events first
            history = list(_sse_history.get(analysis_id, []))
            for past_event in history:
                yield {
                    "event": "message",
                    "data": json.dumps(past_event),
                }

            # If already complete or failed, send completion event and terminate
            current_status = record.get("status")
            if current_status in {"completed", "complete", "failed", "error"}:
                if not history:
                    yield {
                        "event": "message",
                        "data": json.dumps({
                            "stage": "complete" if current_status in {"completed", "complete"} else "error",
                            "progress": 100,
                            "message": "Analysis completed." if current_status in {"completed", "complete"} else "Analysis encountered an error.",
                            "data": {}
                        })
                    }
                return

            # Stream incoming events
            while True:
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=20.0)
                    yield {
                        "event": "message",
                        "data": json.dumps(event),
                    }
                    if event.get("stage") in {"complete", "error"}:
                        break
                except asyncio.TimeoutError:
                    # Send keep-alive comment
                    yield {"event": "ping", "data": "keep-alive"}
        finally:
            if analysis_id in _sse_queues and queue in _sse_queues[analysis_id]:
                _sse_queues[analysis_id].remove(queue)

    return EventSourceResponse(event_generator())


@app.get("/api/analysis/{analysis_id}/audio")
async def get_audio_file(analysis_id: str):
    """Serve the normalized audio file for playback in frontend."""
    record = get_analysis_record(analysis_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")

    audio_path = record.get("audio_path")
    if not audio_path or not os.path.exists(audio_path):
        raise HTTPException(status_code=404, detail="Audio file not found on disk.")

    return FileResponse(
        path=audio_path,
        media_type="audio/wav",
        filename=f"{record.get('filename', analysis_id)}.wav",
    )


@app.get("/api/analysis/{analysis_id}/waveform")
async def get_waveform(analysis_id: str, num_points: int = Query(2000, ge=100, le=10000)):
    """Return downsampled waveform points normalized between -1.0 and 1.0 for visualization."""
    record = get_analysis_record(analysis_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")

    audio_path = record.get("audio_path")
    if not audio_path or not os.path.exists(audio_path):
        raise HTTPException(status_code=404, detail="Audio file not found on disk.")

    waveform = await asyncio.to_thread(audio_processor.get_waveform_data, audio_path, num_points)
    return {
        "analysis_id": analysis_id,
        "num_points": len(waveform),
        "waveform": waveform,
    }


@app.get("/api/analyses")
async def list_analyses(
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
):
    """List all analyses with pagination."""
    return list_analyses_records(limit=limit, offset=offset)


@app.delete("/api/analysis/{analysis_id}")
async def delete_analysis(analysis_id: str):
    """Delete an analysis record and remove its audio files from disk."""
    record = get_analysis_record(analysis_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")

    settings = get_settings()
    # Remove associated files
    for f in settings.upload_path.glob(f"{analysis_id}*"):
        try:
            if f.is_file():
                f.unlink()
        except Exception as e:
            logger.warning(f"Could not remove file {f}: {e}")

    deleted = delete_analysis_record(analysis_id)
    # Clear in-memory event buffers
    _sse_history.pop(analysis_id, None)
    _sse_queues.pop(analysis_id, None)

    return {"deleted": deleted, "analysis_id": analysis_id}


@app.put("/api/analysis/{analysis_id}/transcript")
async def update_transcript(analysis_id: str, payload: TranscriptUpdateRequest):
    """Update transcript after user manual correction."""
    record = get_analysis_record(analysis_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")

    existing_transcript_raw = record.get("transcript", "")
    updated_transcript_dict = {"text": payload.transcript, "segments": [], "words": []}

    # If existing transcript was structured dict, preserve word metadata where possible
    if isinstance(existing_transcript_raw, dict):
        updated_transcript_dict["words"] = existing_transcript_raw.get("words", [])
        updated_transcript_dict["segments"] = existing_transcript_raw.get("segments", [])
    elif isinstance(existing_transcript_raw, str) and existing_transcript_raw.startswith("{"):
        try:
            parsed = json.loads(existing_transcript_raw)
            updated_transcript_dict["words"] = parsed.get("words", [])
            updated_transcript_dict["segments"] = parsed.get("segments", [])
        except Exception:
            pass

    updated_record = update_analysis_record(
        analysis_id,
        transcript=json.dumps(updated_transcript_dict),
    )
    return updated_record


@app.get("/api/analysis/{analysis_id}/export/json")
async def export_analysis_json(analysis_id: str):
    """Export full analysis record as a downloadable JSON file."""
    record = get_analysis_record(analysis_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")

    clean_filename = f"jarvis_analysis_{analysis_id}.json"
    return JSONResponse(
        content=record,
        headers={"Content-Disposition": f'attachment; filename="{clean_filename}"'},
    )


@app.post("/api/analysis/{analysis_id}/reanalyze")
async def reanalyze_speech(analysis_id: str, background_tasks: BackgroundTasks):
    """Re-run flaw detection and LLM explanation on existing audio features with current transcript."""
    record = get_analysis_record(analysis_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")

    audio_path = record.get("audio_path")
    if not audio_path or not os.path.exists(audio_path):
        raise HTTPException(status_code=400, detail="Audio file not found on disk.")

    raw_transcript = record.get("transcript", {})
    if isinstance(raw_transcript, str):
        try:
            transcript_data = json.loads(raw_transcript)
        except Exception:
            transcript_data = {"text": raw_transcript, "words": [], "segments": []}
    else:
        transcript_data = raw_transcript

    def _reanalyze_sync():
        try:
            broadcast_sse(analysis_id, "flaw_detection", 50, "Re-running acoustic flaw detection...")
            features = audio_processor.extract_features(audio_path)
            detected_flaws = flaw_detector.detect_flaws(transcript_data, features, audio_path)

            broadcast_sse(analysis_id, "explanation", 80, "Generating updated coaching explanations...")
            enriched_findings = llm_explainer.explain_findings(
                detected_flaws,
                transcript_data.get("text", ""),
                features,
            )

            update_analysis_record(
                analysis_id,
                status="completed",
                findings_json=json.dumps(enriched_findings),
            )

            broadcast_sse(
                analysis_id,
                "complete",
                100,
                f"Re-analysis complete. {len(enriched_findings)} opportunities identified.",
                {"total_flaws": len(enriched_findings)},
            )
        except Exception as e:
            logger.error(f"Reanalysis failed for {analysis_id}: {e}", exc_info=True)
            broadcast_sse(analysis_id, "error", 100, f"Re-analysis failed: {str(e)}")

    background_tasks.add_task(asyncio.to_thread, _reanalyze_sync)
    return {"message": "Re-analysis started in background.", "analysis_id": analysis_id}


# -----------------------------------------------------------------------------
# Media URL Ingestion (YouTube & Direct Audio/Video URLs)
# -----------------------------------------------------------------------------
class UrlAnalysisRequest(BaseModel):
    url: str = Field(..., description="YouTube or direct audio/video media URL")


@app.post("/api/analyze-url")
async def analyze_url(
    payload: UrlAnalysisRequest,
    background_tasks: BackgroundTasks,
):
    """
    Download audio stream from YouTube or supported media URL using yt-dlp,
    then execute the end-to-end JARVIS pipeline in the background.
    """
    settings = get_settings()
    analysis_id = str(uuid.uuid4())
    url = payload.url.strip()

    if not url:
        raise HTTPException(status_code=400, detail="A valid media URL is required.")

    raw_filename = f"{analysis_id}_download.wav"
    raw_path = str(settings.upload_path / raw_filename)
    wav_path = str(settings.upload_path / f"{analysis_id}.wav")

    def _download_and_process():
        broadcast_sse(analysis_id, "preprocessing", 10, f"Fetching media stream from URL: {url[:50]}...")
        try:
            import yt_dlp

            # Use resolved ffmpeg from imageio-ffmpeg
            ffmpeg_location = None
            try:
                import imageio_ffmpeg
                ffmpeg_location = os.path.dirname(imageio_ffmpeg.get_ffmpeg_exe())
            except Exception:
                pass

            # Check if this is a direct audio file URL (e.g. .mp3, .wav, .m4a)
            lower_url = url.lower().split("?")[0]
            is_direct_audio = any(lower_url.endswith(ext) for ext in [".wav", ".mp3", ".m4a", ".mp4", ".ogg", ".flac", ".aac"])

            candidate_wav = None
            stream_title = "Online Audio Stream"

            if is_direct_audio:
                broadcast_sse(analysis_id, "preprocessing", 15, "Downloading direct media stream...")
                download_dest = str(settings.upload_path / f"{analysis_id}_direct.wav")
                with httpx.stream("GET", url, timeout=40.0, follow_redirects=True) as resp:
                    resp.raise_for_status()
                    with open(download_dest, "wb") as f_out:
                        for chunk in resp.iter_bytes(chunk_size=1024 * 64):
                            f_out.write(chunk)
                candidate_wav = download_dest
                stream_title = os.path.basename(lower_url)
            else:
                ydl_opts: Dict[str, Any] = {
                    "format": "bestaudio/best",
                    "outtmpl": str(settings.upload_path / f"{analysis_id}_dl.%(ext)s"),
                    "extractor_args": {
                        "youtube": {
                            "player_client": ["android", "ios", "mweb", "web"],
                        }
                    },
                    "http_headers": {
                        "User-Agent": (
                            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                            "AppleWebKit/537.36 (KHTML, like Gecko) "
                            "Chrome/128.0.0.0 Safari/537.36"
                        ),
                        "Accept": "*/*",
                        "Accept-Language": "en-US,en;q=0.9",
                    },
                    "postprocessors": [
                        {
                            "key": "FFmpegExtractAudio",
                            "preferredcodec": "wav",
                            "preferredquality": "192",
                        }
                    ],
                    "quiet": True,
                    "no_warnings": True,
                    "nocheckcertificate": True,
                }
                if ffmpeg_location:
                    ydl_opts["ffmpeg_location"] = ffmpeg_location

                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(url, download=True)
                    downloaded_file = ydl.prepare_filename(info)
                    candidate_wav = os.path.splitext(downloaded_file)[0] + ".wav"
                    if not os.path.exists(candidate_wav):
                        candidate_wav = downloaded_file
                    stream_title = info.get("title", "Online Stream")

            # Standardize to 16kHz mono WAV
            audio_processor.preprocess(candidate_wav, wav_path)

            # Proceed with pipeline
            _execute_pipeline_sync(analysis_id, candidate_wav, wav_path, stream_title)

        except Exception as e:
            err_str = str(e)
            logger.error(f"Failed to ingest URL {url}: {err_str}", exc_info=True)
            user_msg = f"URL ingestion failed: {err_str}"
            if "403" in err_str or "Forbidden" in err_str:
                user_msg = (
                    "YouTube restricted direct stream access (HTTP 403 Forbidden). "
                    "YouTube anti-bot protections frequently restrict server-side stream access. "
                    "Please download the audio/video file and use the 'File Upload' tab as the reliable fallback."
                )
            update_analysis_record(analysis_id, status="failed")
            broadcast_sse(analysis_id, "error", 100, user_msg, {"error": user_msg})

    # Initialize analysis record in database
    create_analysis_record(
        analysis_id=analysis_id,
        filename=f"URL Stream: {url[:35]}...",
        audio_path=wav_path,
        status="queued",
    )
    broadcast_sse(analysis_id, "queued", 5, "URL queued for streaming and acoustic extraction.")
    background_tasks.add_task(asyncio.to_thread, _download_and_process)

    return {
        "analysis_id": analysis_id,
        "status": "queued",
        "url": url,
        "message": "Media download and analysis pipeline initiated.",
    }


# -----------------------------------------------------------------------------
# PDF Report Export
# -----------------------------------------------------------------------------
@app.get("/api/analysis/{analysis_id}/export/pdf")
async def export_analysis_pdf(analysis_id: str):
    """Generate and download executive PDF diagnostic report with acoustic proof."""
    record = get_analysis_record(analysis_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")

    settings = get_settings()
    pdf_filename = f"jarvis_report_{analysis_id}.pdf"
    pdf_path = str(settings.upload_path / pdf_filename)

    try:
        await asyncio.to_thread(generate_pdf_report, record, pdf_path)
    except Exception as e:
        logger.error(f"PDF generation failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"PDF generation failed: {str(e)}")

    return FileResponse(
        path=pdf_path,
        media_type="application/pdf",
        filename=f"JARVIS_Diagnostic_Report_{record.get('filename', analysis_id)}.pdf",
    )


# -----------------------------------------------------------------------------
# Reference Delivery Comparison
# -----------------------------------------------------------------------------
@app.get("/api/analysis/{analysis_id}/compare")
async def compare_analysis(analysis_id: str):
    """Compare speaker delivery against standard studio benchmark."""
    record = get_analysis_record(analysis_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")

    metrics = record.get("metrics", {})
    transcript = record.get("transcript", {})
    text = transcript.get("text", "") if isinstance(transcript, dict) else str(transcript)

    comparison = compare_with_reference(metrics, text)
    return {
        "analysis_id": analysis_id,
        "filename": record.get("filename"),
        "comparison": comparison,
    }


# -----------------------------------------------------------------------------
# Contrastive Dataset & Benchmarks
# -----------------------------------------------------------------------------
@app.get("/api/dataset")
async def list_dataset(limit: int = Query(50, ge=1, le=100)):
    """Retrieve contrastive dataset samples containing good, flawed, and graded delivery examples."""
    samples = get_contrastive_samples(limit=limit)
    return {"total": len(samples), "samples": samples}


@app.post("/api/dataset/seed")
async def seed_dataset():
    """Seed benchmark dataset samples into persistent storage."""
    seed_contrastive_dataset()
    return {"message": "Contrastive dataset benchmark seeded successfully."}


# -----------------------------------------------------------------------------
# Evaluation Pipeline
# -----------------------------------------------------------------------------
class BenchmarkEvaluationRequest(BaseModel):
    analysis_id: str = Field(..., description="Target analysis ID to evaluate against ground truth")
    ground_truth: List[Dict[str, Any]] = Field(..., description="Annotated flaw intervals with categories")
    iou_threshold: float = Field(0.3, ge=0.1, le=0.9, description="Minimum IoU overlap to consider a true positive")


@app.post("/api/evaluation/benchmark")
async def evaluate_analysis_benchmark(payload: BenchmarkEvaluationRequest):
    """
    Run evaluation pipeline calculating precision, recall, F1, mean IoU,
    severity accuracy, and false positive count against provided ground truth annotations.
    """
    record = get_analysis_record(payload.analysis_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")

    predictions = record.get("findings", [])
    results = evaluate_flaw_detections(
        predictions=predictions,
        ground_truth=payload.ground_truth,
        iou_threshold=payload.iou_threshold,
    )
    return {
        "analysis_id": payload.analysis_id,
        "evaluation": results,
    }

