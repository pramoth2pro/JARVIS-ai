"""End-to-end verification script for JARVIS speech intelligence engine."""

import os
import sys
import numpy as np
import soundfile as sf

from app.audio_processor import AudioProcessor
from app.flaw_detector import FlawDetector
from app.llm_explainer import LLMExplainer
from app.pdf_exporter import generate_pdf_report
from app.dataset_manager import compare_with_reference, seed_contrastive_dataset
from app.evaluation import evaluate_flaw_detections

def run_test():
    print("=== JARVIS End-to-End Pipeline Verification ===")

    sr = 16000
    duration = 8.0
    t = np.linspace(0, duration, int(sr * duration), endpoint=False)

    # Synthesize speech-like signal:
    # 0.0s - 2.5s: active speech (f0 = 130 Hz with formants)
    # 2.5s - 5.0s: silence / awkward long pause (2.5s > 2.0s threshold)
    # 5.0s - 8.0s: monotone speech (flat 110 Hz, minimal variation)
    signal = np.zeros_like(t)

    # Segment 1 (0 to 2.5s)
    idx1 = (t >= 0.0) & (t < 2.5)
    f0_1 = 130.0 + 30.0 * np.sin(2 * np.pi * 1.5 * t[idx1])
    carrier1 = np.sin(2 * np.pi * f0_1 * t[idx1])
    formant1 = 0.5 * np.sin(2 * np.pi * 800 * t[idx1]) + 0.3 * np.sin(2 * np.pi * 1800 * t[idx1])
    signal[idx1] = (carrier1 + formant1) * 0.4

    # Segment 2 (2.5s to 5.0s) -> Silence / pause
    # (Left at 0.0)

    # Segment 3 (5.0s to 8.0s) -> Flat monotone pitch 110Hz
    idx3 = (t >= 5.0) & (t <= 8.0)
    carrier3 = np.sin(2 * np.pi * 110.0 * t[idx3])
    formant3 = 0.4 * np.sin(2 * np.pi * 700 * t[idx3])
    signal[idx3] = (carrier3 + formant3) * 0.3

    test_wav = os.path.abspath("test_sample.wav")
    sf.write(test_wav, signal.astype(np.float32), sr)
    print(f"[1/7] Generated synthetic benchmark audio: {test_wav} ({duration}s)")

    # 1. Preprocess
    proc = AudioProcessor(target_sr=16000)
    prep_wav = os.path.abspath("test_processed.wav")
    meta = proc.preprocess(test_wav, prep_wav)
    print(f"[2/7] AudioProcessor.preprocess completed: {meta['duration']}s, {meta['channels']} channel, {meta['sample_rate']}Hz")
    assert meta["duration"] > 0, "Duration must be positive"

    # 2. Feature extraction
    features = proc.extract_features(prep_wav)
    print(f"[3/7] Acoustic features extracted successfully:")
    print(f"      - Mean F0: {features['pitch']['mean_f0']} Hz, Std F0: {features['pitch']['std_f0']} Hz")
    print(f"      - Mean RMS: {features['rms']['mean_rms']}")
    print(f"      - Speaking rate: {features['speaking_rate']['overall_syl_per_sec']} syl/s")
    print(f"      - Pauses detected: {len(features['pauses'])}")

    # 3. Flaw Detection
    sample_transcript = {
        "text": "Um welcome to the presentation. The quarterly performance is stable.",
        "language": "en",
        "segments": [
            {"start": 0.0, "end": 2.5, "text": "Um welcome to the presentation."},
            {"start": 5.0, "end": 8.0, "text": "The quarterly performance is stable."},
        ],
        "words": [
            {"word": "Um", "start": 0.1, "end": 0.4, "probability": 0.95},
            {"word": "welcome", "start": 0.5, "end": 0.9, "probability": 0.98},
            {"word": "to", "start": 1.0, "end": 1.2, "probability": 0.99},
            {"word": "the", "start": 1.3, "end": 1.5, "probability": 0.99},
            {"word": "presentation.", "start": 1.6, "end": 2.4, "probability": 0.97},
            {"word": "The", "start": 5.0, "end": 5.3, "probability": 0.96},
            {"word": "quarterly", "start": 5.4, "end": 6.1, "probability": 0.95},
            {"word": "performance", "start": 6.2, "end": 7.0, "probability": 0.96},
            {"word": "is", "start": 7.1, "end": 7.3, "probability": 0.98},
            {"word": "stable.", "start": 7.4, "end": 7.9, "probability": 0.98},
        ],
    }
    detector = FlawDetector()
    flaws = detector.detect_flaws(sample_transcript, features, prep_wav)
    print(f"[4/7] FlawDetector identified {len(flaws)} temporal flaw instances:")
    for f in flaws:
        print(f"      - [{f['severity'].upper()}] {f['category']} at {f['start_time']}s-{f['end_time']}s: {f['description']}")

    # Check that expected flaws were triggered
    categories = [f["category"] for f in flaws]
    assert "long_pause" in categories or "awkward_pause" in categories, "Expected pause flaw to be detected"
    assert "filler_word" in categories, "Expected filler word 'Um' to be detected"

    # 4. LLM Explainer (Rule-based grounded fallback)
    explainer = LLMExplainer()
    enriched = explainer.explain_findings(flaws, sample_transcript["text"], features)
    print(f"[5/7] LLM Explainer synthesized grounded explanations for {len(enriched)} findings:")
    for e in enriched[:2]:
        print(f"      - {e['category']}: {e['explanation'][:70]}...")
        print(f"        Drill: {e['recommendation'][:70]}...")

    # 5. PDF Report Generation
    mock_analysis = {
        "id": "test_e2e_001",
        "filename": "test_sample.wav",
        "duration_seconds": meta["duration"],
        "metrics": features,
        "findings": enriched,
        "transcript": sample_transcript,
    }
    pdf_out = os.path.abspath("test_report.pdf")
    generate_pdf_report(mock_analysis, pdf_out)
    print(f"[6/7] PDF report created: {pdf_out} (Size: {os.path.getsize(pdf_out)} bytes)")
    assert os.path.exists(pdf_out) and os.path.getsize(pdf_out) > 500, "PDF must exist and be non-empty"

    # 6. Benchmark Evaluation & Reference Comparison
    ground_truth = [
        {"id": "gt_1", "category": "filler_word", "start_time": 0.1, "end_time": 0.4, "severity": "low"},
        {"id": "gt_2", "category": "long_pause", "start_time": 2.5, "end_time": 5.0, "severity": "medium"},
    ]
    eval_res = evaluate_flaw_detections(enriched, ground_truth, iou_threshold=0.3)
    print(f"[7/7] Evaluation against ground truth:")
    print(f"      - Precision: {eval_res['precision']}, Recall: {eval_res['recall']}, F1: {eval_res['f1']}")
    print(f"      - Mean IoU: {eval_res['mean_iou']}, Severity Acc: {eval_res['severity_accuracy']}")

    comp = compare_with_reference(features, sample_transcript["text"])
    print(f"      - Reference Assessment: Pace={comp['assessment']['rate_status']}, Pitch={comp['assessment']['inflection_status']}")

    # Clean up test files
    for p in [test_wav, prep_wav, pdf_out]:
        if os.path.exists(p):
            try:
                os.remove(p)
            except Exception:
                pass

    print("\n>>> ALL JARVIS PIPELINE STAGES PASSED VERIFICATION WITH REAL ACOUSTIC DATA! <<<")

if __name__ == "__main__":
    run_test()
