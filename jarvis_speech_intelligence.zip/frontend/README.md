# JARVIS Speech Intelligence - Frontend

A Next.js 14 React & TypeScript dashboard engineered with a dark graphite/cyan Iron Man JARVIS aesthetic for speech prosody, acoustic telemetry, and vocal flaw diagnostics.

## Features
- **Acoustic Waveform Player**: WaveSurfer.js rendering with colored flaw overlays (Red = High, Orange = Medium, Cyan = Low), click-to-seek, and segment loop/play.
- **Neural Speech Transcript Editor**: Interactive word-level timestamps, finding overlays, real-time audio synchronization, and editing mode.
- **Diagnostic Metric Cards**: Speaking rate (syl/s), F0 average pitch, pitch variation (std dev), energy consistency (RMS), pause statistics, filler words count, and speech score.
- **Acoustic Time-series Charts**: Recharts integration for Pitch (F0), Vocal Energy (RMS), Segmental Rate, and MFCC/Spectral analysis.
- **Prosodic Findings Panel**: Categorized flaws with severity badges, measured evidence vs thresholds, actionable suggestions, and expandable deep LLM diagnostics.
- **Real-Time Pipeline Status**: Live SSE event synchronization across audio ingestion, conditioning, transcription, feature extraction, and LLM reasoning.
- **Session Archives**: History list with replay, deletion, and full JSON telemetry export.

## Getting Started

### 1. Install dependencies
```bash
npm install
```

### 2. Run Development Server
```bash
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000) to view the application.

### Configuration
Set backend API endpoint in `.env.local` if running on a custom port:
```env
NEXT_PUBLIC_API_URL=http://localhost:8000
```
