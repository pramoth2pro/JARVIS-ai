export interface Analysis {
  id: string;
  filename: string;
  status:
    | 'uploading'
    | 'queued'
    | 'preprocessing'
    | 'transcribing'
    | 'extracting'
    | 'extracting_features'
    | 'detecting'
    | 'detecting_flaws'
    | 'explaining'
    | 'complete'
    | 'completed'
    | 'error'
    | 'failed';
  created_at: string;
  duration_seconds?: number;
  transcript?: TranscriptResult;
  findings?: Finding[];
  metrics?: AcousticMetrics;
  waveform?: number[];
  error?: string;
  scores?: SpeechScores;
  media_type?: 'audio' | 'video';
  content_hash?: string;
}

export interface ComponentScore {
  score: number | null;
  weight: number;
  grade: string;
  status: 'good' | 'warning' | 'poor' | 'unavailable_no_audio' | 'audio_only';
  evidence?: Record<string, any>;
}

export interface SpeechScores {
  overall: number;
  grade: string;
  is_video?: boolean;
  has_audio?: boolean;
  components: {
    grammar: ComponentScore;
    fluency: ComponentScore;
    pace: ComponentScore;
    vocal_delivery: ComponentScore;
    visual_presentation?: ComponentScore;
  };
  scoring_formula?: string;
}

export interface TranscriptResult {
  text: string;
  segments: TranscriptSegment[];
  words: TranscriptWord[];
  language?: string;
}

export interface TranscriptSegment {
  start: number;
  end: number;
  text: string;
}

export interface TranscriptWord {
  word: string;
  start: number;
  end: number;
  probability: number;
}

export interface Finding {
  id: string;
  category: string;
  start_time: number;
  end_time: number;
  severity: 'low' | 'medium' | 'high';
  confidence: number;
  evidence: {
    metric_name: string;
    measured_value: number;
    threshold: number;
    unit: string;
  };
  description: string;
  suggestion: string;
  explanation?: string;
  recommendation?: string;
}

export interface AcousticMetrics {
  duration?: number;
  pitch: {
    times: number[];
    f0: (number | null)[];
    mean_f0: number;
    std_f0: number;
    min_f0: number;
    max_f0: number;
    // Aliases for convenience
    values?: number[];
    mean?: number;
    std?: number;
  };
  rms: {
    times: number[];
    values: number[];
    mean_rms: number;
    std_rms: number;
    min_rms: number;
    max_rms: number;
  };
  // Alias used by charts
  energy?: {
    times: number[];
    values: number[];
    mean: number;
    std: number;
  };
  speaking_rate: {
    overall_syl_per_sec: number;
    estimated_syllables: number;
    active_speech_time?: number;
    rate_windows: {
      start: number;
      end: number;
      rate: number;
    }[];
    // Alias
    overall?: number;
    segments?: {
      start: number;
      end: number;
      rate: number;
    }[];
  };
  pauses: {
    start: number;
    end: number;
    duration: number;
  }[];
  mfcc: {
    mean: number[];
    std: number[];
    n_mfcc?: number;
    times?: number[];
    coefficients?: number[][];
  };
  spectral: {
    centroid_mean: number;
    bandwidth_mean: number;
    rolloff_mean: number;
    centroid?: {
      times: number[];
      values: number[];
    };
    bandwidth?: {
      times: number[];
      values: number[];
    };
  };
  zcr?: {
    mean: number;
    std: number;
  };
  errors?: string[];
}

export interface SSEEvent {
  stage: string;
  progress: number;
  message: string;
  data?: any;
}

export interface PipelineStageInfo {
  id: Analysis['status'];
  label: string;
  description: string;
}
