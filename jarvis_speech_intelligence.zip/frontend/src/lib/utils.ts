import { clsx, type ClassValue } from 'clsx';
import { format, parseISO } from 'date-fns';
import { Finding } from '@/types';

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

export function formatTime(seconds?: number): string {
  if (seconds === undefined || isNaN(seconds) || seconds < 0) {
    return '00:00';
  }
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 10);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms}`;
}

export function formatDuration(seconds?: number): string {
  if (!seconds || isNaN(seconds)) return '0s';
  if (seconds < 60) return `${Math.round(seconds)}s`;
  const mins = Math.floor(seconds / 60);
  const secs = Math.round(seconds % 60);
  return `${mins}m ${secs}s`;
}

export function formatDate(dateString?: string): string {
  if (!dateString) return 'Just now';
  try {
    const date = parseISO(dateString);
    return format(date, 'MMM d, yyyy HH:mm');
  } catch {
    return dateString;
  }
}

export function getSeverityBadge(severity: 'low' | 'medium' | 'high') {
  switch (severity) {
    case 'high':
      return {
        bg: 'bg-accent/20 border-accent/60 text-accent',
        dot: 'bg-accent shadow-[0_0_8px_#e94560]',
        label: 'Critical',
      };
    case 'medium':
      return {
        bg: 'bg-amber-500/20 border-amber-500/60 text-amber-400',
        dot: 'bg-amber-400 shadow-[0_0_8px_#f59e0b]',
        label: 'Moderate',
      };
    case 'low':
      return {
        bg: 'bg-cyan-400/20 border-cyan-400/60 text-cyan-400',
        dot: 'bg-cyan-400 shadow-[0_0_8px_#00d4ff]',
        label: 'Minor',
      };
    default:
      return {
        bg: 'bg-gray-500/20 border-gray-500/60 text-gray-400',
        dot: 'bg-gray-400',
        label: severity,
      };
  }
}

export function calculateSpeechScore(findings?: Finding[]): {
  score: number;
  grade: string;
  color: string;
} {
  if (!findings || findings.length === 0) {
    return { score: 98, grade: 'A+', color: 'text-cyan-400' };
  }

  // Deduct based on severity
  let deduction = 0;
  for (const f of findings) {
    if (f.severity === 'high') deduction += 12;
    else if (f.severity === 'medium') deduction += 6;
    else deduction += 2.5;
  }

  const score = Math.max(10, Math.min(100, Math.round(100 - deduction)));

  let grade = 'A+';
  let color = 'text-cyan-400';

  if (score >= 90) {
    grade = 'A';
    color = 'text-cyan-400';
  } else if (score >= 80) {
    grade = 'B+';
    color = 'text-emerald-400';
  } else if (score >= 70) {
    grade = 'B';
    color = 'text-amber-400';
  } else if (score >= 60) {
    grade = 'C';
    color = 'text-orange-400';
  } else {
    grade = 'Needs Work';
    color = 'text-accent';
  }

  return { score, grade, color };
}
