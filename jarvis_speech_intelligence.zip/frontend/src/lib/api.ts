import { Analysis, SSEEvent } from '@/types';

export const API_BASE =
  process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export async function uploadAudio(
  file: File,
  onProgress?: (percent: number) => void
): Promise<{ analysis_id: string }> {
  return new Promise((resolve, reject) => {
    const formData = new FormData();
    formData.append('file', file);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', `${API_BASE}/api/upload`);

    if (xhr.upload && onProgress) {
      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          const percent = Math.round((event.loaded / event.total) * 100);
          onProgress(percent);
        }
      };
    }

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const data = JSON.parse(xhr.responseText);
          // Backend may return analysis_id or id
          const analysis_id = data.analysis_id || data.id;
          if (!analysis_id) {
            reject(new Error('Invalid response: missing analysis_id'));
          } else {
            resolve({ analysis_id });
          }
        } catch {
          reject(new Error('Failed to parse response JSON'));
        }
      } else {
        try {
          const errData = JSON.parse(xhr.responseText);
          reject(new Error(errData.detail || errData.message || `Upload failed (${xhr.status})`));
        } catch {
          reject(new Error(`Upload failed with status code ${xhr.status}`));
        }
      }
    };

    xhr.onerror = () => {
      reject(new Error('Network error during upload'));
    };

    xhr.send(formData);
  });
}

export async function getAnalysis(id: string): Promise<Analysis> {
  const res = await fetch(`${API_BASE}/api/analysis/${id}`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
    cache: 'no-store',
  });

  if (!res.ok) {
    const errorText = await res.text().catch(() => '');
    throw new Error(
      `Failed to fetch analysis ${id}: ${res.status} ${errorText}`
    );
  }

  const data = await res.json();
  return data;
}

export async function getAnalyses(): Promise<Analysis[]> {
  try {
    const res = await fetch(`${API_BASE}/api/analyses`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
      cache: 'no-store',
    });

    if (!res.ok) {
      // Fallback check if endpoint is /api/history
      const altRes = await fetch(`${API_BASE}/api/history`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
        cache: 'no-store',
      });
      if (!altRes.ok) {
        throw new Error(`Failed to list analyses (${res.status})`);
      }
      const altData = await altRes.json();
      return Array.isArray(altData) ? altData : altData.analyses || [];
    }

    const data = await res.json();
    return Array.isArray(data) ? data : data.items || data.analyses || [];
  } catch (err: any) {
    console.error('Error in getAnalyses:', err);
    throw err;
  }
}

export async function updateTranscript(
  id: string,
  text: string
): Promise<void> {
  const res = await fetch(`${API_BASE}/api/analysis/${id}/transcript`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ transcript: text }),
  });

  if (!res.ok) {
    const err = await res.text().catch(() => '');
    throw new Error(`Failed to update transcript: ${res.status} ${err}`);
  }
}

export async function deleteAnalysis(id: string): Promise<void> {
  const res = await fetch(`${API_BASE}/api/analysis/${id}`, {
    method: 'DELETE',
  });

  if (!res.ok) {
    throw new Error(`Failed to delete analysis: ${res.status}`);
  }
}

export async function reanalyze(id: string): Promise<void> {
  const res = await fetch(`${API_BASE}/api/analysis/${id}/reanalyze`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!res.ok) {
    throw new Error(`Failed to trigger reanalysis: ${res.status}`);
  }
}

export function getAudioUrl(id: string): string {
  return `${API_BASE}/api/analysis/${id}/audio`;
}

export function getExportUrl(id: string): string {
  return `${API_BASE}/api/analysis/${id}/export/json`;
}

export function getExportPdfUrl(id: string): string {
  return `${API_BASE}/api/analysis/${id}/export/pdf`;
}

export async function analyzeUrl(url: string): Promise<{ analysis_id: string }> {
  const res = await fetch(`${API_BASE}/api/analyze-url`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ url }),
  });

  if (!res.ok) {
    const err = await res.text().catch(() => '');
    throw new Error(`URL analysis failed: ${res.status} ${err}`);
  }

  return await res.json();
}

export async function getComparison(id: string): Promise<any> {
  const res = await fetch(`${API_BASE}/api/analysis/${id}/compare`, {
    method: 'GET',
    headers: { 'Content-Type': 'application/json' },
    cache: 'no-store',
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch comparison: ${res.status}`);
  }
  return await res.json();
}

export function subscribeToStatus(
  id: string,
  onEvent: (event: SSEEvent) => void,
  onError?: (err: Event) => void
): EventSource {
  const eventSource = new EventSource(`${API_BASE}/api/analysis/${id}/status`);

  eventSource.onmessage = (e) => {
    try {
      const data: SSEEvent = JSON.parse(e.data);
      onEvent(data);
    } catch (err) {
      console.warn('Failed to parse SSE payload:', e.data, err);
    }
  };

  // Also support custom event types if the backend emits event: stage / event: progress
  eventSource.addEventListener('progress', (e: any) => {
    try {
      const data = JSON.parse(e.data);
      onEvent(data);
    } catch (err) {
      console.warn('Failed to parse progress event:', err);
    }
  });

  eventSource.addEventListener('stage', (e: any) => {
    try {
      const data = JSON.parse(e.data);
      onEvent(data);
    } catch (err) {
      console.warn('Failed to parse stage event:', err);
    }
  });

  eventSource.onerror = (err) => {
    console.warn('SSE connection warning/error:', err);
    if (onError) onError(err);
  };

  return eventSource;
}
