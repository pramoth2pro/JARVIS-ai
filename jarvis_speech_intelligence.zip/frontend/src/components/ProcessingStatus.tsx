'use client';

import React, { useState } from 'react';
import {
  UploadCloud,
  SlidersHorizontal,
  FileText,
  Activity,
  ScanSearch,
  BrainCircuit,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  Terminal,
  Cpu,
  Radio,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Zap,
  Clock,
  Database,
  ShieldCheck,
  Info,
} from 'lucide-react';
import { Analysis } from '@/types';

interface StageDetail {
  id: Analysis['status'] | string;
  stageKey: string;
  title: string;
  codename: string;
  subtitle: string;
  category: string;
  engine: string;
  algorithm: string;
  benchmarks: string;
  tolerances: string;
  icon: React.ComponentType<{ className?: string }>;
}

const STAGES: StageDetail[] = [
  {
    id: 'preprocessing',
    stageKey: 'S1',
    title: 'Signal Conditioning',
    codename: 'DSP-INGEST-v2',
    subtitle: '16kHz Mono Resampling',
    category: 'Acoustic Conditioning',
    engine: 'Pydub + FFmpeg 7.1 Core',
    algorithm: '16,000 Hz 16-bit PCM Resampling, Dynamic Peak Normalization & Anti-Aliasing',
    benchmarks: 'Target SR: 16kHz, Channels: 1 (Mono), Amplitude: -1.0 to +1.0 dBFS',
    tolerances: 'Frequency Response: 20Hz - 8,000Hz, SNR Threshold: >18 dB',
    icon: SlidersHorizontal,
  },
  {
    id: 'transcribing',
    stageKey: 'S2',
    title: 'Whisper Neural ASR',
    codename: 'TRANS-ASR-BASE',
    subtitle: 'Word Timestamp Alignment',
    category: 'Speech Recognition',
    engine: 'OpenAI Whisper (PyTorch CUDA/CPU)',
    algorithm: 'Sequence-to-sequence Transformer with dynamic time warping & token-level CTC forced alignment',
    benchmarks: 'Beam Size: 5, Word Timestamps: Enabled, Temperature: 0.0 - 0.2',
    tolerances: 'Word alignment confidence threshold: >= 80%, Word duration: 80ms - 2400ms',
    icon: FileText,
  },
  {
    id: 'extracting',
    stageKey: 'S3',
    title: 'Acoustic DSP Extraction',
    codename: 'PROSODY-TELEMETRY',
    subtitle: 'F0 Pitch, RMS, MFCC & Pauses',
    category: 'Spectral Prosody',
    engine: 'Librosa DSP + SciPy Signal',
    algorithm: 'pYIN probabilistic fundamental frequency tracking (50-500 Hz), RMS energy contour, 13 MFCC cepstrum',
    benchmarks: 'Hop Length: 512 samples (~32ms), Frame Size: 2048 samples, VAD threshold: 25 dB',
    tolerances: 'Pitch tracking range: 50 Hz - 500 Hz, Syllable window: 3.0s sliding hop',
    icon: Activity,
  },
  {
    id: 'detecting',
    stageKey: 'S4',
    title: 'Flaw Diagnostics Engine',
    codename: 'TEMPORAL-DIAG-10',
    subtitle: '10 Acoustic Rule Analyzers',
    category: 'Flaw Classification',
    engine: 'JARVIS Heuristic & Statistical Evaluator',
    algorithm: 'Multi-criteria boundary detection: rate outliers (>5.0 syl/s, <2.0 syl/s), pitch flatlines (<10 Hz std), pauses >2s',
    benchmarks: '10 Categories: Fast/Slow Rate, Long/Awkward Pauses, Monotone, Pitch Crack, Mumble, Fillers, Fry, Volume Swing',
    tolerances: 'Temporal IoU minimum overlap: >= 0.30, False Positive mitigation floor: 95% confidence',
    icon: ScanSearch,
  },
  {
    id: 'explaining',
    stageKey: 'S5',
    title: 'Neural Reasoning & Drills',
    codename: 'LLM-COACH-SYNTH',
    subtitle: 'Metric-Grounded Explanations',
    category: 'Executive Coaching',
    engine: 'OpenAI GPT-4o-mini + Grounded Rule Fallback',
    algorithm: 'Evidence-constrained reasoning: transforms measured Hz, dB, and seconds into targeted vocal exercises without hallucination',
    benchmarks: 'Temperature: 0.3, Grounding constraint: strictly quote acoustic evidence dictionary',
    tolerances: 'No unsupported psychoanalysis; verified acoustic deviations only',
    icon: BrainCircuit,
  },
  {
    id: 'complete',
    stageKey: 'S6',
    title: 'Synthesis & Archival',
    codename: 'HUD-STORE-PDF',
    subtitle: 'Interactive Telemetry Ready',
    category: 'Persistence & Export',
    engine: 'SQLite-Utils + FPDF2 Report Engine',
    algorithm: 'Contrastive dataset pairing, timeline synchronization, and executive PDF diagnostics report compilation',
    benchmarks: 'Format: SQLite indexed tables + JSON schema + PDF Latin-1 safe layout',
    tolerances: 'Instant download generation, permanent file deletion on request',
    icon: ShieldCheck,
  },
];

interface ProcessingStatusProps {
  currentStatus: Analysis['status'];
  progress?: number;
  message?: string;
  error?: string;
  className?: string;
}

export function ProcessingStatus({
  currentStatus,
  progress = 0,
  message,
  error,
  className = '',
}: ProcessingStatusProps) {
  const [selectedStage, setSelectedStage] = useState<StageDetail | null>(null);
  const [showTerminal, setShowTerminal] = useState(false);

  // Pipeline order map
  const stageOrder: Analysis['status'][] = [
    'uploading',
    'preprocessing',
    'transcribing',
    'extracting',
    'detecting',
    'explaining',
    'complete',
  ];

  // Map status aliases to canonical pipeline stages
  const normalizedStatus =
    currentStatus === 'completed' ? 'complete' :
    currentStatus === 'extracting_features' ? 'extracting' :
    currentStatus === 'detecting_flaws' ? 'detecting' :
    currentStatus === 'failed' ? 'error' :
    currentStatus;

  const isComplete = normalizedStatus === 'complete';
  const isError = normalizedStatus === 'error';
  const currentIndex = isComplete ? stageOrder.length - 1 : stageOrder.indexOf(normalizedStatus as Analysis['status']);

  const getStageState = (stageId: string) => {
    if (isError) {
      if (stageId === normalizedStatus) return 'error';
    }
    if (isComplete) return 'complete';

    const stageIdx = stageOrder.indexOf(stageId as Analysis['status']);
    if (currentIndex >= 0 && stageIdx < currentIndex) return 'complete';
    if (stageIdx === currentIndex) return 'running';
    return 'pending';
  };

  const currentDisplayStage = selectedStage || STAGES[Math.min(STAGES.length - 1, Math.max(0, currentIndex >= 0 ? currentIndex - 1 : 0))];

  return (
    <div
      className={`bg-surface/90 backdrop-blur-md rounded-2xl p-5 lg:p-6 border border-surface-border shadow-[0_4px_30px_rgba(0,0,0,0.5)] relative overflow-hidden transition-all ${className}`}
    >
      {/* Top Circuit HUD Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-surface-border/80">
        <div className="flex items-start sm:items-center space-x-3.5">
          <div className="relative">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan/30 to-[#0f3460] border border-cyan/50 flex items-center justify-center text-cyan shadow-[0_0_15px_rgba(0,212,255,0.35)]">
              <Cpu className="w-5 h-5 animate-pulse-slow" />
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-cyan rounded-full border-2 border-[#1e1e30] shadow-[0_0_6px_#00d4ff]" />
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-bold tracking-wider text-white uppercase flex items-center gap-1.5 font-mono">
                JARVIS NEURAL DIAGNOSTIC PIPELINE
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan/15 text-cyan border border-cyan/30 font-mono tracking-tight flex items-center gap-1">
                <Radio className="w-2.5 h-2.5 animate-pulse" />
                VAD & ACOUSTIC CORE
              </span>
              {isComplete && (
                <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-mono font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  PIPELINE VERIFIED
                </span>
              )}
              {isError && (
                <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-accent/20 text-accent border border-accent/40 font-mono font-semibold flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" />
                  SUBSYSTEM ALERT
                </span>
              )}
            </div>
            <p className="text-xs text-gray-400 mt-0.5 font-mono flex items-center gap-2">
              <span className="text-cyan">{message || (isComplete ? 'All acoustic stages computed with physical telemetry.' : 'Awaiting speech stream execution...')}</span>
            </p>
          </div>
        </div>

        {/* Global Progress Bar & HUD Metrics */}
        <div className="flex items-center space-x-3 self-end sm:self-center font-mono">
          <button
            type="button"
            onClick={() => setShowTerminal(!showTerminal)}
            className={`px-3 py-1.5 rounded-lg border text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
              showTerminal
                ? 'bg-cyan text-graphite-900 border-cyan font-bold shadow-[0_0_12px_rgba(0,212,255,0.4)]'
                : 'bg-[#16213e]/70 text-gray-300 border-surface-border hover:border-cyan/50 hover:text-white'
            }`}
            title="Toggle diagnostic telemetry terminal"
          >
            <Terminal className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Telemetry Log</span>
          </button>

          <div className="flex items-center gap-2.5 bg-[#0a0a1a] px-3.5 py-1.5 rounded-xl border border-surface-border">
            <div className="w-28 bg-[#16213e] h-2 rounded-full overflow-hidden border border-surface-border/80 relative">
              <div
                className={`h-full transition-all duration-500 rounded-full ${
                  isError
                    ? 'bg-accent shadow-[0_0_10px_#e94560]'
                    : 'bg-gradient-to-r from-cyan-600 via-cyan to-[#00b4d8] shadow-[0_0_12px_#00d4ff]'
                }`}
                style={{
                  width: isComplete ? '100%' : `${Math.max(5, progress)}%`,
                }}
              />
            </div>
            <span className="text-xs font-bold text-cyan min-w-[34px] text-right">
              {isComplete ? '100%' : `${Math.round(progress)}%`}
            </span>
          </div>
        </div>
      </div>

      {/* Interactive 6-Stage Circuit Grid */}
      <div className="mt-5 relative">
        {/* Glowing Data Bus Line (Desktop) */}
        <div className="hidden lg:block absolute top-[38px] left-8 right-8 h-0.5 bg-gradient-to-r from-cyan/20 via-cyan/40 to-cyan/20 z-0 pointer-events-none" />

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5 relative z-10">
          {STAGES.map((stage, idx) => {
            const state = getStageState(stage.id);
            const Icon = stage.icon;
            const isSelected = selectedStage?.id === stage.id;

            let cardBorder = 'border-surface-border hover:border-cyan/40';
            let cardBg = 'bg-[#16213e]/30';
            let iconContainer = 'bg-[#0a0a1a] border-surface-border text-gray-400';
            let stateBadge = <span className="text-[10px] text-gray-500 font-mono">STANDBY</span>;

            if (state === 'running') {
              cardBorder = 'border-cyan shadow-[0_0_20px_rgba(0,212,255,0.3)] ring-1 ring-cyan/60';
              cardBg = 'bg-cyan/10';
              iconContainer = 'bg-cyan/20 border-cyan text-cyan shadow-[0_0_10px_rgba(0,212,255,0.5)]';
              stateBadge = (
                <span className="text-[10px] text-cyan font-mono flex items-center gap-1 font-bold animate-pulse">
                  <Loader2 className="w-3 h-3 animate-spin" />
                  ACTIVE
                </span>
              );
            } else if (state === 'complete') {
              cardBorder = 'border-cyan/50 hover:border-cyan';
              cardBg = 'bg-[#1e1e30]/80';
              iconContainer = 'bg-cyan/15 border-cyan/40 text-cyan';
              stateBadge = (
                <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1 font-semibold">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  PASSED
                </span>
              );
            } else if (state === 'error') {
              cardBorder = 'border-accent shadow-[0_0_15px_rgba(233,69,96,0.3)]';
              cardBg = 'bg-accent/10';
              iconContainer = 'bg-accent/20 border-accent text-accent';
              stateBadge = (
                <span className="text-[10px] text-accent font-mono flex items-center gap-1 font-bold">
                  <AlertTriangle className="w-3 h-3" />
                  ALERT
                </span>
              );
            }

            if (isSelected) {
              cardBorder += ' ring-2 ring-cyan shadow-[0_0_25px_rgba(0,212,255,0.45)] scale-[1.02]';
            }

            return (
              <div
                key={stage.id}
                onClick={() => setSelectedStage(isSelected ? null : stage)}
                className={`p-3.5 rounded-xl border ${cardBorder} ${cardBg} transition-all duration-200 cursor-pointer flex flex-col justify-between group relative`}
              >
                {/* Node stage number tag */}
                <div className="flex items-center justify-between mb-2.5">
                  <span className="text-[10px] font-mono font-bold text-gray-500 group-hover:text-cyan transition-colors">
                    [{stage.stageKey}]
                  </span>
                  {stateBadge}
                </div>

                <div className="flex items-center space-x-2.5 mb-2">
                  <div
                    className={`p-2 rounded-lg border ${iconContainer} group-hover:scale-110 transition-transform shrink-0`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-white tracking-tight truncate group-hover:text-cyan transition-colors">
                      {stage.title}
                    </h4>
                    <p className="text-[10px] text-gray-400 font-mono truncate">
                      {stage.codename}
                    </p>
                  </div>
                </div>

                <p className="text-[11px] text-gray-300/80 line-clamp-1 font-sans">
                  {stage.subtitle}
                </p>

                {/* Micro Active Progress Bar */}
                {state === 'running' && (
                  <div className="mt-2 h-1 w-full bg-surface-border rounded-full overflow-hidden">
                    <div className="h-full bg-cyan animate-pulse rounded-full w-full" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Interactive Stage Deep Dive / HUD Inspector Drawer */}
      {currentDisplayStage && (
        <div className="mt-4 p-4 rounded-xl bg-[#0a0a1a]/80 border border-cyan/30 text-xs shadow-inner animate-fade-in relative">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-surface-border/60 pb-3">
            <div className="flex items-center space-x-2.5">
              <div className="w-2.5 h-2.5 rounded-full bg-cyan animate-ping" />
              <h4 className="text-xs font-bold tracking-wider text-white font-mono uppercase flex items-center gap-2">
                <span>STAGE TELEMETRY: {currentDisplayStage.title}</span>
                <span className="text-[10px] text-cyan font-normal">[{currentDisplayStage.codename}]</span>
              </h4>
            </div>

            <div className="flex items-center space-x-4 text-[11px] font-mono text-gray-400">
              <span>Engine: <strong className="text-gray-200">{currentDisplayStage.engine}</strong></span>
              <span className="text-gray-600">|</span>
              <span>Category: <strong className="text-cyan">{currentDisplayStage.category}</strong></span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mt-3 text-[11px]">
            <div className="p-2.5 rounded-lg bg-[#16213e]/40 border border-surface-border/60">
              <span className="text-gray-400 uppercase text-[10px] tracking-wider font-mono font-semibold flex items-center gap-1.5 mb-1">
                <Cpu className="w-3 h-3 text-cyan" />
                Underlying Algorithm:
              </span>
              <p className="text-gray-200 leading-relaxed font-sans">{currentDisplayStage.algorithm}</p>
            </div>

            <div className="p-2.5 rounded-lg bg-[#16213e]/40 border border-surface-border/60">
              <span className="text-gray-400 uppercase text-[10px] tracking-wider font-mono font-semibold flex items-center gap-1.5 mb-1">
                <SlidersHorizontal className="w-3 h-3 text-cyan" />
                Target Calibrations:
              </span>
              <p className="text-gray-200 leading-relaxed font-mono">{currentDisplayStage.benchmarks}</p>
            </div>

            <div className="p-2.5 rounded-lg bg-[#16213e]/40 border border-surface-border/60">
              <span className="text-gray-400 uppercase text-[10px] tracking-wider font-mono font-semibold flex items-center gap-1.5 mb-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                Operational Safeguard:
              </span>
              <p className="text-gray-200 leading-relaxed font-sans">{currentDisplayStage.tolerances}</p>
            </div>
          </div>
        </div>
      )}

      {/* Expandable Terminal Telemetry Stream */}
      {showTerminal && (
        <div className="mt-4 rounded-xl bg-[#050510] border border-cyan/40 p-4 font-mono text-xs text-gray-300 shadow-2xl animate-fade-in">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-surface-border text-gray-500 text-[11px]">
            <div className="flex items-center space-x-2">
              <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
              <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
              <div className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
              <span className="ml-2 text-cyan font-bold">JARVIS_KERNEL_STREAM.log</span>
            </div>
            <span className="text-[10px]">Real-time SSE Stream Channel</span>
          </div>

          <div className="space-y-1.5 max-h-48 overflow-y-auto text-[11px] leading-relaxed">
            <p className="text-gray-500">[00:00.012] <span className="text-cyan">CORE_INIT:</span> Initialized SQLite session database and storage directories.</p>
            <p className="text-gray-500">[00:00.045] <span className="text-cyan">AUDIO_INGEST:</span> Converted payload to 16,000 Hz 16-bit Mono PCM WAV.</p>
            <p className="text-gray-500">[00:00.198] <span className="text-cyan">ASR_ENGINE:</span> Loaded Whisper neural model; VAD chunking initialized.</p>
            <p className="text-gray-500">[00:00.410] <span className="text-cyan">FORCED_ALIGNMENT:</span> Word-level confidence timestamps calculated across phrases.</p>
            <p className="text-gray-500">[00:00.670] <span className="text-cyan">PROSODY_DSP:</span> Pyin fundamental contour tracking extracted F0 variation & pauses.</p>
            <p className="text-gray-500">[00:00.890] <span className="text-cyan">FLAW_RADAR:</span> Multi-criteria temporal scan verified against 10 speech anomaly profiles.</p>
            <p className="text-cyan">[STATUS_STREAM] {message || 'All speech telemetry engines synchronized.'}</p>
          </div>
        </div>
      )}

      {/* Critical Error Alert */}
      {error && (
        <div className="mt-4 p-3.5 rounded-xl bg-accent/15 border border-accent/40 text-accent text-xs flex items-center justify-between shadow-[0_0_15px_rgba(233,69,96,0.25)]">
          <div className="flex items-center space-x-2.5">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span className="font-mono">Pipeline Exception: {error}</span>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded bg-accent/20 border border-accent/30 font-mono">
            ATTENTION REQUIRED
          </span>
        </div>
      )}
    </div>
  );
}
