'use client';

import React from 'react';
import {
  Mic,
  Activity,
  TrendingUp,
  Zap,
  PauseCircle,
  MessageSquareWarning,
  ShieldAlert,
  Award,
  BookOpen,
  Volume2,
  Video,
  CheckCircle2,
  AlertTriangle,
  Info,
} from 'lucide-react';
import { AcousticMetrics, Finding, SpeechScores } from '@/types';
import { calculateSpeechScore } from '@/lib/utils';

interface MetricCardsProps {
  metrics?: AcousticMetrics;
  findings?: Finding[];
  scores?: SpeechScores;
  is_video?: boolean;
}

export function MetricCards({ metrics, findings = [], scores, is_video = false }: MetricCardsProps) {
  // 1. Overall Score calculation
  const fallbackScore = calculateSpeechScore(findings);
  const overallScore = scores ? scores.overall : fallbackScore.score;
  const overallGrade = scores ? scores.grade : fallbackScore.grade;

  // 2. Speaking Rate (syl/s)
  const speakingRate =
    metrics?.speaking_rate?.overall_syl_per_sec ??
    metrics?.speaking_rate?.overall ??
    0;
  let rateStatus: 'good' | 'warning' | 'poor' = 'good';
  let rateLabel = 'Optimal';
  if (speakingRate > 5.2) {
    rateStatus = 'warning';
    rateLabel = 'Rapid';
  } else if (speakingRate > 0 && speakingRate < 3.2) {
    rateStatus = 'warning';
    rateLabel = 'Deliberate / Slow';
  } else if (speakingRate === 0) {
    rateStatus = 'poor';
    rateLabel = 'N/A';
  }

  // 3. Average Pitch (Hz)
  const meanPitch = metrics?.pitch?.mean_f0 ?? metrics?.pitch?.mean ?? 0;
  let pitchStatus: 'good' | 'warning' | 'poor' = 'good';
  if (meanPitch === 0) pitchStatus = 'poor';

  // 4. Pitch Variation (Std dev)
  const stdPitch = metrics?.pitch?.std_f0 ?? metrics?.pitch?.std ?? 0;
  let variationStatus: 'good' | 'warning' | 'poor' = 'good';
  let variationLabel = 'Dynamic';
  if (stdPitch < 16 && stdPitch > 0) {
    variationStatus = 'poor';
    variationLabel = 'Monotone Risk';
  } else if (stdPitch > 65) {
    variationStatus = 'warning';
    variationLabel = 'High Fluctuations';
  }

  // 5. Energy Consistency (%)
  let energyConsistency = 0;
  const rmsMean = metrics?.rms?.mean_rms ?? metrics?.energy?.mean;
  const rmsStd = metrics?.rms?.std_rms ?? metrics?.energy?.std;
  if (rmsMean !== undefined && rmsStd !== undefined && rmsMean > 0) {
    const cv = rmsStd / rmsMean;
    energyConsistency = Math.max(10, Math.min(100, Math.round((1 - Math.min(cv, 1)) * 100)));
  }
  let energyStatus: 'good' | 'warning' | 'poor' = 'good';
  if (energyConsistency < 60) energyStatus = 'poor';
  else if (energyConsistency < 75) energyStatus = 'warning';

  // 6. Pause Count & Duration
  const pauses = metrics?.pauses || [];
  const pauseCount = pauses.length;
  const totalPauseDuration = pauses.reduce((acc, p) => acc + (p.duration || 0), 0);

  // 7. Filler Words
  const fillers = findings.filter(
    (f) =>
      f.category.toLowerCase().includes('filler') ||
      f.category.toLowerCase().includes('hesitation')
  );
  const fillerCount = fillers.length;
  let fillerStatus: 'good' | 'warning' | 'poor' = 'good';
  if (fillerCount >= 4) fillerStatus = 'poor';
  else if (fillerCount >= 2) fillerStatus = 'warning';

  // 8. Total Findings breakdown
  const highSev = findings.filter((f) => f.severity === 'high').length;
  const medSev = findings.filter((f) => f.severity === 'medium').length;

  const getStatusIndicator = (status: 'good' | 'warning' | 'poor' | string) => {
    switch (status) {
      case 'good':
        return {
          pill: 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30',
          dot: 'bg-cyan-400 shadow-[0_0_6px_#00d4ff]',
        };
      case 'warning':
        return {
          pill: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
          dot: 'bg-amber-400 shadow-[0_0_6px_#f59e0b]',
        };
      case 'unavailable_no_audio':
      case 'audio_only':
        return {
          pill: 'bg-purple-500/15 text-purple-400 border-purple-500/30',
          dot: 'bg-purple-400',
        };
      case 'poor':
      default:
        return {
          pill: 'bg-accent/15 text-accent border-accent/30',
          dot: 'bg-accent shadow-[0_0_6px_#e94560]',
        };
    }
  };

  // Component Scores from deterministic backend rules
  const components = scores?.components;

  return (
    <div className="space-y-4">
      {/* 5-Component Deterministic Score Breakdown Banner */}
      <div className="bg-surface/90 backdrop-blur-md rounded-2xl p-5 border border-surface-border shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-surface-border gap-2">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-cyan/10 border border-cyan/30 text-cyan">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                DETERMINISTIC EVALUATION RADAR
                <span className="text-[10px] px-2 py-0.5 rounded bg-cyan/15 text-cyan border border-cyan/30 font-normal">
                  RULE ENGINE v2
                </span>
              </h3>
              <p className="text-xs text-gray-400 font-mono">
                {scores?.scoring_formula || 'Calculated from acoustic, linguistic, and visual measurements'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3 self-end sm:self-auto">
            <div className="text-right">
              <span className="text-[11px] text-gray-400 font-mono block">Overall Rating</span>
              <strong className="text-xl font-bold font-mono text-cyan tracking-tight">
                {overallScore}/100
              </strong>
            </div>
            <span className="px-3 py-1 rounded-xl bg-cyan/20 border border-cyan/40 text-cyan font-bold text-sm font-mono shadow-[0_0_12px_rgba(0,212,255,0.3)]">
              {overallGrade}
            </span>
          </div>
        </div>

        {/* 5 Separate Component Scores */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-4">
          {/* Component 1: Grammar */}
          <div className="bg-[#16213e]/60 rounded-xl p-3 border border-surface-border">
            <div className="flex items-center justify-between text-gray-400 mb-1">
              <span className="text-[11px] font-mono">1. Grammar</span>
              <BookOpen className="w-3.5 h-3.5 text-cyan" />
            </div>
            <div className="text-lg font-bold font-mono text-white">
              {components?.grammar?.score !== null && components?.grammar?.score !== undefined
                ? `${components.grammar.score}`
                : '--'}
              <span className="text-xs text-gray-400 font-normal">/100</span>
            </div>
            <span className="text-[10px] text-gray-400 font-mono block mt-1">
              {components?.grammar?.grade || 'Syntactic Flow'} ({(components?.grammar?.weight ?? 0.20) * 100}%)
            </span>
          </div>

          {/* Component 2: Fluency */}
          <div className="bg-[#16213e]/60 rounded-xl p-3 border border-surface-border">
            <div className="flex items-center justify-between text-gray-400 mb-1">
              <span className="text-[11px] font-mono">2. Fluency</span>
              <MessageSquareWarning className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="text-lg font-bold font-mono text-white">
              {components?.fluency?.score !== null && components?.fluency?.score !== undefined
                ? `${components.fluency.score}`
                : '--'}
              <span className="text-xs text-gray-400 font-normal">/100</span>
            </div>
            <span className="text-[10px] text-gray-400 font-mono block mt-1">
              {components?.fluency?.grade || 'Fillers & Pauses'} ({(components?.fluency?.weight ?? 0.30) * 100}%)
            </span>
          </div>

          {/* Component 3: Pace */}
          <div className="bg-[#16213e]/60 rounded-xl p-3 border border-surface-border">
            <div className="flex items-center justify-between text-gray-400 mb-1">
              <span className="text-[11px] font-mono">3. Pace</span>
              <Zap className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-lg font-bold font-mono text-white">
              {components?.pace?.score !== null && components?.pace?.score !== undefined
                ? `${components.pace.score}`
                : '--'}
              <span className="text-xs text-gray-400 font-normal">/100</span>
            </div>
            <span className="text-[10px] text-gray-400 font-mono block mt-1">
              {components?.pace?.grade || 'Syllable Tempo'} ({(components?.pace?.weight ?? 0.25) * 100}%)
            </span>
          </div>

          {/* Component 4: Vocal Delivery */}
          <div className="bg-[#16213e]/60 rounded-xl p-3 border border-surface-border">
            <div className="flex items-center justify-between text-gray-400 mb-1">
              <span className="text-[11px] font-mono">4. Vocal Delivery</span>
              <Volume2 className="w-3.5 h-3.5 text-cyan" />
            </div>
            <div className="text-lg font-bold font-mono text-white">
              {components?.vocal_delivery?.score !== null && components?.vocal_delivery?.score !== undefined
                ? `${components.vocal_delivery.score}`
                : '--'}
              <span className="text-xs text-gray-400 font-normal">/100</span>
            </div>
            <span className="text-[10px] text-gray-400 font-mono block mt-1">
              {components?.vocal_delivery?.grade || 'Pitch & Energy'} ({(components?.vocal_delivery?.weight ?? 0.25) * 100}%)
            </span>
          </div>

          {/* Component 5: Visual Presentation */}
          <div className="bg-[#16213e]/60 rounded-xl p-3 border border-surface-border col-span-2 md:col-span-1">
            <div className="flex items-center justify-between text-gray-400 mb-1">
              <span className="text-[11px] font-mono">5. Visual Presentation</span>
              <Video className="w-3.5 h-3.5 text-purple-400" />
            </div>
            <div className="text-lg font-bold font-mono text-white">
              {components?.visual_presentation?.score !== null && components?.visual_presentation?.score !== undefined
                ? `${components.visual_presentation.score}/100`
                : is_video
                ? 'Processing'
                : 'Audio Only'}
            </div>
            <span className="text-[10px] text-gray-400 font-mono block mt-1">
              {components?.visual_presentation?.score !== null && components?.visual_presentation?.score !== undefined
                ? `${components.visual_presentation.grade} (Lighting & Motion)`
                : is_video
                ? 'Video Frames'
                : 'N/A (Audio File)'}
            </span>
          </div>
        </div>
      </div>

      {/* Acoustic Measurement Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        {/* Speaking Rate */}
        <div className="bg-surface rounded-xl p-4 border border-surface-border shadow-md transition-all duration-200 group hover:border-cyan/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-gray-400 line-clamp-1">Speaking Rate</span>
            <div className="p-1.5 rounded-lg bg-[#16213e] text-cyan group-hover:scale-110 transition-transform">
              <Mic className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-1.5 my-1">
            <span className="text-2xl font-bold font-mono tracking-tight text-white">
              {speakingRate > 0 ? speakingRate.toFixed(1) : '--'}
            </span>
            <span className="text-xs text-gray-400 font-mono">syl / sec</span>
          </div>
          <div className="mt-2.5 flex items-center justify-between pt-2 border-t border-surface-border/50">
            <span className={`text-[10px] px-2 py-0.5 rounded-full border flex items-center gap-1.5 font-mono ${getStatusIndicator(rateStatus).pill}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${getStatusIndicator(rateStatus).dot}`} />
              {rateLabel}
            </span>
          </div>
        </div>

        {/* Fundamental Pitch */}
        <div className="bg-surface rounded-xl p-4 border border-surface-border shadow-md transition-all duration-200 group hover:border-cyan/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-gray-400 line-clamp-1">Average Pitch</span>
            <div className="p-1.5 rounded-lg bg-[#16213e] text-cyan group-hover:scale-110 transition-transform">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-1.5 my-1">
            <span className="text-2xl font-bold font-mono tracking-tight text-white">
              {meanPitch > 0 ? Math.round(meanPitch).toString() : '--'}
            </span>
            <span className="text-xs text-gray-400 font-mono">Hz (F0)</span>
          </div>
          <div className="mt-2.5 flex items-center justify-between pt-2 border-t border-surface-border/50">
            <span className={`text-[10px] px-2 py-0.5 rounded-full border flex items-center gap-1.5 font-mono ${getStatusIndicator(pitchStatus).pill}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${getStatusIndicator(pitchStatus).dot}`} />
              {meanPitch > 0 ? 'F0 Extracted' : 'No Voiced F0'}
            </span>
          </div>
        </div>

        {/* Pitch Variation */}
        <div className="bg-surface rounded-xl p-4 border border-surface-border shadow-md transition-all duration-200 group hover:border-cyan/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-gray-400 line-clamp-1">Pitch Variation</span>
            <div className="p-1.5 rounded-lg bg-[#16213e] text-cyan group-hover:scale-110 transition-transform">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-1.5 my-1">
            <span className="text-2xl font-bold font-mono tracking-tight text-white">
              {stdPitch > 0 ? `±${Math.round(stdPitch)}` : '--'}
            </span>
            <span className="text-xs text-gray-400 font-mono">Hz std</span>
          </div>
          <div className="mt-2.5 flex items-center justify-between pt-2 border-t border-surface-border/50">
            <span className={`text-[10px] px-2 py-0.5 rounded-full border flex items-center gap-1.5 font-mono ${getStatusIndicator(variationStatus).pill}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${getStatusIndicator(variationStatus).dot}`} />
              {variationLabel}
            </span>
          </div>
        </div>

        {/* Energy Consistency */}
        <div className="bg-surface rounded-xl p-4 border border-surface-border shadow-md transition-all duration-200 group hover:border-cyan/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-gray-400 line-clamp-1">Energy Stability</span>
            <div className="p-1.5 rounded-lg bg-[#16213e] text-cyan group-hover:scale-110 transition-transform">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-1.5 my-1">
            <span className="text-2xl font-bold font-mono tracking-tight text-white">
              {energyConsistency > 0 ? `${energyConsistency}%` : '--'}
            </span>
            <span className="text-xs text-gray-400 font-mono">RMS stability</span>
          </div>
          <div className="mt-2.5 flex items-center justify-between pt-2 border-t border-surface-border/50">
            <span className={`text-[10px] px-2 py-0.5 rounded-full border flex items-center gap-1.5 font-mono ${getStatusIndicator(energyStatus).pill}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${getStatusIndicator(energyStatus).dot}`} />
              {energyConsistency >= 75 ? 'Controlled' : energyConsistency >= 60 ? 'Fluctuating' : 'Uneven'}
            </span>
          </div>
        </div>

        {/* Pauses */}
        <div className="bg-surface rounded-xl p-4 border border-surface-border shadow-md transition-all duration-200 group hover:border-cyan/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-gray-400 line-clamp-1">Pauses & Silences</span>
            <div className="p-1.5 rounded-lg bg-[#16213e] text-cyan group-hover:scale-110 transition-transform">
              <PauseCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-1.5 my-1">
            <span className="text-2xl font-bold font-mono tracking-tight text-white">
              {pauseCount}
            </span>
            <span className="text-xs text-gray-400 font-mono">({totalPauseDuration.toFixed(1)}s total)</span>
          </div>
          <div className="mt-2.5 flex items-center justify-between pt-2 border-t border-surface-border/50">
            <span className="text-[10px] px-2 py-0.5 rounded-full border bg-cyan-500/15 text-cyan-400 border-cyan-500/30 flex items-center gap-1.5 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              &gt;0.3s intervals
            </span>
          </div>
        </div>

        {/* Fillers */}
        <div className="bg-surface rounded-xl p-4 border border-surface-border shadow-md transition-all duration-200 group hover:border-cyan/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-gray-400 line-clamp-1">Filler Words</span>
            <div className="p-1.5 rounded-lg bg-[#16213e] text-cyan group-hover:scale-110 transition-transform">
              <MessageSquareWarning className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-1.5 my-1">
            <span className="text-2xl font-bold font-mono tracking-tight text-white">
              {fillerCount}
            </span>
            <span className="text-xs text-gray-400 font-mono">detected</span>
          </div>
          <div className="mt-2.5 flex items-center justify-between pt-2 border-t border-surface-border/50">
            <span className={`text-[10px] px-2 py-0.5 rounded-full border flex items-center gap-1.5 font-mono ${getStatusIndicator(fillerStatus).pill}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${getStatusIndicator(fillerStatus).dot}`} />
              {fillerCount === 0 ? 'Clean' : fillerCount <= 3 ? 'Acceptable' : 'High Density'}
            </span>
          </div>
        </div>

        {/* Total Flaws & Observations */}
        <div className="bg-surface rounded-xl p-4 border border-surface-border shadow-md transition-all duration-200 group hover:border-cyan/50 col-span-2">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-gray-400 line-clamp-1">Diagnostic Observations</span>
            <div className="p-1.5 rounded-lg bg-[#16213e] text-cyan group-hover:scale-110 transition-transform">
              <ShieldAlert className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-1.5 my-1">
            <span className="text-2xl font-bold font-mono tracking-tight text-white">
              {findings.length}
            </span>
            <span className="text-xs text-gray-400 font-mono">findings ({highSev} critical, {medSev} moderate)</span>
          </div>
          <div className="mt-2.5 flex items-center justify-between pt-2 border-t border-surface-border/50">
            <span className={`text-[10px] px-2 py-0.5 rounded-full border flex items-center gap-1.5 font-mono ${
              highSev > 0 ? getStatusIndicator('poor').pill : medSev > 0 ? getStatusIndicator('warning').pill : getStatusIndicator('good').pill
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${
                highSev > 0 ? getStatusIndicator('poor').dot : medSev > 0 ? getStatusIndicator('warning').dot : getStatusIndicator('good').dot
              }`} />
              {highSev > 0 ? 'Urgent Improvements' : medSev > 0 ? 'Refinements Recommended' : 'Strong Polish'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
