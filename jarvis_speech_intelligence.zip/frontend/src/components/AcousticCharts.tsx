'use client';

import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
  ReferenceArea,
  Legend,
} from 'recharts';
import { Activity, Zap, Mic, Waves, BarChart2 } from 'lucide-react';
import { AcousticMetrics, Finding } from '@/types';
import { formatTime } from '@/lib/utils';

interface AcousticChartsProps {
  metrics?: AcousticMetrics;
  findings?: Finding[];
  currentTime?: number;
  onSeek?: (seconds: number) => void;
}

export function AcousticCharts({
  metrics,
  findings = [],
  currentTime = 0,
  onSeek,
}: AcousticChartsProps) {
  const [activeTab, setActiveTab] = useState<'pitch' | 'energy' | 'rate' | 'spectral'>('pitch');

  // Downsample helper to keep charts fluid and fast
  const downsample = <T,>(arr: T[], maxPoints = 250): T[] => {
    if (!arr || arr.length <= maxPoints) return arr;
    const step = Math.ceil(arr.length / maxPoints);
    const result: T[] = [];
    for (let i = 0; i < arr.length; i += step) {
      result.push(arr[i]);
    }
    return result;
  };

  // 1. Process Pitch Data - backend uses pitch.f0 not pitch.values
  const pitchData = useMemo(() => {
    const pitchTimes = metrics?.pitch?.times;
    const pitchValues = metrics?.pitch?.f0 || metrics?.pitch?.values;
    if (!pitchTimes || !pitchValues) return [];
    const raw = pitchTimes.map((t, i) => ({
      time: parseFloat(t.toFixed(2)),
      pitch: Math.round(pitchValues[i] || 0),
    }));
    return downsample(raw);
  }, [metrics?.pitch]);

  // 2. Process Energy Data - backend uses rms not energy
  const energyData = useMemo(() => {
    const rmsData = metrics?.rms || metrics?.energy;
    if (!rmsData?.times || !rmsData?.values) return [];
    const raw = rmsData.times.map((t, i) => ({
      time: parseFloat(t.toFixed(2)),
      energy: parseFloat((rmsData.values[i] || 0).toFixed(4)),
    }));
    return downsample(raw);
  }, [metrics?.rms, metrics?.energy]);

  // 3. Process Speaking Rate Segments Data - backend uses rate_windows not segments
  const rateData = useMemo(() => {
    const windows = metrics?.speaking_rate?.rate_windows || metrics?.speaking_rate?.segments;
    if (!windows) return [];
    return windows.map((seg, i) => ({
      segment: `S${i + 1}`,
      time: `${seg.start.toFixed(1)}s`,
      start: seg.start,
      end: seg.end,
      rate: parseFloat(seg.rate.toFixed(2)),
      optimal: 4.2,
    }));
  }, [metrics?.speaking_rate]);

  // 4. Process Spectral & MFCC Data
  const spectralData = useMemo(() => {
    if (metrics?.mfcc?.times && metrics.mfcc.coefficients?.length) {
      const times = metrics.mfcc.times;
      const coeffs = metrics.mfcc.coefficients;
      const raw = times.map((t, i) => {
        const coefRow = coeffs[i] || [];
        return {
          time: parseFloat(t.toFixed(2)),
          c1: parseFloat((coefRow[0] || 0).toFixed(2)),
          c2: parseFloat((coefRow[1] || 0).toFixed(2)),
          c3: parseFloat((coefRow[2] || 0).toFixed(2)),
        };
      });
      return downsample(raw);
    } else if (metrics?.spectral?.centroid?.times && metrics?.spectral?.centroid?.values) {
      const times = metrics.spectral.centroid.times;
      const centroids = metrics.spectral.centroid.values;
      const bandwidths = metrics.spectral.bandwidth?.values || [];
      const raw = times.map((t, i) => ({
        time: parseFloat(t.toFixed(2)),
        centroid: Math.round(centroids[i] || 0),
        bandwidth: Math.round(bandwidths[i] || 0),
      }));
      return downsample(raw);
    }
    return [];
  }, [metrics?.mfcc, metrics?.spectral]);

  const handleChartClick = (e: any) => {
    if (e && e.activeLabel !== undefined && onSeek) {
      const timeNum = parseFloat(e.activeLabel);
      if (!isNaN(timeNum)) {
        onSeek(timeNum);
      }
    }
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-[#1e1e30] border border-cyan/40 p-2.5 rounded-lg shadow-xl text-xs font-mono">
          <p className="text-gray-400 border-b border-surface-border pb-1 mb-1.5 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan" />
            Time: <strong className="text-white">{label}s</strong>
          </p>
          {payload.map((item: any, idx: number) => (
            <p key={idx} style={{ color: item.color }} className="flex justify-between gap-3">
              <span>{item.name}:</span>
              <span className="font-bold">{item.value}</span>
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-surface rounded-xl border border-surface-border shadow-lg p-5">
      {/* Top Controls: Title & Chart Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 border-b border-surface-border pb-3">
        <div>
          <h3 className="text-sm font-semibold tracking-wide text-white uppercase flex items-center gap-2">
            <Activity className="w-4 h-4 text-cyan" />
            Acoustic Signal Diagnostics
          </h3>
          <p className="text-xs text-gray-400 mt-0.5">
            High-precision prosodic trajectory synchronized to timeline
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center space-x-1 bg-[#0a0a1a] p-1 rounded-lg border border-surface-border">
          <button
            type="button"
            onClick={() => setActiveTab('pitch')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-1.5 ${
              activeTab === 'pitch'
                ? 'bg-cyan text-graphite-900 shadow-[0_0_10px_rgba(0,212,255,0.4)]'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Pitch (F0)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('energy')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-1.5 ${
              activeTab === 'energy'
                ? 'bg-cyan text-graphite-900 shadow-[0_0_10px_rgba(0,212,255,0.4)]'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Energy (RMS)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('rate')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-1.5 ${
              activeTab === 'rate'
                ? 'bg-cyan text-graphite-900 shadow-[0_0_10px_rgba(0,212,255,0.4)]'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Mic className="w-3.5 h-3.5" />
            <span>Speaking Rate</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('spectral')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-1.5 ${
              activeTab === 'spectral'
                ? 'bg-cyan text-graphite-900 shadow-[0_0_10px_rgba(0,212,255,0.4)]'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Waves className="w-3.5 h-3.5" />
            <span>MFCC / Spectral</span>
          </button>
        </div>
      </div>

      {/* Chart Viewport */}
      <div className="w-full h-72">
        {/* TAB 1: PITCH (F0) */}
        {activeTab === 'pitch' && (
          pitchData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={pitchData}
                onClick={handleChartClick}
                margin={{ top: 10, right: 20, left: 0, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#252540" />
                <XAxis
                  dataKey="time"
                  stroke="#64748b"
                  fontSize={11}
                  tickFormatter={(val) => `${val}s`}
                />
                <YAxis
                  stroke="#64748b"
                  fontSize={11}
                  domain={['dataMin - 20', 'dataMax + 20']}
                  unit=" Hz"
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: '11px' }} />

                {/* Shaded finding regions */}
                {findings.map((f, i) => (
                  <ReferenceArea
                    key={i}
                    x1={parseFloat(f.start_time.toFixed(2))}
                    x2={parseFloat(f.end_time.toFixed(2))}
                    fill={f.severity === 'high' ? '#e94560' : f.severity === 'medium' ? '#f59e0b' : '#00d4ff'}
                    fillOpacity={0.18}
                    strokeOpacity={0.3}
                  />
                ))}

                {/* Mean Pitch Guideline */}
                {(metrics?.pitch?.mean_f0 || metrics?.pitch?.mean) && (
                  <ReferenceLine
                    y={Math.round(metrics?.pitch?.mean_f0 || metrics?.pitch?.mean || 0)}
                    stroke="#00d4ff"
                    strokeDasharray="4 4"
                    label={{
                      value: `Mean: ${Math.round(metrics?.pitch?.mean_f0 || metrics?.pitch?.mean || 0)} Hz`,
                      fill: '#00d4ff',
                      fontSize: 10,
                      position: 'insideBottomRight',
                    }}
                  />
                )}

                {/* Playhead Marker */}
                {currentTime > 0 && (
                  <ReferenceLine
                    x={parseFloat(currentTime.toFixed(2))}
                    stroke="#ffffff"
                    strokeWidth={2}
                  />
                )}

                <Line
                  type="monotone"
                  dataKey="pitch"
                  name="F0 Fundamental Pitch"
                  stroke="#00d4ff"
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 5, fill: '#00d4ff', stroke: '#ffffff' }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-gray-500 text-xs font-mono">
              No pitch contour metrics found for this recording.
            </div>
          )
        )}

        {/* TAB 2: ENERGY (RMS) */}
        {activeTab === 'energy' && (
          energyData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={energyData}
                onClick={handleChartClick}
                margin={{ top: 10, right: 20, left: 0, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="energyGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00d4ff" stopOpacity={0.5} />
                    <stop offset="95%" stopColor="#00d4ff" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#252540" />
                <XAxis
                  dataKey="time"
                  stroke="#64748b"
                  fontSize={11}
                  tickFormatter={(val) => `${val}s`}
                />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip content={<CustomTooltip />} />
                <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: '11px' }} />

                {metrics?.energy?.mean && (
                  <ReferenceLine
                    y={parseFloat(metrics.energy.mean.toFixed(4))}
                    stroke="#f59e0b"
                    strokeDasharray="4 4"
                    label={{
                      value: `Mean RMS: ${metrics.energy.mean.toFixed(3)}`,
                      fill: '#f59e0b',
                      fontSize: 10,
                      position: 'insideTopRight',
                    }}
                  />
                )}

                {currentTime > 0 && (
                  <ReferenceLine
                    x={parseFloat(currentTime.toFixed(2))}
                    stroke="#ffffff"
                    strokeWidth={2}
                  />
                )}

                <Area
                  type="monotone"
                  dataKey="energy"
                  name="RMS Vocal Energy"
                  stroke="#00d4ff"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#energyGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-gray-500 text-xs font-mono">
              No energy metrics extracted.
            </div>
          )
        )}

        {/* TAB 3: SPEAKING RATE */}
        {activeTab === 'rate' && (
          rateData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={rateData}
                margin={{ top: 10, right: 20, left: 0, bottom: 0 }}
                onClick={(e: any) => {
                  if (e && e.activePayload && e.activePayload[0] && onSeek) {
                    onSeek(e.activePayload[0].payload.start);
                  }
                }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#252540" />
                <XAxis dataKey="segment" stroke="#64748b" fontSize={11} />
                <YAxis
                  stroke="#64748b"
                  fontSize={11}
                  domain={[0, 'dataMax + 2']}
                  unit=" syl/s"
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: '11px' }} />

                {/* Optimal zone guideline */}
                <ReferenceLine
                  y={4.2}
                  stroke="#10b981"
                  strokeDasharray="4 4"
                  label={{
                    value: 'Ideal Pace (4.2 syl/s)',
                    fill: '#10b981',
                    fontSize: 10,
                    position: 'insideTopRight',
                  }}
                />

                <Bar
                  dataKey="rate"
                  name="Syllables / Sec"
                  fill="#00d4ff"
                  radius={[4, 4, 0, 0]}
                  cursor="pointer"
                />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-gray-500 text-xs font-mono">
              Speaking rate segmented data not available for this recording.
            </div>
          )
        )}

        {/* TAB 4: SPECTRAL / MFCC */}
        {activeTab === 'spectral' && (
          spectralData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={spectralData}
                onClick={handleChartClick}
                margin={{ top: 10, right: 20, left: 0, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#252540" />
                <XAxis
                  dataKey="time"
                  stroke="#64748b"
                  fontSize={11}
                  tickFormatter={(val) => `${val}s`}
                />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip content={<CustomTooltip />} />
                <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: '11px' }} />

                {(spectralData[0] as any)?.c1 !== undefined ? (
                  <>
                    <Line
                      type="monotone"
                      dataKey="c1"
                      name="MFCC Coeff 1"
                      stroke="#00d4ff"
                      strokeWidth={1.5}
                      dot={false}
                    />
                    <Line
                      type="monotone"
                      dataKey="c2"
                      name="MFCC Coeff 2"
                      stroke="#10b981"
                      strokeWidth={1.5}
                      dot={false}
                    />
                    <Line
                      type="monotone"
                      dataKey="c3"
                      name="MFCC Coeff 3"
                      stroke="#f59e0b"
                      strokeWidth={1.5}
                      dot={false}
                    />
                  </>
                ) : (
                  <>
                    <Line
                      type="monotone"
                      dataKey="centroid"
                      name="Spectral Centroid (Hz)"
                      stroke="#00d4ff"
                      strokeWidth={1.5}
                      dot={false}
                    />
                    <Line
                      type="monotone"
                      dataKey="bandwidth"
                      name="Spectral Bandwidth (Hz)"
                      stroke="#a855f7"
                      strokeWidth={1.5}
                      dot={false}
                    />
                  </>
                )}
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-gray-500 text-xs font-mono">
              Spectral and MFCC coefficients are compiling or not computed.
            </div>
          )
        )}
      </div>
    </div>
  );
}
