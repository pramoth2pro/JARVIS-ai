'use client';

import React, { useState, useMemo } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  Play,
  Volume2,
  ChevronDown,
  ChevronUp,
  Brain,
  Filter,
  CheckCircle2,
  TrendingDown,
  Gauge,
  Flame,
  MessageSquare,
  Clock,
  Sparkles,
} from 'lucide-react';
import { Finding } from '@/types';
import { formatTime, getSeverityBadge } from '@/lib/utils';

interface FindingsPanelProps {
  findings?: Finding[];
  onPlaySegment?: (start: number, end: number) => void;
  onSeek?: (start: number) => void;
}

export function FindingsPanel({
  findings = [],
  onPlaySegment,
  onSeek,
}: FindingsPanelProps) {
  const [selectedSeverity, setSelectedSeverity] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Extract unique categories for filter dropdown
  const categories = useMemo(() => {
    const set = new Set<string>();
    findings.forEach((f) => {
      if (f.category) set.add(f.category);
    });
    return Array.from(set);
  }, [findings]);

  // Sort by start_time
  const sortedFindings = useMemo(() => {
    return [...findings].sort((a, b) => a.start_time - b.start_time);
  }, [findings]);

  // Filtered findings
  const filteredFindings = useMemo(() => {
    return sortedFindings.filter((f) => {
      const matchSev =
        selectedSeverity === 'all' || f.severity === selectedSeverity;
      const matchCat =
        selectedCategory === 'all' || f.category === selectedCategory;
      return matchSev && matchCat;
    });
  }, [sortedFindings, selectedSeverity, selectedCategory]);

  const highCount = findings.filter((f) => f.severity === 'high').length;
  const medCount = findings.filter((f) => f.severity === 'medium').length;
  const lowCount = findings.filter((f) => f.severity === 'low').length;

  const toggleExpand = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  const getCategoryIcon = (cat: string) => {
    const c = cat.toLowerCase();
    if (c.includes('monotone') || c.includes('pitch')) return TrendingDown;
    if (c.includes('pace') || c.includes('rate') || c.includes('speed')) return Gauge;
    if (c.includes('fry') || c.includes('rough')) return Flame;
    if (c.includes('filler') || c.includes('hesitation')) return MessageSquare;
    return AlertTriangle;
  };

  return (
    <div className="bg-surface rounded-xl border border-surface-border shadow-lg flex flex-col h-full overflow-hidden">
      {/* Header & Stats */}
      <div className="p-4 border-b border-surface-border bg-[#16213e]/30">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-lg bg-accent/15 border border-accent/30 text-accent">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white tracking-wide flex items-center gap-2">
                Prosodic Flaw & Diagnostic Findings
                <span className="text-xs px-2 py-0.5 rounded-full bg-cyan/15 text-cyan border border-cyan/30 font-mono">
                  {findings.length} Flagged
                </span>
              </h3>
              <p className="text-xs text-gray-400">
                Rule-based thresholds & LLM diagnostic explanations
              </p>
            </div>
          </div>

          {/* Severity summary pills */}
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="px-2 py-1 rounded bg-accent/15 text-accent border border-accent/40 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-accent" />
              {highCount} Critical
            </span>
            <span className="px-2 py-1 rounded bg-amber-500/15 text-amber-400 border border-amber-500/40 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              {medCount} Moderate
            </span>
            <span className="px-2 py-1 rounded bg-cyan/15 text-cyan border border-cyan/40 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan" />
              {lowCount} Minor
            </span>
          </div>
        </div>

        {/* Filter bar */}
        <div className="mt-3.5 pt-3 border-t border-surface-border/50 flex flex-wrap items-center justify-between gap-2">
          {/* Severity Filter Buttons */}
          <div className="flex items-center space-x-1.5">
            <span className="text-xs text-gray-400 mr-1 flex items-center gap-1">
              <Filter className="w-3 h-3 text-cyan" />
              Severity:
            </span>
            {['all', 'high', 'medium', 'low'].map((sev) => (
              <button
                key={sev}
                type="button"
                onClick={() => setSelectedSeverity(sev)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium capitalize transition-colors ${
                  selectedSeverity === sev
                    ? 'bg-cyan text-graphite-900 font-bold shadow-sm'
                    : 'bg-[#0a0a1a] text-gray-400 hover:text-white border border-surface-border'
                }`}
              >
                {sev}
              </button>
            ))}
          </div>

          {/* Category Dropdown */}
          {categories.length > 0 && (
            <div className="flex items-center space-x-2">
              <span className="text-xs text-gray-400">Category:</span>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-[#0a0a1a] border border-surface-border rounded-lg px-2.5 py-1 text-xs text-gray-200 focus:outline-none focus:border-cyan cursor-pointer"
              >
                <option value="all">All Categories</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Findings List */}
      <div className="p-4 flex-1 overflow-y-auto space-y-3 max-h-[500px]">
        {filteredFindings.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center text-gray-400">
            <CheckCircle2 className="w-10 h-10 mb-2 text-cyan opacity-80 animate-pulse" />
            <p className="text-sm font-semibold text-white">No Acoustic Flaws in View</p>
            <p className="text-xs text-gray-500 mt-1">
              Speech delivery is compliant with acoustic targets or no findings match current filters.
            </p>
          </div>
        ) : (
          filteredFindings.map((finding) => {
            const Icon = getCategoryIcon(finding.category);
            const badge = getSeverityBadge(finding.severity);
            const isExpanded = expandedId === finding.id;

            return (
              <div
                key={finding.id}
                className="bg-[#16213e]/30 rounded-xl border border-surface-border hover:border-cyan/40 transition-all duration-200 overflow-hidden shadow-sm"
              >
                {/* Main Card Summary */}
                <div className="p-3.5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start space-x-3">
                      <div className="p-2 rounded-lg bg-[#0a0a1a] border border-surface-border text-cyan mt-0.5">
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="text-sm font-semibold text-white">
                            {finding.category}
                          </h4>
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-full border font-mono font-medium flex items-center gap-1.5 ${badge.bg}`}
                          >
                            <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`} />
                            {badge.label}
                          </span>
                        </div>

                        {/* Description */}
                        <p className="text-xs text-gray-300 mt-1 leading-relaxed">
                          {finding.description}
                        </p>
                      </div>
                    </div>

                    {/* Play Segment Button */}
                    <div className="flex items-center space-x-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() =>
                          onPlaySegment
                            ? onPlaySegment(finding.start_time, finding.end_time)
                            : onSeek?.(finding.start_time)
                        }
                        className="px-2.5 py-1.5 rounded-lg bg-cyan/15 hover:bg-cyan text-cyan hover:text-graphite-900 border border-cyan/40 text-xs font-mono flex items-center gap-1.5 transition-all cursor-pointer group"
                        title="Play audio region for this flaw"
                      >
                        <Play className="w-3 h-3 fill-current group-hover:scale-110" />
                        <span>
                          {formatTime(finding.start_time)} - {formatTime(finding.end_time)}
                        </span>
                      </button>
                    </div>
                  </div>

                  {/* Evidence Summary & Confidence Gauge */}
                  <div className="mt-3 pt-2.5 border-t border-surface-border/50 flex flex-wrap items-center justify-between gap-2 text-xs">
                    {finding.evidence && (
                      <div className="flex items-center gap-2 font-mono text-[11px] text-gray-400">
                        <span className="text-gray-500">Metric:</span>
                        <span className="text-cyan">{finding.evidence.metric_name}</span>
                        <span className="text-gray-600">|</span>
                        <span>Measured: <strong className="text-white">{finding.evidence.measured_value} {finding.evidence.unit}</strong></span>
                        <span className="text-gray-600">|</span>
                        <span>Threshold: <strong className="text-gray-300">{finding.evidence.threshold} {finding.evidence.unit}</strong></span>
                      </div>
                    )}

                    <div className="flex items-center gap-2 ml-auto">
                      <span className="text-[10px] text-gray-400 font-mono">Confidence:</span>
                      <div className="w-16 bg-[#0a0a1a] h-1.5 rounded-full overflow-hidden border border-surface-border">
                        <div
                          className="h-full bg-cyan rounded-full"
                          style={{
                            width: `${Math.round((finding.confidence || 0.8) * 100)}%`,
                          }}
                        />
                      </div>
                      <span className="text-[10px] font-mono font-bold text-gray-300">
                        {Math.round((finding.confidence || 0.8) * 100)}%
                      </span>
                    </div>
                  </div>

                  {/* Suggestion banner */}
                  {finding.suggestion && (
                    <div className="mt-2.5 p-2 rounded-lg bg-[#0a0a1a]/70 border border-surface-border text-xs text-gray-300 flex items-start gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-cyan shrink-0 mt-0.5" />
                      <div>
                        <span className="text-cyan font-semibold">JARVIS Action: </span>
                        <span>{finding.suggestion}</span>
                      </div>
                    </div>
                  )}

                  {/* Toggle LLM Explanation Button */}
                  {(finding.explanation || finding.recommendation) && (
                    <div className="mt-2 flex justify-end">
                      <button
                        type="button"
                        onClick={() => toggleExpand(finding.id)}
                        className="text-[11px] text-cyan hover:underline flex items-center gap-1 font-medium transition-colors"
                      >
                        <Brain className="w-3 h-3" />
                        <span>{isExpanded ? 'Hide Neural Diagnostics' : 'Deep LLM Diagnostics'}</span>
                        {isExpanded ? (
                          <ChevronUp className="w-3 h-3" />
                        ) : (
                          <ChevronDown className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  )}
                </div>

                {/* Expanded LLM Reasoning Card */}
                {isExpanded && (
                  <div className="p-3.5 bg-[#0a0a1a]/90 border-t border-surface-border text-xs space-y-2 animate-fade-in">
                    {finding.explanation && (
                      <div>
                        <span className="text-[11px] uppercase tracking-wider text-gray-400 font-mono font-semibold flex items-center gap-1.5">
                          <Brain className="w-3.5 h-3.5 text-cyan" />
                          Diagnostic Synthesis:
                        </span>
                        <p className="text-gray-300 mt-1 leading-relaxed pl-5">
                          {finding.explanation}
                        </p>
                      </div>
                    )}

                    {finding.recommendation && (
                      <div className="pt-2 border-t border-surface-border/40">
                        <span className="text-[11px] uppercase tracking-wider text-amber-400 font-mono font-semibold flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                          Targeted Drill:
                        </span>
                        <p className="text-gray-300 mt-1 leading-relaxed pl-5">
                          {finding.recommendation}
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
