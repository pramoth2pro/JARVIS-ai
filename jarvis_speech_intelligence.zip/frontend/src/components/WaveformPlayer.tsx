'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Gauge,
  ZoomIn,
  ZoomOut,
  Maximize2,
  AlertCircle,
} from 'lucide-react';
import { Finding } from '@/types';
import { formatTime } from '@/lib/utils';

interface WaveformPlayerProps {
  audioUrl?: string;
  duration?: number;
  findings?: Finding[];
  onTimeUpdate?: (time: number) => void;
  onPlayStateChange?: (isPlaying: boolean) => void;
  seekToTime?: number | null;
  onSeekComplete?: () => void;
}

export function WaveformPlayer({
  audioUrl,
  duration: initialDuration = 0,
  findings = [],
  onTimeUpdate,
  onPlayStateChange,
  seekToTime,
  onSeekComplete,
}: WaveformPlayerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const wavesurferRef = useRef<any>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [totalDuration, setTotalDuration] = useState(initialDuration);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(0);
  const [activeSegment, setActiveSegment] = useState<{ start: number; end: number } | null>(null);

  // Initialize WaveSurfer dynamically on the client
  useEffect(() => {
    let isMounted = true;

    if (!containerRef.current || !audioUrl) return;

    setIsLoading(true);

    const initWaveSurfer = async () => {
      try {
        const WaveSurferModule = await import('wavesurfer.js');
        const WaveSurfer = WaveSurferModule.default;

        if (!isMounted || !containerRef.current) return;

        // Clean up any existing instance
        if (wavesurferRef.current) {
          wavesurferRef.current.destroy();
        }

        const ws = WaveSurfer.create({
          container: containerRef.current,
          waveColor: '#16213e',
          progressColor: '#00d4ff',
          cursorColor: '#ffffff',
          cursorWidth: 2,
          barWidth: 3,
          barGap: 2,
          barRadius: 2,
          height: 90,
          normalize: true,
          fillParent: true,
          url: audioUrl,
        });

        ws.on('ready', () => {
          if (!isMounted) return;
          setIsLoading(false);
          const dur = ws.getDuration();
          if (dur > 0) setTotalDuration(dur);
        });

        ws.on('audioprocess', () => {
          if (!isMounted) return;
          const curr = ws.getCurrentTime();
          setCurrentTime(curr);
          onTimeUpdate?.(curr);

          // Check if playing a bounded segment
          if (activeSegment && curr >= activeSegment.end) {
            ws.pause();
            setActiveSegment(null);
          }
        });

        ws.on('seeking' as any, () => {
          if (!isMounted) return;
          const curr = ws.getCurrentTime();
          setCurrentTime(curr);
          onTimeUpdate?.(curr);
        });

        ws.on('play', () => {
          if (!isMounted) return;
          setIsPlaying(true);
          onPlayStateChange?.(true);
        });

        ws.on('pause', () => {
          if (!isMounted) return;
          setIsPlaying(false);
          onPlayStateChange?.(false);
        });

        ws.on('finish', () => {
          if (!isMounted) return;
          setIsPlaying(false);
          onPlayStateChange?.(false);
          setActiveSegment(null);
        });

        wavesurferRef.current = ws;
      } catch (err) {
        console.error('Failed to instantiate WaveSurfer:', err);
        setIsLoading(false);
      }
    };

    initWaveSurfer();

    return () => {
      isMounted = false;
      if (wavesurferRef.current) {
        try {
          wavesurferRef.current.destroy();
        } catch {
          // ignore destroy errors on unmount
        }
      }
    };
  }, [audioUrl]);

  // Handle external seek requests (e.g. from transcript word clicks or findings clicks)
  useEffect(() => {
    if (seekToTime !== null && seekToTime !== undefined && wavesurferRef.current) {
      const dur = wavesurferRef.current.getDuration() || totalDuration || 1;
      const progress = Math.min(1, Math.max(0, seekToTime / dur));
      wavesurferRef.current.seekTo(progress);
      setCurrentTime(seekToTime);
      onSeekComplete?.();
    }
  }, [seekToTime, totalDuration, onSeekComplete]);

  // Toggle play/pause
  const togglePlay = useCallback(() => {
    if (wavesurferRef.current) {
      wavesurferRef.current.playPause();
    }
  }, []);

  const skipSeconds = useCallback((sec: number) => {
    if (wavesurferRef.current) {
      const current = wavesurferRef.current.getCurrentTime();
      const dur = wavesurferRef.current.getDuration() || 1;
      const target = Math.min(dur, Math.max(0, current + sec));
      wavesurferRef.current.seekTo(target / dur);
    }
  }, []);

  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    if (newVol > 0 && isMuted) setIsMuted(false);
    if (wavesurferRef.current) {
      wavesurferRef.current.setVolume(isMuted ? 0 : newVol);
    }
  };

  const toggleMute = () => {
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    if (wavesurferRef.current) {
      wavesurferRef.current.setVolume(nextMute ? 0 : volume);
    }
  };

  const cyclePlaybackRate = () => {
    const rates = [1, 1.25, 1.5, 2, 0.75];
    const nextRate = rates[(rates.indexOf(playbackRate) + 1) % rates.length];
    setPlaybackRate(nextRate);
    if (wavesurferRef.current) {
      wavesurferRef.current.setPlaybackRate(nextRate);
    }
  };

  const playSegment = (start: number, end: number) => {
    if (!wavesurferRef.current) return;
    const dur = wavesurferRef.current.getDuration() || totalDuration || 1;
    wavesurferRef.current.seekTo(start / dur);
    setActiveSegment({ start, end });
    wavesurferRef.current.play();
  };

  const effectiveDuration = totalDuration || initialDuration || 1;

  return (
    <div className="bg-surface rounded-xl p-5 border border-surface-border shadow-lg relative overflow-hidden">
      {/* Top Header & Timestamps */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex items-center space-x-2">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan animate-pulse shadow-[0_0_8px_#00d4ff]" />
          <h3 className="text-sm font-semibold tracking-wide text-white uppercase">
            Acoustic Waveform Analysis
          </h3>
          {isLoading && (
            <span className="text-[11px] text-cyan font-mono animate-pulse">
              [Buffering audio stream...]
            </span>
          )}
        </div>

        {/* Time display */}
        <div className="flex items-center space-x-2 font-mono text-xs">
          <span className="px-2.5 py-1 rounded bg-[#0a0a1a] text-cyan font-bold border border-surface-border shadow-inner">
            {formatTime(currentTime)}
          </span>
          <span className="text-gray-500">/</span>
          <span className="px-2.5 py-1 rounded bg-[#0a0a1a] text-gray-400 border border-surface-border">
            {formatTime(effectiveDuration)}
          </span>
        </div>
      </div>

      {/* Waveform Viewport with Overlaid Finding Regions */}
      <div className="relative rounded-lg bg-[#0a0a1a] border border-surface-border p-3 overflow-hidden">
        {/* Finding Markers Overlay */}
        <div className="absolute inset-x-3 top-3 bottom-3 pointer-events-none z-10">
          {findings.map((f) => {
            const leftPct = Math.max(0, Math.min(100, (f.start_time / effectiveDuration) * 100));
            const widthPct = Math.max(
              1,
              Math.min(100 - leftPct, ((f.end_time - f.start_time) / effectiveDuration) * 100)
            );

            let bgClass = 'bg-cyan/20 border-cyan/60';
            if (f.severity === 'high') {
              bgClass = 'bg-accent/25 border-accent shadow-[0_0_8px_rgba(233,69,96,0.4)]';
            } else if (f.severity === 'medium') {
              bgClass = 'bg-amber-500/25 border-amber-400 shadow-[0_0_8px_rgba(245,158,11,0.3)]';
            }

            return (
              <div
                key={f.id}
                onClick={(e) => {
                  e.stopPropagation();
                  playSegment(f.start_time, f.end_time);
                }}
                title={`[${f.severity.toUpperCase()}] ${f.category}: ${f.description}\nClick to play segment`}
                style={{
                  left: `${leftPct}%`,
                  width: `${widthPct}%`,
                }}
                className={`absolute top-0 bottom-0 border-x rounded-sm cursor-pointer pointer-events-auto transition-opacity hover:opacity-100 opacity-70 group ${bgClass}`}
              >
                <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-6 left-1/2 -translate-x-1/2 bg-[#1e1e30] border border-surface-border text-[10px] text-white px-1.5 py-0.5 rounded shadow-lg whitespace-nowrap z-30 font-mono pointer-events-none">
                  {f.category} ({formatTime(f.start_time)})
                </div>
              </div>
            );
          })}
        </div>

        {/* WaveSurfer rendering container */}
        <div ref={containerRef} className="w-full relative z-0 min-h-[90px]" />
      </div>

      {/* Audio Controls Bar */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-4 pt-2">
        {/* Main Transport: Skip Back, Play/Pause, Skip Fwd */}
        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={() => skipSeconds(-5)}
            disabled={!audioUrl}
            title="Rewind 5 seconds"
            className="p-2 rounded-lg bg-[#16213e] hover:bg-[#252540] text-gray-300 hover:text-white transition-colors disabled:opacity-40"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={togglePlay}
            disabled={!audioUrl || isLoading}
            className="px-5 py-2 rounded-xl bg-cyan hover:bg-[#00e5ff] text-graphite-900 font-bold transition-all shadow-[0_0_15px_rgba(0,212,255,0.4)] hover:shadow-[0_0_20px_rgba(0,212,255,0.7)] active:scale-95 flex items-center gap-2 cursor-pointer disabled:opacity-40"
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-graphite-900" />
                <span className="text-xs uppercase tracking-wider">Pause</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-graphite-900" />
                <span className="text-xs uppercase tracking-wider">Play</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => skipSeconds(5)}
            disabled={!audioUrl}
            title="Forward 5 seconds"
            className="p-2 rounded-lg bg-[#16213e] hover:bg-[#252540] text-gray-300 hover:text-white transition-colors disabled:opacity-40"
          >
            <RotateCw className="w-4 h-4" />
          </button>
        </div>

        {/* Secondary Controls: Speed, Volume */}
        <div className="flex items-center space-x-4">
          {/* Speed Toggle */}
          <button
            type="button"
            onClick={cyclePlaybackRate}
            className="px-2.5 py-1 rounded-lg bg-[#16213e] hover:bg-[#252540] text-xs font-mono text-cyan border border-cyan/20 flex items-center gap-1.5 transition-colors"
            title="Cycle playback speed"
          >
            <Gauge className="w-3.5 h-3.5" />
            <span>{playbackRate}x</span>
          </button>

          {/* Volume Control */}
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={toggleMute}
              className="p-1.5 rounded-lg text-gray-400 hover:text-white transition-colors"
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-4 h-4 text-accent" />
              ) : (
                <Volume2 className="w-4 h-4 text-cyan" />
              )}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={isMuted ? 0 : volume}
              onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
              className="w-20 accent-cyan cursor-pointer h-1.5 bg-[#16213e] rounded-lg"
            />
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="mt-3 pt-3 border-t border-surface-border/60 flex flex-wrap items-center gap-4 text-[11px] text-gray-400">
        <span className="text-gray-500 font-mono">Severity Overlay:</span>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-sm bg-accent/80 border border-accent" />
          <span>High Flaw</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-sm bg-amber-400/80 border border-amber-400" />
          <span>Medium Flaw</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-sm bg-cyan/80 border border-cyan" />
          <span>Minor / Optimal</span>
        </div>
      </div>
    </div>
  );
}
