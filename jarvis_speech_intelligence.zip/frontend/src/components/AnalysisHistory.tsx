'use client';

import React, { useState } from 'react';
import {
  History,
  FileAudio,
  Trash2,
  Download,
  RotateCw,
  Clock,
  CheckCircle,
  AlertCircle,
  Loader2,
  ChevronRight,
} from 'lucide-react';
import { Analysis } from '@/types';
import { formatDate, formatDuration } from '@/lib/utils';
import { getExportUrl } from '@/lib/api';

interface AnalysisHistoryProps {
  analyses: Analysis[];
  activeId?: string;
  onSelectAnalysis: (id: string) => void;
  onDeleteAnalysis: (id: string) => Promise<void> | void;
  onRefresh?: () => void;
  isLoading?: boolean;
}

export function AnalysisHistory({
  analyses = [],
  activeId,
  onSelectAnalysis,
  onDeleteAnalysis,
  onRefresh,
  isLoading = false,
}: AnalysisHistoryProps) {
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleDelete = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (!window.confirm('Delete this speech analysis telemetry permanently?')) {
      return;
    }

    try {
      setDeletingId(id);
      await onDeleteAnalysis(id);
    } catch (err) {
      console.error('Failed to delete analysis:', err);
      alert('Could not delete analysis. Please retry.');
    } finally {
      setDeletingId(null);
    }
  };

  const handleExport = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const url = getExportUrl(id);
    window.open(url, '_blank');
  };

  const getStatusBadge = (status: Analysis['status']) => {
    switch (status) {
      case 'complete':
      case 'completed':
        return (
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-cyan/15 text-cyan border border-cyan/30 flex items-center gap-1 font-mono">
            <CheckCircle className="w-2.5 h-2.5" />
            Ready
          </span>
        );
      case 'error':
      case 'failed':
        return (
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-accent/15 text-accent border border-accent/30 flex items-center gap-1 font-mono">
            <AlertCircle className="w-2.5 h-2.5" />
            Error
          </span>
        );
      default:
        return (
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center gap-1 font-mono">
            <Loader2 className="w-2.5 h-2.5 animate-spin" />
            Processing
          </span>
        );
    }
  };

  return (
    <div className="bg-surface rounded-xl p-4 border border-surface-border shadow-lg flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-surface-border mb-3">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 rounded-lg bg-cyan/10 border border-cyan/30 text-cyan">
            <History className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">Archives</h3>
            <p className="text-[11px] text-gray-400">
              {analyses.length} {analyses.length === 1 ? 'recording' : 'recordings'} logged
            </p>
          </div>
        </div>

        {onRefresh && (
          <button
            type="button"
            onClick={onRefresh}
            disabled={isLoading}
            className="p-1.5 rounded-lg hover:bg-[#252540] text-gray-400 hover:text-cyan transition-colors disabled:opacity-50"
            title="Refresh history"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-cyan' : ''}`} />
          </button>
        )}
      </div>

      {/* List */}
      <div className="space-y-2 overflow-y-auto max-h-[380px] flex-1 pr-1">
        {analyses.length === 0 ? (
          <div className="py-8 text-center text-gray-400">
            <History className="w-8 h-8 mx-auto mb-2 opacity-30 text-cyan" />
            <p className="text-xs font-medium text-gray-300">No Past Sessions</p>
            <p className="text-[11px] text-gray-500 mt-0.5">
              Analyzed audio files will appear here for instant replay.
            </p>
          </div>
        ) : (
          analyses.map((item) => {
            const isActive = activeId === item.id;
            const isDeleting = deletingId === item.id;

            return (
              <div
                key={item.id}
                onClick={() => onSelectAnalysis(item.id)}
                className={`p-3 rounded-lg border transition-all cursor-pointer relative group flex items-center justify-between gap-2 ${
                  isActive
                    ? 'bg-cyan/10 border-cyan/60 shadow-[0_0_12px_rgba(0,212,255,0.15)]'
                    : 'bg-[#16213e]/20 border-surface-border/60 hover:bg-[#16213e]/50 hover:border-surface-border'
                }`}
              >
                <div className="flex items-center space-x-2.5 overflow-hidden flex-1">
                  <div
                    className={`p-2 rounded-lg shrink-0 ${
                      isActive
                        ? 'bg-cyan/20 text-cyan'
                        : 'bg-[#0a0a1a] text-gray-400 group-hover:text-cyan'
                    }`}
                  >
                    <FileAudio className="w-4 h-4" />
                  </div>

                  <div className="truncate flex-1">
                    <div className="flex items-center gap-1.5">
                      <p
                        className={`text-xs font-semibold truncate ${
                          isActive ? 'text-cyan' : 'text-gray-200 group-hover:text-white'
                        }`}
                      >
                        {item.filename || 'voice_sample.wav'}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 mt-1 text-[10px] text-gray-400 font-mono">
                      <span>{formatDate(item.created_at)}</span>
                      {item.duration_seconds && (
                        <>
                          <span>•</span>
                          <span className="flex items-center gap-0.5">
                            <Clock className="w-2.5 h-2.5 text-gray-500" />
                            {formatDuration(item.duration_seconds)}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-1.5 shrink-0">
                  {getStatusBadge(item.status)}

                  {/* Export JSON */}
                  <button
                    type="button"
                    onClick={(e) => handleExport(e, item.id)}
                    title="Export JSON payload"
                    className="p-1.5 rounded hover:bg-cyan/20 text-gray-400 hover:text-cyan opacity-80 group-hover:opacity-100 transition-all"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>

                  {/* Delete */}
                  <button
                    type="button"
                    onClick={(e) => handleDelete(e, item.id)}
                    disabled={isDeleting}
                    title="Delete recording"
                    className="p-1.5 rounded hover:bg-accent/20 text-gray-400 hover:text-accent opacity-80 group-hover:opacity-100 transition-all"
                  >
                    {isDeleting ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-accent" />
                    ) : (
                      <Trash2 className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
