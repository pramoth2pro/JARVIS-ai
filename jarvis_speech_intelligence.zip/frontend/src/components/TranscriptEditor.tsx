'use client';

import React, { useState, useMemo } from 'react';
import {
  FileText,
  Edit3,
  Check,
  X,
  Volume2,
  Clock,
  Search,
  Sparkles,
  AlertTriangle,
  Loader2,
} from 'lucide-react';
import { TranscriptResult, Finding, TranscriptWord } from '@/types';
import { updateTranscript } from '@/lib/api';
import { formatTime } from '@/lib/utils';

interface TranscriptEditorProps {
  analysisId: string;
  transcript?: TranscriptResult;
  findings?: Finding[];
  currentTime?: number;
  onSeek?: (seconds: number) => void;
  onTranscriptUpdated?: (newText: string) => void;
}

export function TranscriptEditor({
  analysisId,
  transcript,
  findings = [],
  currentTime = 0,
  onSeek,
  onTranscriptUpdated,
}: TranscriptEditorProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(transcript?.text || '');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [hoveredWord, setHoveredWord] = useState<TranscriptWord | null>(null);

  // Sync editText when transcript prop changes
  React.useEffect(() => {
    if (transcript?.text) {
      setEditText(transcript.text);
    }
  }, [transcript?.text]);

  // Pre-index findings by time intervals for fast lookup
  const isWordInFinding = (start: number, end: number): Finding | undefined => {
    return findings.find((f) => {
      // Overlap condition
      return Math.max(start, f.start_time) < Math.min(end, f.end_time);
    });
  };

  const handleSave = async () => {
    try {
      setIsSaving(true);
      await updateTranscript(analysisId, editText);
      setIsSaving(false);
      setIsEditing(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
      if (onTranscriptUpdated) {
        onTranscriptUpdated(editText);
      }
    } catch (err) {
      console.error('Failed to update transcript:', err);
      setIsSaving(false);
      alert('Could not save transcript update. Check backend connection.');
    }
  };

  const hasWords = transcript?.words && transcript.words.length > 0;
  const hasSegments = transcript?.segments && transcript.segments.length > 0;

  return (
    <div className="bg-surface rounded-xl border border-surface-border shadow-lg overflow-hidden flex flex-col h-full">
      {/* Header bar */}
      <div className="p-4 border-b border-surface-border flex flex-wrap items-center justify-between gap-3 bg-[#16213e]/30">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-lg bg-cyan/10 border border-cyan/30 text-cyan">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white tracking-wide flex items-center gap-2">
              Neural Speech Transcript
              {transcript?.language && (
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-[#252540] text-gray-300 border border-surface-border">
                  {transcript.language}
                </span>
              )}
            </h3>
            <p className="text-xs text-gray-400">
              Interactive word alignment & phonetic tagging
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Search bar */}
          {!isEditing && (
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
              <input
                type="text"
                placeholder="Search words..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-[#0a0a1a] border border-surface-border rounded-lg pl-8 pr-3 py-1 text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan/60 w-32 sm:w-44 transition-all"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          )}

          {/* Toggle Edit / View */}
          {isEditing ? (
            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={() => {
                  setEditText(transcript?.text || '');
                  setIsEditing(false);
                }}
                disabled={isSaving}
                className="px-2.5 py-1.5 rounded-lg border border-surface-border text-xs text-gray-300 hover:bg-[#252540] transition-colors flex items-center gap-1"
              >
                <X className="w-3.5 h-3.5" />
                Cancel
              </button>

              <button
                type="button"
                onClick={handleSave}
                disabled={isSaving}
                className="px-3 py-1.5 rounded-lg bg-cyan text-graphite-900 font-medium text-xs hover:bg-[#00e5ff] shadow-[0_0_12px_rgba(0,212,255,0.4)] transition-all flex items-center gap-1.5"
              >
                {isSaving ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Check className="w-3.5 h-3.5" />
                )}
                Save Changes
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => {
                setEditText(transcript?.text || '');
                setIsEditing(true);
              }}
              className="px-3 py-1.5 rounded-lg bg-[#252540] border border-surface-border hover:border-cyan/40 text-xs text-gray-200 hover:text-white transition-all flex items-center gap-1.5 shadow-sm"
            >
              <Edit3 className="w-3.5 h-3.5 text-cyan" />
              Edit Text
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="p-4 flex-1 overflow-y-auto max-h-[460px] min-h-[220px]">
        {saveSuccess && (
          <div className="mb-3 p-2.5 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0" />
            Transcript updated successfully on JARVIS server.
          </div>
        )}

        {isEditing ? (
          <div className="h-full flex flex-col">
            <label className="text-xs text-gray-400 mb-1.5 flex items-center justify-between">
              <span>Raw Transcript String</span>
              <span className="font-mono text-[11px]">{editText.length} characters</span>
            </label>
            <textarea
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              rows={12}
              className="w-full h-full min-h-[260px] bg-[#0a0a1a] border border-surface-border rounded-lg p-3 text-sm text-gray-100 font-sans leading-relaxed focus:outline-none focus:border-cyan shadow-inner resize-y"
              placeholder="Enter spoken transcript..."
            />
          </div>
        ) : !transcript?.text ? (
          <div className="flex flex-col items-center justify-center py-12 text-center text-gray-400">
            <FileText className="w-10 h-10 mb-2 opacity-30 text-cyan" />
            <p className="text-sm font-medium text-gray-300">
              No transcript available yet
            </p>
            <p className="text-xs text-gray-500 max-w-sm mt-1">
              Upload an audio stream or select a previous analysis to view word-level acoustic transcription.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* If we have segmented speech, render with speaker blocks and timestamps */}
            {hasSegments ? (
              <div className="space-y-3">
                {transcript.segments.map((seg, sIdx) => {
                  // Filter words belonging to this segment if available
                  const segWords = transcript.words?.filter(
                    (w) => w.start >= seg.start - 0.05 && w.end <= seg.end + 0.05
                  );

                  return (
                    <div
                      key={sIdx}
                      className="p-3 rounded-lg bg-[#16213e]/20 border border-surface-border/60 hover:border-surface-border transition-colors group"
                    >
                      <div className="flex items-center justify-between mb-1.5 text-xs text-gray-400">
                        <button
                          type="button"
                          onClick={() => onSeek && onSeek(seg.start)}
                          className="flex items-center gap-1.5 text-cyan hover:underline font-mono text-[11px]"
                          title="Seek audio to segment start"
                        >
                          <Volume2 className="w-3 h-3 text-cyan" />
                          <span>
                            [{formatTime(seg.start)} - {formatTime(seg.end)}]
                          </span>
                        </button>
                        <span className="text-[10px] text-gray-500 font-mono">
                          Segment #{sIdx + 1}
                        </span>
                      </div>

                      {segWords && segWords.length > 0 ? (
                        <div className="flex flex-wrap gap-x-1.5 gap-y-2 leading-relaxed text-sm">
                          {segWords.map((w, wIdx) => {
                            const isCurrent =
                              currentTime >= w.start && currentTime <= w.end;
                            const finding = isWordInFinding(w.start, w.end);
                            const matchesSearch =
                              searchQuery &&
                              w.word.toLowerCase().includes(searchQuery.toLowerCase());

                            let wordStyle =
                              'text-gray-200 hover:text-white hover:bg-white/10';

                            if (finding) {
                              if (finding.severity === 'high') {
                                wordStyle =
                                  'text-accent font-medium bg-accent/15 border-b-2 border-accent hover:bg-accent/25';
                              } else if (finding.severity === 'medium') {
                                wordStyle =
                                  'text-amber-400 font-medium bg-amber-400/15 border-b-2 border-amber-400 hover:bg-amber-400/25';
                              } else {
                                wordStyle =
                                  'text-cyan font-medium bg-cyan/15 border-b border-cyan hover:bg-cyan/25';
                              }
                            }

                            if (isCurrent) {
                              wordStyle +=
                                ' ring-2 ring-cyan bg-cyan/30 text-white rounded font-bold shadow-[0_0_10px_rgba(0,212,255,0.7)]';
                            }

                            if (matchesSearch) {
                              wordStyle += ' bg-yellow-400/30 text-yellow-200 font-bold';
                            }

                            return (
                              <button
                                key={wIdx}
                                type="button"
                                onClick={() => onSeek && onSeek(w.start)}
                                onMouseEnter={() => setHoveredWord(w)}
                                onMouseLeave={() => setHoveredWord(null)}
                                title={`Timestamp: ${formatTime(w.start)} - ${formatTime(w.end)}${
                                  finding ? `\nDiagnostic: ${finding.category} (${finding.severity})` : ''
                                }`}
                                className={`px-1 py-0.5 rounded cursor-pointer transition-all duration-150 inline-flex items-center gap-0.5 ${wordStyle}`}
                              >
                                {w.word}
                                {finding && (
                                  <span className="w-1.5 h-1.5 rounded-full bg-current inline-block ml-0.5" />
                                )}
                              </button>
                            );
                          })}
                        </div>
                      ) : (
                        <p
                          onClick={() => onSeek && onSeek(seg.start)}
                          className="text-sm text-gray-200 hover:text-white cursor-pointer"
                        >
                          {seg.text}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : hasWords ? (
              /* Flat word array if no segment grouping */
              <div className="flex flex-wrap gap-x-1.5 gap-y-2 leading-relaxed text-sm p-2">
                {transcript.words.map((w, idx) => {
                  const isCurrent =
                    currentTime >= w.start && currentTime <= w.end;
                  const finding = isWordInFinding(w.start, w.end);
                  const matchesSearch =
                    searchQuery &&
                    w.word.toLowerCase().includes(searchQuery.toLowerCase());

                  let wordStyle =
                    'text-gray-200 hover:text-white hover:bg-white/10';

                  if (finding) {
                    if (finding.severity === 'high') {
                      wordStyle =
                        'text-accent font-medium bg-accent/15 border-b-2 border-accent';
                    } else if (finding.severity === 'medium') {
                      wordStyle =
                        'text-amber-400 font-medium bg-amber-400/15 border-b-2 border-amber-400';
                    } else {
                      wordStyle =
                        'text-cyan font-medium bg-cyan/15 border-b border-cyan';
                    }
                  }

                  if (isCurrent) {
                    wordStyle +=
                      ' ring-2 ring-cyan bg-cyan/30 text-white rounded font-bold shadow-[0_0_10px_rgba(0,212,255,0.7)]';
                  }

                  if (matchesSearch) {
                    wordStyle += ' bg-yellow-400/30 text-yellow-200 font-bold';
                  }

                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => onSeek && onSeek(w.start)}
                      title={`Timestamp: ${formatTime(w.start)} - ${formatTime(w.end)}${
                        finding ? `\nDiagnostic: ${finding.category} (${finding.severity})` : ''
                      }`}
                      className={`px-1 py-0.5 rounded cursor-pointer transition-all duration-150 ${wordStyle}`}
                    >
                      {w.word}
                    </button>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-gray-200 leading-relaxed whitespace-pre-wrap">
                {transcript.text}
              </p>
            )}
          </div>
        )}
      </div>

      {/* Footer info pill */}
      {hoveredWord && (
        <div className="px-4 py-2 bg-[#0a0a1a] border-t border-surface-border text-xs flex items-center justify-between text-gray-400 font-mono animate-fade-in">
          <div className="flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-cyan" />
            <span>
              Target: &quot;<strong className="text-white">{hoveredWord.word}</strong>&quot; ({formatTime(hoveredWord.start)} - {formatTime(hoveredWord.end)})
            </span>
          </div>
          <span>Confidence: {Math.round((hoveredWord.probability || 1) * 100)}%</span>
        </div>
      )}
    </div>
  );
}
