import React, { useState, useRef, DragEvent, ChangeEvent } from 'react';
import { Upload, FileAudio, CheckCircle2, AlertCircle, Sparkles, X, Link, Globe } from 'lucide-react';
import { uploadAudio, analyzeUrl } from '@/lib/api';

interface UploadPanelProps {
  onUploadSuccess: (analysisId: string, filename: string) => void;
  isUploadingGlobal?: boolean;
}

export function UploadPanel({ onUploadSuccess, isUploadingGlobal = false }: UploadPanelProps) {
  const [activeTab, setActiveTab] = useState<'file' | 'url'>('file');
  const [urlInput, setUrlInput] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [isUploading, setIsUploading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const acceptedExtensions = ['.wav', '.mp3', '.m4a', '.mp4'];
  const acceptedMimeTypes = [
    'audio/wav',
    'audio/x-wav',
    'audio/wave',
    'audio/mpeg',
    'audio/mp3',
    'audio/mp4',
    'audio/x-m4a',
    'video/mp4',
  ];

  const validateFile = (file: File): boolean => {
    const fileName = file.name.toLowerCase();
    const hasValidExt = acceptedExtensions.some((ext) => fileName.endsWith(ext));
    const hasValidMime =
      acceptedMimeTypes.includes(file.type) ||
      file.type.startsWith('audio/') ||
      file.type === 'video/mp4';

    if (!hasValidExt && !hasValidMime) {
      setErrorMessage('Unsupported format. Please upload .wav, .mp3, .m4a, or .mp4');
      return false;
    }

    // 100 MB max limit
    if (file.size > 100 * 1024 * 1024) {
      setErrorMessage('File exceeds 100MB limit. Please provide a shorter recording.');
      return false;
    }

    setErrorMessage(null);
    return true;
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (validateFile(file)) {
        setSelectedFile(file);
      }
    }
  };

  const handleFileSelect = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      if (validateFile(file)) {
        setSelectedFile(file);
      }
    }
  };

  const clearSelection = () => {
    setSelectedFile(null);
    setUploadProgress(0);
    setErrorMessage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    try {
      setIsUploading(true);
      setErrorMessage(null);
      setUploadProgress(10);

      const result = await uploadAudio(selectedFile, (progress) => {
        setUploadProgress(Math.min(95, progress));
      });

      setUploadProgress(100);
      onUploadSuccess(result.analysis_id, selectedFile.name);
      clearSelection();
    } catch (err: any) {
      console.error('Upload failed:', err);
      setErrorMessage(err.message || 'Failed to upload audio to backend.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleUrlSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;

    try {
      setIsUploading(true);
      setErrorMessage(null);
      setUploadProgress(20);

      const result = await analyzeUrl(urlInput.trim());
      setUploadProgress(100);
      onUploadSuccess(result.analysis_id, urlInput.trim());
      setUrlInput('');
    } catch (err: any) {
      console.error('URL ingestion failed:', err);
      setErrorMessage(err.message || 'Failed to analyze media URL.');
    } finally {
      setIsUploading(false);
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="bg-surface rounded-xl p-5 border border-surface-border shadow-lg relative overflow-hidden transition-all duration-300">
      {/* Subtle corner tech accent */}
      <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-cyan/20 to-transparent pointer-events-none rounded-tr-xl" />

      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <div className="p-2 rounded-lg bg-cyan/10 border border-cyan/30 text-cyan">
            <Upload className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-white tracking-wide flex items-center gap-1.5">
              Input Voice Feed
              <Sparkles className="w-3.5 h-3.5 text-cyan animate-pulse" />
            </h2>
            <p className="text-xs text-gray-400">Stream audio to JARVIS Core</p>
          </div>
        </div>
      </div>

      {/* Tab Selector: File Upload vs YouTube / URL */}
      <div className="flex items-center p-1 mb-4 rounded-lg bg-[#0a0a1a] border border-surface-border">
        <button
          type="button"
          onClick={() => setActiveTab('file')}
          className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'file'
              ? 'bg-cyan text-graphite-900 font-bold shadow-sm'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <FileAudio className="w-3.5 h-3.5" />
          <span>File Upload</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('url')}
          className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'url'
              ? 'bg-cyan text-graphite-900 font-bold shadow-sm'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>YouTube / URL</span>
        </button>
      </div>

      {activeTab === 'url' ? (
        <form onSubmit={handleUrlSubmit} className="space-y-3">
          <div className="relative">
            <input
              type="url"
              placeholder="https://www.youtube.com/watch?v=..."
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              disabled={isUploading || isUploadingGlobal}
              className="w-full bg-[#0a0a1a] border border-surface-border focus:border-cyan rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none font-mono"
            />
          </div>
          <div className="p-2.5 rounded-lg bg-[#0a0a1a] border border-surface-border text-[11px] text-gray-400 space-y-1">
            <p className="text-gray-300 font-medium flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-cyan" />
              <span>Supports YouTube, Podcast & Direct Media URLs</span>
            </p>
            <p className="text-[10px] text-gray-400 leading-relaxed">
              Note: YouTube anti-bot protections occasionally restrict automated cloud downloads with HTTP 403. If this occurs, download the recording and switch to the <strong className="text-cyan cursor-pointer" onClick={() => setActiveTab('file')}>File Upload</strong> tab as the reliable fallback.
            </p>
          </div>
          <button
            type="submit"
            disabled={!urlInput.trim() || isUploading || isUploadingGlobal}
            className="w-full py-2.5 px-4 rounded-xl font-semibold text-xs tracking-wide text-graphite-900 bg-cyan hover:bg-[#00e5ff] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
          >
            <Link className="w-4 h-4" />
            <span>{isUploading ? 'Ingesting Stream...' : 'Analyze URL Stream'}</span>
          </button>
        </form>
      ) : (
        <>

      <input
        ref={fileInputRef}
        type="file"
        accept=".wav,.mp3,.m4a,.mp4,audio/*,video/mp4"
        className="hidden"
        onChange={handleFileSelect}
      />

      {/* Drag & Drop Zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => !selectedFile && !isUploading && fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-lg p-5 text-center cursor-pointer transition-all duration-200 ${
          isDragging
            ? 'border-cyan bg-cyan/10 shadow-[0_0_20px_rgba(0,212,255,0.25)] scale-[1.01]'
            : selectedFile
            ? 'border-cyan/50 bg-[#16213e]/40'
            : 'border-surface-border hover:border-cyan/40 hover:bg-[#16213e]/20'
        }`}
      >
        {!selectedFile ? (
          <div className="flex flex-col items-center justify-center py-4 space-y-2">
            <div className="w-12 h-12 rounded-full bg-cyan/10 border border-cyan/20 flex items-center justify-center text-cyan mb-1 group-hover:scale-110 transition-transform">
              <FileAudio className="w-6 h-6 animate-pulse-slow" />
            </div>
            <p className="text-sm font-medium text-gray-200">
              Drag & drop audio here, or{' '}
              <span className="text-cyan underline underline-offset-4 font-semibold">browse</span>
            </p>
            <p className="text-xs text-gray-400 font-mono">
              WAV, MP3, M4A, MP4 (Up to 100MB)
            </p>
          </div>
        ) : (
          <div className="flex items-center justify-between p-2">
            <div className="flex items-center space-x-3 text-left overflow-hidden">
              <div className="p-2.5 rounded-lg bg-cyan/20 border border-cyan/40 text-cyan">
                <FileAudio className="w-6 h-6" />
              </div>
              <div className="truncate">
                <p className="text-sm font-medium text-white truncate max-w-[200px]">
                  {selectedFile.name}
                </p>
                <p className="text-xs text-gray-400 font-mono">
                  {formatFileSize(selectedFile.size)} • {selectedFile.name.split('.').pop()?.toUpperCase()}
                </p>
              </div>
            </div>

            {!isUploading && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  clearSelection();
                }}
                className="p-1.5 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
                title="Remove file"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        )}
      </div>

      {/* Upload Progress Bar */}
      {isUploading && (
        <div className="mt-4 space-y-2">
          <div className="flex justify-between text-xs text-gray-300 font-mono">
            <span className="flex items-center gap-1.5 text-cyan">
              <span className="w-2 h-2 rounded-full bg-cyan animate-ping" />
              Streaming telemetry...
            </span>
            <span>{uploadProgress}%</span>
          </div>
          <div className="h-2 w-full bg-[#16213e] rounded-full overflow-hidden border border-cyan/30">
            <div
              className="h-full bg-gradient-to-r from-cyan-600 via-cyan to-[#00b4d8] rounded-full transition-all duration-300 shadow-[0_0_12px_rgba(0,212,255,0.8)]"
              style={{ width: `${uploadProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* Error Banner */}
      {errorMessage && (
        <div className="mt-3 p-3 rounded-lg bg-accent/15 border border-accent/40 text-accent text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Big Cyan Upload Button */}
      {selectedFile && !isUploading && (
        <button
          type="button"
          onClick={handleUpload}
          disabled={isUploading || isUploadingGlobal}
          className="mt-4 w-full py-3 px-4 rounded-xl font-semibold text-sm tracking-wide text-graphite-900 bg-cyan hover:bg-[#00e5ff] active:scale-[0.99] transition-all duration-200 flex items-center justify-center space-x-2 shadow-[0_0_20px_rgba(0,212,255,0.4)] hover:shadow-[0_0_25px_rgba(0,212,255,0.6)] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Upload className="w-4 h-4" />
          <span>Initiate JARVIS Analysis</span>
        </button>
      )}
        </>
      )}
    </div>
  );
}
