import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'J.A.R.V.I.S. Speech Intelligence | AI Vocal Diagnostics',
  description:
    'Advanced real-time speech acoustic analysis, transcript editing, flaw detection, and prosodic intelligence dashboard.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body
        className={`${inter.variable} font-sans bg-[#0a0a1a] text-slate-200 antialiased min-h-screen selection:bg-cyan-500/30 selection:text-white`}
      >
        {children}
      </body>
    </html>
  );
}
