'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  BrainCircuit,
  Radio,
  RefreshCw,
  Download,
  AlertTriangle,
  Sparkles,
  Layers,
  ChevronRight,
  ShieldCheck,
  Cpu,
  BarChart3,
  FileCode2,
} from 'lucide-react';
import { Analysis, SSEEvent } from '@/types';
import {
  getAnalysis,
  getAnalyses,
  deleteAnalysis,
  reanalyze,
  getAudioUrl,
  getExportUrl,
  getExportPdfUrl,
  subscribeToStatus,
} from '@/lib/api';
import { UploadPanel } from '@/components/UploadPanel';
import { ProcessingStatus } from '@/components/ProcessingStatus';
import { WaveformPlayer } from '@/components/WaveformPlayer';
import { TranscriptEditor } from '@/components/TranscriptEditor';
import { MetricCards } from '@/components/MetricCards';
import { AcousticCharts } from '@/components/AcousticCharts';
import { FindingsPanel } from '@/components/FindingsPanel';
import { AnalysisHistory } from '@/components/AnalysisHistory';

export default function DashboardPage() {
  // State for Analyses
  const [analyses, setAnalyses] = useState<Analysis[]>([]);
  const [currentAnalysis, setCurrentAnalysis] = useState<Analysis | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  // Loading and Error States
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [isLoadingDetail, setIsLoadingDetail] = useState(false);
  const [generalError, setGeneralError] = useState<string | null>(null);

  // Audio Playback & Synchronization State
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [seekTarget, setSeekTarget] = useState<number | null>(null);

  // SSE State
  const [sseMessage, setSseMessage] = useState<string>('');
  const [sseProgress, setSseProgress] = useState<number>(0);
  const sseRef = useRef<EventSource | null>(null);

  // Load initial analysis list on mount
  const fetchHistory = useCallback(async () => {
    try {
      setIsLoadingHistory(true);
      const list = await getAnalyses();
      setAnalyses(list);

      // Auto-select latest or first if none currently selected
      if (!selectedId && list.length > 0) {
        setSelectedId(list[0].id);
      }
    } catch (err: any) {
      console.warn('Could not load analysis list:', err.message);
      // Non-blocking error if backend not yet running
    } finally {
      setIsLoadingHistory(false);
    }
  }, [selectedId]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  // Load single analysis whenever selectedId changes
  useEffect(() => {
    if (!selectedId) {
      setCurrentAnalysis(null);
      return;
    }

    let isMounted = true;

    const loadDetail = async () => {
      try {
        setIsLoadingDetail(true);
        setGeneralError(null);
        const data = await getAnalysis(selectedId);
        if (isMounted) {
          setCurrentAnalysis(data);

          // If currently processing, subscribe to SSE stream
          const isDone = data.status === 'complete' || data.status === 'completed';
          const isFailed = data.status === 'error' || data.status === 'failed';
          if (!isDone && !isFailed) {
            startSSE(selectedId);
          }
        }
      } catch (err: any) {
        if (isMounted) {
          console.error('Failed to load analysis:', err);
          setGeneralError(err.message || 'Failed to fetch analysis details.');
        }
      } finally {
        if (isMounted) setIsLoadingDetail(false);
      }
    };

    loadDetail();

    return () => {
      isMounted = false;
      // Close SSE if active
      if (sseRef.current) {
        sseRef.current.close();
        sseRef.current = null;
      }
    };
  }, [selectedId]);

  // SSE Management
  const startSSE = (analysisId: string) => {
    if (sseRef.current) {
      sseRef.current.close();
    }

    const eventSource = subscribeToStatus(
      analysisId,
      (event: SSEEvent) => {
        setSseMessage(event.message || '');
        if (typeof event.progress === 'number') {
          setSseProgress(event.progress);
        }

        setCurrentAnalysis((prev) => {
          if (!prev || prev.id !== analysisId) return prev;
          return {
            ...prev,
            status: (event.stage as Analysis['status']) || prev.status,
            transcript: event.data?.transcript || prev.transcript,
            findings: event.data?.findings || prev.findings,
            metrics: event.data?.metrics || prev.metrics,
          };
        });

        // If completed or errored, reload full data and close SSE
        const isDoneEvent = event.stage === 'complete' || event.stage === 'completed';
        const isErrorEvent = event.stage === 'error' || event.stage === 'failed';
        if (isDoneEvent || isErrorEvent) {
          setTimeout(async () => {
            try {
              const fullData = await getAnalysis(analysisId);
              setCurrentAnalysis(fullData);
              fetchHistory();
            } catch (err) {
              console.warn('Post-SSE fetch failed:', err);
            }
          }, 500);
          eventSource.close();
        }
      },
      (err) => {
        console.warn('SSE stream disconnected or failed to connect:', err);
      }
    );

    sseRef.current = eventSource;
  };

  // Upload handler
  const handleUploadSuccess = (analysisId: string, filename: string) => {
    setSelectedId(analysisId);
    fetchHistory();
    startSSE(analysisId);
  };

  // Delete handler
  const handleDeleteAnalysis = async (id: string) => {
    await deleteAnalysis(id);
    if (selectedId === id) {
      setSelectedId(null);
      setCurrentAnalysis(null);
    }
    fetchHistory();
  };

  // Reanalyze handler
  const handleReanalyze = async () => {
    if (!currentAnalysis) return;
    try {
      await reanalyze(currentAnalysis.id);
      startSSE(currentAnalysis.id);
      setCurrentAnalysis((prev) =>
        prev ? { ...prev, status: 'preprocessing' } : prev
      );
    } catch (err: any) {
      alert(`Reanalysis failed: ${err.message}`);
    }
  };

  // Seeking handlers
  const handleSeek = (time: number) => {
    setSeekTarget(time);
  };

  const handlePlaySegment = (start: number, end: number) => {
    setSeekTarget(start);
  };

  const isProcessing = Boolean(
    currentAnalysis &&
    currentAnalysis.status !== 'complete' &&
    currentAnalysis.status !== 'error'
  );

  return (
    <div className="min-h-screen bg-[#0a0a1a] text-slate-200 flex flex-col font-sans selection:bg-cyan/30">
      {/* JARVIS Top Header */}
      <header className="sticky top-0 z-50 border-b border-surface-border bg-[#0a0a1a]/95 backdrop-blur-md px-4 lg:px-8 py-3.5 shadow-md">
        <div className="max-w-[1700px] mx-auto flex items-center justify-between">
          {/* Logo & HUD Branding */}
          <div className="flex items-center space-x-3.5">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 to-graphite-600 border border-cyan/40 flex items-center justify-center text-cyan shadow-[0_0_15px_rgba(0,212,255,0.3)]">
                <BrainCircuit className="w-6 h-6 animate-pulse-slow" />
              </div>
              <span className="absolute -bottom-1 -right-1 w-3 h-3 bg-cyan rounded-full border-2 border-[#0a0a1a] shadow-[0_0_6px_#00d4ff]" />
            </div>

            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg font-bold tracking-wider text-white flex items-center gap-1.5">
                  J.A.R.V.I.S.
                  <span className="text-[11px] font-mono font-normal px-2 py-0.5 rounded bg-cyan/15 text-cyan border border-cyan/30">
                    SPEECH HUD v2.4
                  </span>
                </h1>
              </div>
              <p className="text-xs text-gray-400 font-mono tracking-tight flex items-center gap-1">
                <span>AI Acoustic & Prosodic Intelligence Platform</span>
              </p>
            </div>
          </div>

          {/* Quick HUD Metrics & Actions */}
          <div className="flex items-center space-x-3">
            {currentAnalysis && (
              <>
                <button
                  type="button"
                  onClick={handleReanalyze}
                  disabled={isProcessing}
                  className="hidden sm:flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-[#1e1e30] border border-surface-border hover:border-cyan/50 text-xs text-gray-300 hover:text-white transition-all disabled:opacity-40"
                  title="Run neural diagnostics again"
                >
                  <RefreshCw
                    className={`w-3.5 h-3.5 text-cyan ${
                      isProcessing ? 'animate-spin' : ''
                    }`}
                  />
                  <span>Reanalyze</span>
                </button>

                <a
                  href={getExportUrl(currentAnalysis.id)}
                  target="_blank"
                  rel="noreferrer"
                  className="hidden sm:flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-[#1e1e30] border border-surface-border hover:border-cyan/50 text-xs text-gray-300 hover:text-white transition-all"
                >
                  <Download className="w-3.5 h-3.5 text-cyan" />
                  <span>JSON</span>
                </a>

                <a
                  href={getExportPdfUrl(currentAnalysis.id)}
                  target="_blank"
                  rel="noreferrer"
                  className="hidden sm:flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-cyan/15 border border-cyan/40 hover:bg-cyan hover:text-graphite-900 text-xs text-cyan transition-all font-medium"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>PDF Report</span>
                </a>
              </>
            )}

            {/* System Online Badge */}
            <div className="px-3 py-1.5 rounded-lg bg-[#16213e]/60 border border-surface-border flex items-center space-x-2 text-xs font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-gray-300">CORE ONLINE</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Workspace Layout */}
      <main className="flex-1 max-w-[1700px] w-full mx-auto p-4 lg:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Sidebar (Upload & History) - 3.5 Columns */}
        <aside className="lg:col-span-4 xl:col-span-3 space-y-5 flex flex-col">
          {/* Upload Audio Feed */}
          <UploadPanel
            onUploadSuccess={handleUploadSuccess}
            isUploadingGlobal={isProcessing}
          />

          {/* Analysis History Log */}
          <div className="flex-1 min-h-[380px]">
            <AnalysisHistory
              analyses={analyses}
              activeId={selectedId || undefined}
              onSelectAnalysis={(id) => setSelectedId(id)}
              onDeleteAnalysis={handleDeleteAnalysis}
              onRefresh={fetchHistory}
              isLoading={isLoadingHistory}
            />
          </div>
        </aside>

        {/* Right Main Intelligence Dashboard - 8.5 Columns */}
        <section className="lg:col-span-8 xl:col-span-9 space-y-6 flex flex-col">
          {generalError && (
            <div className="p-4 rounded-xl bg-accent/15 border border-accent/40 text-accent text-sm flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                <span>{generalError}</span>
              </div>
              <button
                type="button"
                onClick={() => setGeneralError(null)}
                className="underline text-xs"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* When loading details */}
          {isLoadingDetail ? (
            <div className="bg-surface/90 backdrop-blur-md rounded-2xl border border-cyan/30 p-12 text-center flex flex-col items-center justify-center my-auto min-h-[500px] shadow-[0_0_50px_rgba(0,212,255,0.1)]">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-cyan/20 to-[#0f3460] border border-cyan/50 flex items-center justify-center text-cyan mb-5 shadow-[0_0_30px_rgba(0,212,255,0.35)]">
                <Cpu className="w-10 h-10 animate-spin" />
              </div>
              <div className="flex items-center space-x-2 font-mono text-cyan text-xs tracking-wider mb-2">
                <span className="w-2 h-2 rounded-full bg-cyan animate-ping" />
                <span>SYNAPSE ACTIVE // LOADING TELEMETRY</span>
              </div>
              <h2 className="text-xl font-bold text-white tracking-wide font-mono">
                HYDRATING ACOUSTIC SPECTROGRAMS
              </h2>
              <p className="text-sm text-gray-400 max-w-md mt-2 leading-relaxed">
                Synchronizing pYIN pitch tracks, Whisper ASR token alignments, and acoustic flaw matrices...
              </p>
            </div>
          ) : !currentAnalysis ? (
            <div className="bg-surface/90 backdrop-blur-md rounded-2xl border border-surface-border p-8 lg:p-12 text-center flex flex-col items-center justify-center my-auto min-h-[500px] shadow-[0_4px_30px_rgba(0,0,0,0.5)]">
              <div className="w-20 h-20 rounded-2xl bg-cyan/10 border border-cyan/30 flex items-center justify-center text-cyan mb-5 shadow-[0_0_30px_rgba(0,212,255,0.2)]">
                <Cpu className="w-10 h-10 animate-pulse-slow" />
              </div>
              <div className="flex items-center space-x-2 font-mono text-cyan text-xs tracking-wider mb-2">
                <span className="w-2 h-2 rounded-full bg-cyan" />
                <span>JARVIS NEURAL CORE • READY</span>
              </div>
              <h2 className="text-2xl font-bold text-white tracking-wide font-mono">
                JARVIS Voice Diagnostic Console
              </h2>
              <p className="text-sm text-gray-400 max-w-lg mt-3 leading-relaxed">
                Professional acoustic telemetry & speech intelligence suite. Upload an audio/video recording, paste a speech URL, or load a historical session to inspect micro-cadence, pitch stability, and speech delivery flaws.
              </p>

              {analyses.length > 0 && (
                <div className="mt-6 flex flex-col items-center">
                  <button
                    type="button"
                    onClick={() => setSelectedId(analyses[0].id)}
                    className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan to-[#0096c7] text-[#0a0a1a] font-bold text-sm tracking-wide shadow-[0_0_25px_rgba(0,212,255,0.4)] hover:shadow-[0_0_35px_rgba(0,212,255,0.6)] transition-all flex items-center gap-2 group cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4 text-[#0a0a1a] group-hover:rotate-12 transition-transform" />
                    <span>Load Latest Analysis: {analyses[0].filename}</span>
                  </button>
                  <span className="text-xs text-gray-500 font-mono mt-2">
                    {analyses.length} logged recording{analyses.length > 1 ? 's' : ''} available in archive
                  </span>
                </div>
              )}

              <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-gray-300 font-mono w-full max-w-xl">
                <div className="p-3 rounded-xl bg-[#16213e]/60 border border-cyan/20 flex flex-col items-center text-center">
                  <Radio className="w-4 h-4 text-cyan mb-1.5" />
                  <span className="font-semibold text-white">pYIN F0 Tracking</span>
                  <span className="text-[10px] text-gray-400">50 - 500 Hz Contour</span>
                </div>
                <div className="p-3 rounded-xl bg-[#16213e]/60 border border-cyan/20 flex flex-col items-center text-center">
                  <BarChart3 className="w-4 h-4 text-amber-400 mb-1.5" />
                  <span className="font-semibold text-white">Cadence & Rate</span>
                  <span className="text-[10px] text-gray-400">Syllable Dynamics</span>
                </div>
                <div className="p-3 rounded-xl bg-[#16213e]/60 border border-cyan/20 flex flex-col items-center text-center">
                  <FileCode2 className="w-4 h-4 text-emerald-400 mb-1.5" />
                  <span className="font-semibold text-white">Whisper CTC STT</span>
                  <span className="text-[10px] text-gray-400">Word Timestamp Grid</span>
                </div>
                <div className="p-3 rounded-xl bg-[#16213e]/60 border border-cyan/20 flex flex-col items-center text-center">
                  <ShieldCheck className="w-4 h-4 text-purple-400 mb-1.5" />
                  <span className="font-semibold text-white">10 Flaw Classifiers</span>
                  <span className="text-[10px] text-gray-400">Temporal Evidence</span>
                </div>
              </div>
            </div>
          ) : (
            <>
              {/* Active Session Info Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 bg-surface rounded-xl px-5 py-3 border border-surface-border shadow-sm">
                <div className="flex items-center space-x-3 truncate">
                  <div className="w-3 h-3 rounded-full bg-cyan shadow-[0_0_8px_#00d4ff]" />
                  <div className="truncate">
                    <span className="text-xs text-gray-400 font-mono">
                      Active Stream:
                    </span>{' '}
                    <strong className="text-sm font-semibold text-white truncate">
                      {currentAnalysis.filename || 'Speech Recording'}
                    </strong>
                  </div>
                </div>

                <div className="flex items-center space-x-3 text-xs font-mono">
                  <span className="text-gray-400">ID:</span>
                  <span className="text-cyan bg-[#0a0a1a] px-2 py-0.5 rounded border border-surface-border">
                    {currentAnalysis.id ? currentAnalysis.id.slice(0, 8) : '--------'}...
                  </span>
                </div>
              </div>

              {/* Processing Pipeline Stage Grid (Visible during processing or upon completion) */}
              <ProcessingStatus
                currentStatus={currentAnalysis?.status || 'uploading'}
                progress={sseProgress}
                message={sseMessage}
                error={currentAnalysis?.error}
              />

              {/* Waveform Player (Shown when audio url is active) */}
              {currentAnalysis && (
                <WaveformPlayer
                  audioUrl={getAudioUrl(currentAnalysis.id)}
                  duration={currentAnalysis.duration_seconds}
                  findings={currentAnalysis.findings || []}
                  onTimeUpdate={(t) => setCurrentTime(t)}
                  onPlayStateChange={(playing) => setIsPlaying(playing)}
                  seekToTime={seekTarget}
                  onSeekComplete={() => setSeekTarget(null)}
                />
              )}

              {/* Metric Summary Cards Grid */}
              <MetricCards
                metrics={currentAnalysis?.metrics}
                findings={currentAnalysis?.findings}
                scores={currentAnalysis?.scores}
                is_video={currentAnalysis?.media_type === 'video'}
              />

              {/* Acoustic Charts Time-series */}
              <AcousticCharts
                metrics={currentAnalysis?.metrics}
                findings={currentAnalysis?.findings}
                currentTime={currentTime}
                onSeek={handleSeek}
              />

              {/* Two Column Grid: Transcript Editor & Findings Panel */}
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
                {/* Transcript Editor - 6 Columns */}
                <div className="xl:col-span-6">
                  {currentAnalysis && (
                    <TranscriptEditor
                      analysisId={currentAnalysis.id}
                      transcript={currentAnalysis.transcript}
                      findings={currentAnalysis.findings}
                      currentTime={currentTime}
                      onSeek={handleSeek}
                      onTranscriptUpdated={(newText) => {
                        setCurrentAnalysis((prev) =>
                          prev
                            ? {
                                ...prev,
                                transcript: prev.transcript
                                  ? { ...prev.transcript, text: newText }
                                  : { text: newText, segments: [], words: [] },
                              }
                            : prev
                        );
                      }}
                    />
                  )}
                </div>

                {/* Findings & Diagnostics Panel - 6 Columns */}
                <div className="xl:col-span-6">
                  <FindingsPanel
                    findings={currentAnalysis?.findings}
                    onPlaySegment={handlePlaySegment}
                    onSeek={handleSeek}
                  />
                </div>
              </div>
            </>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-surface-border/60 bg-[#0a0a1a] px-6 py-4 text-center text-xs text-gray-500 font-mono flex flex-col sm:flex-row items-center justify-between max-w-[1700px] w-full mx-auto">
        <p>J.A.R.V.I.S. Speech Intelligence Architecture • Dark Graphite / Cyan Protocol</p>
        <p className="mt-1 sm:mt-0">Neural Pipeline: Whisper ASR + F0 Praat/Librosa + LLM Diagnostics</p>
      </footer>
    </div>
  );
}
