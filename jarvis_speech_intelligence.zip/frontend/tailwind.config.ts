import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        graphite: {
          DEFAULT: "#1a1a2e",
          900: "#0a0a1a",
          800: "#1a1a2e",
          700: "#16213e",
          600: "#0f3460",
        },
        cyan: {
          DEFAULT: "#00d4ff",
          400: "#00d4ff",
          500: "#00b4d8",
          600: "#0096c7",
          dim: "rgba(0, 212, 255, 0.15)",
        },
        surface: {
          DEFAULT: "#1e1e30",
          card: "#1e1e30",
          hover: "#252540",
          border: "#2a2a4a",
          base: "#0a0a1a",
        },
        accent: {
          DEFAULT: "#e94560",
          hover: "#ff5773",
          dim: "rgba(233, 69, 96, 0.15)",
        },
      },
      boxShadow: {
        glow: "0 0 20px rgba(0, 212, 255, 0.25)",
        "glow-sm": "0 0 10px rgba(0, 212, 255, 0.2)",
        "glow-accent": "0 0 20px rgba(233, 69, 96, 0.3)",
      },
      animation: {
        "pulse-slow": "pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "spin-slow": "spin 3s linear infinite",
      },
    },
  },
  plugins: [],
};

export default config;
